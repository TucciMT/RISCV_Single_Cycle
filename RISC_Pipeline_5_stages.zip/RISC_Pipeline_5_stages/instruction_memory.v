module instruction_memory (
    input [31:0] A,      //! Endereço de leitura
    output reg [31:0] RD //! Dados lidos da memória de instruções
);

    reg [7:0] memory [0:1023]; //! Memória de instruções byte-addressable

    initial begin
        // Programa de teste fornecido:
        // 00a00293
        memory[10'h0] = 8'h93; // addi x5, x0, 10
        memory[10'h1] = 8'h02;
        memory[10'h2] = 8'ha0;
        memory[10'h3] = 8'h00;
        // 00000313
        memory[10'h4] = 8'h13; // addi x6, x0, 0
        memory[10'h5] = 8'h03;
        memory[10'h6] = 8'h00;
        memory[10'h7] = 8'h00;
        // 00000393
        memory[10'h8] = 8'h93; // addi x7, x0, 0
        memory[10'h9] = 8'h03;
        memory[10'hA] = 8'h00;
        memory[10'hB] = 8'h00;
        // 00028c63
        memory[10'hC] = 8'h63; // beq x5, x0, +24
        memory[10'hD] = 8'h8c;
        memory[10'hE] = 8'h02;
        memory[10'hF] = 8'h00;
        // 0003ae03
        memory[10'h10] = 8'h03; // lw x28, 0(x7)
        memory[10'h11] = 8'hae;
        memory[10'h12] = 8'h03;
        memory[10'h13] = 8'h00;
        // 01c30333
        memory[10'h14] = 8'h33; // add x6, x6, x28
        memory[10'h15] = 8'h03;
        memory[10'h16] = 8'hc3;
        memory[10'h17] = 8'h01;
        // 00438393
        memory[10'h18] = 8'h93; // addi x7, x7, 4
        memory[10'h19] = 8'h83;
        memory[10'h1A] = 8'h43;
        memory[10'h1B] = 8'h00;
        // fff28293
        memory[10'h1C] = 8'h93; // addi x5, x5, -1
        memory[10'h1D] = 8'h82;
        memory[10'h1E] = 8'hf2;
        memory[10'h1F] = 8'hff;
        // fe0006e3
        memory[10'h20] = 8'he3; // beq x0, x0, -20
        memory[10'h21] = 8'h06;
        memory[10'h22] = 8'h00;
        memory[10'h23] = 8'hfe;
        // 00000013
        memory[10'h24] = 8'h13; // addi x0, x0, 0 (NOP)
        memory[10'h25] = 8'h00;
        memory[10'h26] = 8'h00;
        memory[10'h27] = 8'h00;
        // fc000ce3
        memory[10'h28] = 8'he3; // beq x0, x0, -40
        memory[10'h29] = 8'h0c;
        memory[10'h2A] = 8'h00;
        memory[10'h2B] = 8'hfc;
    end

    always @(*) begin
        RD = {memory[A - 32'h1000 + 3], memory[A - 32'h1000 + 2], memory[A - 32'h1000 + 1], memory[A - 32'h1000 + 0]};
    end

endmodule
