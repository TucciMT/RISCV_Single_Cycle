module datapath (
    input           clk,          //! Sinal de clock
    input           rst,          //! Sinal de reset síncrono
    input           Branch,       //! Indica se a instrução corrente é um branch
    input  [1:0]    ResultSrc,    //! Seleção da fonte de dados para Write Back (estágio ID)
    input           MemWrite,     //! Controle de escrita da memória de dados (estágio ID)
    input           ALUSrc,       //! Seleção do operando B da ALU (estágio ID)
    input           RegWrite,     //! Controle de escrita do banco de registradores (estágio ID)
    input  [1:0]    ImmSrc,       //! Seleção do formato de imediato (estágio ID)
    input  [2:0]    ALUControl,   //! Operação da ALU (estágio ID)
    input           Jump,         //! Indicação de instrução JAL no estágio ID
    input  [2:0]    LoadType,     //! Define ajuste de sinal/zero para leituras de memória
    input  [1:0]    StoreType,    //! Define o tamanho da escrita em memória
    output          funct7,       //! Bit 30 da instrução para o bloco de controle
    output [2:0]    funct3,       //! Campo funct3 encaminhado para a controladora
    output [6:0]    op            //! Opcode encaminhado para a controladora
);

    /* Declaração dos fios utilizados ao longo do datapath */
    wire [31:0] pc_next;          //! Próximo valor do contador de programa
    wire [31:0] pc;               //! Valor atual do contador de programa
    wire [31:0] pc_plus4;         //! PC + 4 (próxima instrução sequencial)
    wire [31:0] instr;            //! Instrução lida na memória
    wire [31:0] if_id_pc;         //! PC armazenado no registrador IF/ID
    wire [31:0] if_id_pc_plus4;   //! PC+4 no estágio IF/ID
    wire [31:0] if_id_instr;      //! Instrução armazenada no registrador IF/ID
    wire [31:0] imm_ext;          //! Imediato estendido
    wire [31:0] rd1;              //! Operando A lido do banco de registradores
    wire [31:0] rd2;              //! Operando B lido do banco de registradores
    wire [31:0] id_ex_pc;         //! PC armazenado no registrador ID/EX
    wire [31:0] id_ex_pc_plus4;   //! PC+4 propagado para ID/EX
    wire [31:0] id_ex_rd1;        //! Operando A no estágio EX
    wire [31:0] id_ex_rd2;        //! Operando B (antes da seleção) no estágio EX
    wire [31:0] id_ex_imm;        //! Imediato no estágio EX
    wire [4:0]  id_ex_rd;         //! Registrador destino no estágio EX/MEM
    wire        id_ex_RegWrite;   //! Controle RegWrite no estágio EX/MEM
    wire        id_ex_MemWrite;   //! Controle MemWrite no estágio EX/MEM
    wire [1:0]  id_ex_ResultSrc;  //! Controle ResultSrc no estágio EX/MEM
    wire        id_ex_Branch;     //! Indicação de branch no estágio EX
    wire        id_ex_Jump;       //! Indicação de jump no estágio EX
    wire        id_ex_ALUSrc;     //! Seleção do operando B da ALU no estágio EX
    wire [2:0]  id_ex_ALUControl; //! Operação da ALU no estágio EX
    wire [2:0]  id_ex_LoadType;   //! Tipo de carga propagado para o estágio MEM
    wire [1:0]  id_ex_StoreType;  //! Tipo de armazenamento propagado para o estágio MEM
    wire [31:0] alu_srcB;         //! Operando B efetivo da ALU
    wire [31:0] alu_result;       //! Resultado da operação da ALU
    wire        zero;             //! Flag zero da ALU
    wire [31:0] pc_target;        //! Endereço alvo do branch/jump
    wire        pc_src;           //! Indica se o próximo PC deve ser o alvo do branch/jump
    wire [31:0] read_data;        //! Dado lido da memória de dados
    wire [31:0] load_data_ext;    //! Dado de leitura ajustado conforme o tipo de carga
    wire [31:0] wb_data;          //! Dado a ser escrito no banco de registradores
    wire        mem_wb_RegWrite;  //! Controle RegWrite no estágio WB
    wire [1:0]  mem_wb_ResultSrc; //! Seleção da fonte de dados no estágio WB
    wire [31:0] mem_wb_ReadData;  //! Dado vindo da memória no estágio WB
    wire [31:0] mem_wb_ALUResult; //! Resultado da ALU propagado para WB
    wire [4:0]  mem_wb_rd;        //! Registrador destino no estágio WB
    wire [31:0] mem_wb_PCPlus4;   //! Valor de PC+4 propagado até o estágio WB
    reg  [3:0]  byte_enable;      //! Máscara de escrita por byte na memória de dados
    reg  [31:0] store_data;       //! Dado alinhado para escrita parcial
    reg  [1:0]  hazard_counter;   //! Contador de ciclos para inserir bolhas por hazard
    wire        hazard_stall;     //! Indica necessidade de manter IF e ID parados
    wire        hazard_detect;    //! Detecta dependência de dados sem forwarding
    wire        uses_rs1;         //! Verdadeiro quando a instrução em ID utiliza rs1
    wire        uses_rs2;         //! Verdadeiro quando a instrução em ID utiliza rs2
    wire [4:0]  id_rs1;           //! Campo rs1 da instrução em ID
    wire [4:0]  id_rs2;           //! Campo rs2 da instrução em ID

    /* Estágio IF */
    program_counter PROGRAM_COUNTER (
        .clk(clk),
        .rst(rst),
        .stall(hazard_stall),
        .PCNext(pc_next),
        .PC(pc)
    );

    instruction_memory INSTRUCTION_MEMORY (
        .A(pc),
        .RD(instr)
    );

    adder ADDER_PC (
        .a(pc),
        .b(32'd4),
        .sum(pc_plus4)
    );

    /* Registrador IF/ID com sinal de flush quando um branch é tomado */
    if_id_reg IF_ID (
        .clk(clk),
        .rst(rst),
        .flush(pc_src),
        .stall(hazard_stall),
        .pc_in(pc),
        .pc_plus4_in(pc_plus4),
        .instr_in(instr),
        .pc_out(if_id_pc),
        .pc_plus4_out(if_id_pc_plus4),
        .instr_out(if_id_instr)
    );

    /* Campos da instrução encaminhados para o bloco de controle */
    assign op     = if_id_instr[6:0];
    assign funct3 = if_id_instr[14:12];
    assign funct7 = if_id_instr[30];
    assign id_rs1 = if_id_instr[19:15];
    assign id_rs2 = if_id_instr[24:20];

    wire is_nop    = (if_id_instr == 32'b0);
    wire is_jal    = (op == 7'b1101111);
    wire is_store  = (op == 7'b0100011);
    wire is_branch = (op == 7'b1100011);
    wire is_rtype  = (op == 7'b0110011);

    assign uses_rs1 = !is_nop && !is_jal; //! Todas as demais instruções dependem de rs1
    assign uses_rs2 = !is_nop && (is_rtype || is_store || is_branch);

    assign hazard_detect = id_ex_RegWrite && (id_ex_rd != 5'd0) &&
                           ((uses_rs1 && (id_ex_rd == id_rs1)) ||
                            (uses_rs2 && (id_ex_rd == id_rs2)));

    /* Banco de registradores (leitura assíncrona, escrita síncrona) */
    register_file REGISTER_FILE (
        .clk(clk),
        .rst(rst),
        .WE3(mem_wb_RegWrite),
        .A1(if_id_instr[19:15]),
        .A2(if_id_instr[24:20]),
        .A3(mem_wb_rd),
        .WD3(wb_data),
        .RD1(rd1),
        .RD2(rd2)
    );

    /* Extensão de imediato conforme o tipo da instrução */
    extend EXTEND (
        .instr(if_id_instr[31:7]),
        .immsrc(ImmSrc),
        .immext(imm_ext)
    );

    localparam [1:0] HAZARD_EXTRA_CYCLES = 2'd2; //! Número de ciclos adicionais após detecção

    always @(posedge clk) begin
        if (rst || pc_src) begin
            hazard_counter <= 2'd0;
        end else if (hazard_detect && (hazard_counter == 2'd0)) begin
            hazard_counter <= HAZARD_EXTRA_CYCLES;
        end else if (hazard_counter != 2'd0) begin
            hazard_counter <= hazard_counter - 2'd1;
        end
    end

    assign hazard_stall = hazard_detect || (hazard_counter != 2'd0);

    /* Registrador ID/EX - propaga operandos e sinais de controle */
    id_ex_reg ID_EX (
        .clk(clk),
        .rst(rst),
        .flush(pc_src | hazard_stall),
        .RegWrite_in(RegWrite),
        .MemWrite_in(MemWrite),
        .ResultSrc_in(ResultSrc),
        .Branch_in(Branch),
        .Jump_in(Jump),
        .LoadType_in(LoadType),
        .StoreType_in(StoreType),
        .ALUSrc_in(ALUSrc),
        .ALUControl_in(ALUControl),
        .pc_in(if_id_pc),
        .pc_plus4_in(if_id_pc_plus4),
        .rd1_in(rd1),
        .rd2_in(rd2),
        .imm_in(imm_ext),
        .rd_in(if_id_instr[11:7]),
        .RegWrite_out(id_ex_RegWrite),
        .MemWrite_out(id_ex_MemWrite),
        .ResultSrc_out(id_ex_ResultSrc),
        .Branch_out(id_ex_Branch),
        .Jump_out(id_ex_Jump),
        .LoadType_out(id_ex_LoadType),
        .StoreType_out(id_ex_StoreType),
        .ALUSrc_out(id_ex_ALUSrc),
        .ALUControl_out(id_ex_ALUControl),
        .pc_out(id_ex_pc),
        .pc_plus4_out(id_ex_pc_plus4),
        .rd1_out(id_ex_rd1),
        .rd2_out(id_ex_rd2),
        .imm_out(id_ex_imm),
        .rd_out(id_ex_rd)
    );

    /* Estágio EX + MEM */
    Mux2x1 #(.N(32)) MUX_SRCB (
        .a(id_ex_rd2),
        .b(id_ex_imm),
        .sel(id_ex_ALUSrc),
        .y(alu_srcB)
    );

    ALU ALU_UNIT (
        .SrcA(id_ex_rd1),
        .SrcB(alu_srcB),
        .ALUControl(id_ex_ALUControl),
        .ALUResult(alu_result),
        .Zero(zero)
    );

    adder ADDER_PCTARGET (
        .a(id_ex_pc),
        .b(id_ex_imm),
        .sum(pc_target)
    );

    assign pc_src = (id_ex_Branch & zero) | id_ex_Jump; //! Branch ou jump tomados

    localparam STORE_SB   = 2'b00;
    localparam STORE_SH   = 2'b01;
    localparam STORE_SW   = 2'b10;

    always @(*) begin
        if (!id_ex_MemWrite) begin
            byte_enable = 4'b0000;
        end else begin
            case (id_ex_StoreType)
                STORE_SW: byte_enable = 4'b1111;
                STORE_SH: byte_enable = alu_result[1] ? 4'b1100 : 4'b0011;
                STORE_SB: begin
                    case (alu_result[1:0])
                        2'b00: byte_enable = 4'b0001;
                        2'b01: byte_enable = 4'b0010;
                        2'b10: byte_enable = 4'b0100;
                        default: byte_enable = 4'b1000;
                    endcase
                end
                default: byte_enable = 4'b0000;
            endcase
        end
    end

    always @(*) begin
        case (id_ex_StoreType)
            STORE_SW: store_data = id_ex_rd2;
            STORE_SH: store_data = alu_result[1] ? {id_ex_rd2[15:0], 16'b0} : {16'b0, id_ex_rd2[15:0]};
            STORE_SB: begin
                case (alu_result[1:0])
                    2'b00: store_data = {24'b0, id_ex_rd2[7:0]};
                    2'b01: store_data = {16'b0, id_ex_rd2[7:0], 8'b0};
                    2'b10: store_data = {8'b0, id_ex_rd2[7:0], 16'b0};
                    default: store_data = {id_ex_rd2[7:0], 24'b0};
                endcase
            end
            default: store_data = id_ex_rd2;
        endcase
    end

    memByteAddressable32WF #(
        .DATA_WIDTH(32),
        .ADDRESS_WIDTH(8)
    ) DATA_MEMORY (
        .clk(clk),
        .byteEnable(byte_enable),
        .addr(alu_result[7:0]),
        .din(store_data),
        .dout(read_data)
    );

    localparam LOAD_LB  = 3'b000;
    localparam LOAD_LH  = 3'b001;
    localparam LOAD_LW  = 3'b010;
    localparam LOAD_LBU = 3'b011;
    localparam LOAD_LHU = 3'b100;

    wire [7:0] selected_byte = (alu_result[1:0] == 2'b00) ? read_data[7:0]  :
                               (alu_result[1:0] == 2'b01) ? read_data[15:8] :
                               (alu_result[1:0] == 2'b10) ? read_data[23:16]:
                                                             read_data[31:24];

    wire [15:0] selected_half = alu_result[1] ? read_data[31:16] : read_data[15:0];

    reg [31:0] load_data_ext_reg;
    always @(*) begin
        case (id_ex_LoadType)
            LOAD_LB:  load_data_ext_reg = {{24{selected_byte[7]}}, selected_byte};
            LOAD_LBU: load_data_ext_reg = {24'b0, selected_byte};
            LOAD_LH:  load_data_ext_reg = {{16{selected_half[15]}}, selected_half};
            LOAD_LHU: load_data_ext_reg = {16'b0, selected_half};
            LOAD_LW:  load_data_ext_reg = read_data;
            default:  load_data_ext_reg = read_data;
        endcase
    end

    assign load_data_ext = load_data_ext_reg;

    /* Registrador MEM/WB */
    mem_wb_reg MEM_WB (
        .clk(clk),
        .rst(rst),
        .RegWrite_in(id_ex_RegWrite),
        .ResultSrc_in(id_ex_ResultSrc),
        .ReadData_in(load_data_ext),
        .ALUResult_in(alu_result),
        .pc_plus4_in(id_ex_pc_plus4),
        .rd_in(id_ex_rd),
        .RegWrite_out(mem_wb_RegWrite),
        .ResultSrc_out(mem_wb_ResultSrc),
        .ReadData_out(mem_wb_ReadData),
        .ALUResult_out(mem_wb_ALUResult),
        .pc_plus4_out(mem_wb_PCPlus4),
        .rd_out(mem_wb_rd)
    );

    /* Estágio WB */
    assign wb_data = (mem_wb_ResultSrc == 2'b00) ? mem_wb_ALUResult :
                     (mem_wb_ResultSrc == 2'b01) ? mem_wb_ReadData :
                     mem_wb_PCPlus4; //! Para JAL gravar PC+4

    /* Atualização do PC: branch tomado versus sequência normal */
    Mux2x1 #(.N(32)) MUX_PCNEXT (
        .a(pc_plus4),
        .b(pc_target),
        .sel(pc_src),
        .y(pc_next)
    );

endmodule
