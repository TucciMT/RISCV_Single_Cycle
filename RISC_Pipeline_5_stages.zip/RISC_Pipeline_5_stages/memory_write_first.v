module memory_write_first #(
    parameter DATA_WIDTH = 8,          //! Largura dos dados (em bits)
    parameter ADDRESS_WIDTH = 4        //! Número de bits do endereço
) (
    input  wire                     clk,  //! Clock da memória
    input  wire                     we,   //! Habilitação de escrita
    input  wire [ADDRESS_WIDTH-1:0] addr, //! Endereço da palavra
    input  wire [DATA_WIDTH-1:0]    din,  //! Dado de entrada
    output wire [DATA_WIDTH-1:0]    dout  //! Dado de saída (leitura assíncrona)
);

    localparam DEPTH = 1 << ADDRESS_WIDTH; //! Número total de posições na memória

    reg [DATA_WIDTH-1:0] mem [0:DEPTH-1]; //! Array que armazena os dados
    integer init_idx; //! Índice auxiliar para inicialização

    initial begin
        for (init_idx = 0; init_idx < DEPTH; init_idx = init_idx + 1) begin
            mem[init_idx] = {DATA_WIDTH{1'b0}}; //! Garante memória zerada e evita valores indefinidos
        end
    end

    always @(posedge clk) begin
        if (we) begin
            mem[addr] <= din; //! Escrita síncrona
        end
    end

    assign dout = mem[addr]; //! Leitura assíncrona (write-first devido ao uso de atribuição não bloqueante)

endmodule
