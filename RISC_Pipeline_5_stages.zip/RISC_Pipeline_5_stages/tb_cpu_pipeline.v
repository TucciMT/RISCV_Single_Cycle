`timescale 1ns/1ps

module tb_cpu_pipeline;
    reg clk = 0;
    reg rst = 1;

    // Instancie cpu ou cpu_pipeline_single_file caso deseje testar o arquivo único
    cpu uut (
        .clk(clk),
        .rst(rst)
    );

    // Geração de clock de 100 MHz (período de 10 ns)
    always #5 clk = ~clk;

    integer x5_expected;
    integer x5_writes;
    reg success;
    reg [31:0] write_val;
    integer error_count;

    initial begin
        x5_expected = 10;
        x5_writes   = 0;
        success     = 0;
        write_val   = 0;
        error_count = 0;
    end

    initial begin
        $dumpfile("cpu_pipeline.vcd");
        $dumpvars(0, tb_cpu_pipeline);
        // Mantém reset ativo por alguns ciclos
        #20;
        rst = 0;
        // Aguarda número máximo de ciclos antes de acusar falha
        repeat (500) @(posedge clk);
        if (!success) begin
            error_count = error_count + 1;
            $error("Timeout: x5 não atingiu zero dentro do número de ciclos esperado");
        end
        $display("Teste encerrado em t=%0t com %0d erro(s)", $time, error_count);
        $finish;
    end

    // Monitora e valida o comportamento esperado do programa de teste
    always @(posedge clk) begin
        if (rst) begin
            x5_expected <= 10;
            x5_writes   <= 0;
            success     <= 0;
            write_val   <= 0;
            error_count <= 0;
        end else begin
            // Exibe alguns registradores para inspeção manual
            $display("t=%0t | PC=%h | x5=%h x6=%h x7=%h", $time,
                     uut.DATAPATH.PROGRAM_COUNTER.PC,
                     uut.DATAPATH.REGISTER_FILE.registers[5],
                     uut.DATAPATH.REGISTER_FILE.registers[6],
                     uut.DATAPATH.REGISTER_FILE.registers[7]);

            if (!success && uut.DATAPATH.MEM_WB.RegWrite_out && (uut.DATAPATH.MEM_WB.rd_out == 5'd5)) begin
                write_val = uut.DATAPATH.wb_data;
                x5_writes <= x5_writes + 1;

                if (x5_writes == 0) begin
                    // Primeira escrita em x5 deve carregar o valor inicial 10
                    if (write_val !== 32'd10) begin
                        error_count = error_count + 1;
                        $error("Falha: primeira escrita em x5 deveria ser 10, obtido %0d", write_val);
                    end
                    x5_expected <= write_val - 1;
                end else begin
                    if (write_val !== x5_expected) begin
                        error_count = error_count + 1;
                        $error("Falha: esperado x5=%0d, obtido %0d na escrita #%0d", x5_expected, write_val, x5_writes);
                    end
                    if (write_val == 0) begin
                        // Quando x5 chega a zero esperamos x7=40, x6=0 e x28=0
                        if (uut.DATAPATH.REGISTER_FILE.registers[7] !== 32'd40) begin
                            error_count = error_count + 1;
                            $error("Falha: x7 deveria ser 40 quando x5 chegou a zero, obtido %0d", uut.DATAPATH.REGISTER_FILE.registers[7]);
                        end
                        if (uut.DATAPATH.REGISTER_FILE.registers[6] !== 32'd0) begin
                            error_count = error_count + 1;
                            $error("Falha: x6 deveria permanecer 0, obtido %0d", uut.DATAPATH.REGISTER_FILE.registers[6]);
                        end
                        if (uut.DATAPATH.REGISTER_FILE.registers[28] !== 32'd0) begin
                            error_count = error_count + 1;
                            $error("Falha: x28 deveria ser 0 após os loads, obtido %0d", uut.DATAPATH.REGISTER_FILE.registers[28]);
                        end
                        success   <= 1;
                        $display("Teste concluído em t=%0t com %0d erro(s)", $time, error_count);
                        $finish;
                    end
                    x5_expected <= write_val - 1;
                end
            end
        end
    end
endmodule
