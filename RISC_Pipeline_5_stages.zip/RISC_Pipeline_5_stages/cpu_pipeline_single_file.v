// Arquivo auto-gerado para facilitar testes: contém todas as definições em um único arquivo.
module cpu_pipeline_single_file (
    input clk, //! Sinal de clock
    input rst  //! Sinal de reset
);

    /* Declaração dos sinais de interconexão entre os blocos */
    wire        Branch;       //! Indica instrução de branch
    wire [1:0]  ResultSrc;    //! Seleção da fonte para Write Back (ALU_sf/Mem/PC+4)
    wire        MemWrite;     //! Habilita escrita na memória de dados
    wire        ALUSrc;       //! Seleciona imediato como operando B da ALU_sf
    wire        RegWrite;     //! Habilita escrita no banco de registradores
    wire [1:0]  ImmSrc;       //! Seleciona extensão do imediato
    wire        Jump;         //! Indica instrução JAL
    wire [2:0]  LoadType;     //! Ajuste de sinal/zero para leituras
    wire [1:0]  StoreType;    //! Tamanho da escrita em memória
    wire [2:0]  ALUControl;   //! Operação executada pela ALU_sf
    wire        funct7;       //! Bit 30 da instrução em ID
    wire [2:0]  funct3;       //! Campo funct3 em ID
    wire [6:0]  op;           //! Opcode da instrução em ID

    /* Datapath pipeline */
    datapath_sf DATAPATH (
        .clk(clk),
        .rst(rst),
        .Branch(Branch),
        .ResultSrc(ResultSrc),
        .MemWrite(MemWrite),
        .ALUSrc(ALUSrc),
        .RegWrite(RegWrite),
        .ImmSrc(ImmSrc),
        .ALUControl(ALUControl),
        .funct7(funct7),
        .funct3(funct3),
        .op(op),
        .Jump(Jump),
        .LoadType(LoadType),
        .StoreType(StoreType)
    );

    /* Unidade de controle reaproveitada do processador single-cycle */
    Control_Unit_sf CONTROL_UNIT (
        .Op(op),
        .funct3(funct3),
        .funct7(funct7),
        .Branch(Branch),
        .ResultSrc(ResultSrc),
        .MemWrite(MemWrite),
        .ALUSrc(ALUSrc),
        .ImmSrc(ImmSrc),
        .RegWrite(RegWrite),
        .Jump(Jump),
        .LoadType(LoadType),
        .StoreType(StoreType),
        .ALUControl(ALUControl)
    );

endmodule

module datapath_sf (
    input           clk,          //! Sinal de clock
    input           rst,          //! Sinal de reset síncrono
    input           Branch,       //! Indica se a instrução corrente é um branch
    input  [1:0]    ResultSrc,    //! Seleção da fonte de dados para Write Back (estágio ID)
    input           MemWrite,     //! Controle de escrita da memória de dados (estágio ID)
    input           ALUSrc,       //! Seleção do operando B da ALU_sf (estágio ID)
    input           RegWrite,     //! Controle de escrita do banco de registradores (estágio ID)
    input  [1:0]    ImmSrc,       //! Seleção do formato de imediato (estágio ID)
    input  [2:0]    ALUControl,   //! Operação da ALU_sf (estágio ID)
    input           Jump,         //! Indicação de instrução JAL no estágio ID
    input  [2:0]    LoadType,     //! Ajuste de sinal/zero para leituras
    input  [1:0]    StoreType,    //! Tamanho da escrita em memória
    output          funct7,       //! Bit 30 da instrução para o bloco de controle
    output [2:0]    funct3,       //! Campo funct3 encaminhado para a controladora
    output [6:0]    op            //! Opcode encaminhado para a controladora
);

    /* Declaração dos fios utilizados ao longo do datapath_sf */
    wire [31:0] pc_next;          //! Próximo valor do contador de programa
    wire [31:0] pc;               //! Valor atual do contador de programa
    wire [31:0] pc_plus4;         //! PC + 4 (próxima instrução sequencial)
    wire [31:0] instr;            //! Instrução lida na memória
    wire [31:0] if_id_pc;         //! PC armazenado no registrador IF/ID
    wire [31:0] if_id_pc_plus4;   //! PC+4 no estágio IF/ID
    wire [31:0] if_id_instr;      //! Instrução armazenada no registrador IF/ID
    wire [31:0] imm_ext;          //! Imediato estendido
    wire [31:0] rd1;              //! Operando A lido do banco de registradores
    wire [31:0] rd2;              //! Operando B lido do banco de registradores
    wire [31:0] id_ex_pc;         //! PC armazenado no registrador ID/EX
    wire [31:0] id_ex_pc_plus4;   //! PC+4 propagado para ID/EX
    wire [31:0] id_ex_rd1;        //! Operando A no estágio EX
    wire [31:0] id_ex_rd2;        //! Operando B (antes da seleção) no estágio EX
    wire [31:0] id_ex_imm;        //! Imediato no estágio EX
    wire [4:0]  id_ex_rd;         //! Registrador destino no estágio EX/MEM
    wire        id_ex_RegWrite;   //! Controle RegWrite no estágio EX/MEM
    wire        id_ex_MemWrite;   //! Controle MemWrite no estágio EX/MEM
    wire [1:0]  id_ex_ResultSrc;  //! Controle ResultSrc no estágio EX/MEM
    wire        id_ex_Branch;     //! Indicação de branch no estágio EX
    wire        id_ex_Jump;       //! Indicação de jump no estágio EX
    wire        id_ex_ALUSrc;     //! Seleção do operando B da ALU_sf no estágio EX
    wire [2:0]  id_ex_ALUControl; //! Operação da ALU_sf no estágio EX
    wire [2:0]  id_ex_LoadType;   //! Tipo de carga propagado para o estágio MEM
    wire [1:0]  id_ex_StoreType;  //! Tipo de armazenamento propagado para o estágio MEM
    wire [31:0] alu_srcB;         //! Operando B efetivo da ALU_sf
    wire [31:0] alu_result;       //! Resultado da operação da ALU_sf
    wire        zero;             //! Flag zero da ALU_sf
    wire [31:0] pc_target;        //! Endereço alvo do branch/jump
    wire        pc_src;           //! Indica se o próximo PC deve ser o alvo do branch/jump
    wire [31:0] read_data;        //! Dado lido da memória de dados
    wire [31:0] load_data_ext;    //! Dado de leitura ajustado conforme o tipo de carga
    wire [31:0] wb_data;          //! Dado a ser escrito no banco de registradores
    wire        mem_wb_RegWrite;  //! Controle RegWrite no estágio WB
    wire [1:0]  mem_wb_ResultSrc; //! Seleção da fonte de dados no estágio WB
    wire [31:0] mem_wb_ReadData;  //! Dado vindo da memória no estágio WB
    wire [31:0] mem_wb_ALUResult; //! Resultado da ALU_sf propagado para WB
    wire [4:0]  mem_wb_rd;        //! Registrador destino no estágio WB
    wire [31:0] mem_wb_PCPlus4;   //! Valor de PC+4 propagado até o estágio WB
    reg  [3:0]  byte_enable;      //! Máscara de escrita por byte na memória de dados
    reg  [31:0] store_data;       //! Dado alinhado para escrita parcial
    reg  [1:0]  hazard_counter;   //! Contador de ciclos para inserção de bolhas por hazard
    wire        hazard_stall;     //! Mantém PC/IF/ID quando verdadeiro
    wire        hazard_detect;    //! Dependência de dados detectada
    wire        uses_rs1;         //! Indica uso de rs1 na instrução atual de ID
    wire        uses_rs2;         //! Indica uso de rs2 na instrução atual de ID
    wire [4:0]  id_rs1;           //! Campo rs1 em ID
    wire [4:0]  id_rs2;           //! Campo rs2 em ID

    /* Estágio IF */
    program_counter_sf PROGRAM_COUNTER (
        .clk(clk),
        .rst(rst),
        .stall(hazard_stall),
        .PCNext(pc_next),
        .PC(pc)
    );

    instruction_memory_sf INSTRUCTION_MEMORY (
        .A(pc),
        .RD(instr)
    );

    adder_sf ADDER_PC (
        .a(pc),
        .b(32'd4),
        .sum(pc_plus4)
    );

    /* Registrador IF/ID com sinal de flush quando um branch é tomado */
    if_id_reg_sf IF_ID (
        .clk(clk),
        .rst(rst),
        .flush(pc_src),
        .stall(hazard_stall),
        .pc_in(pc),
        .pc_plus4_in(pc_plus4),
        .instr_in(instr),
        .pc_out(if_id_pc),
        .pc_plus4_out(if_id_pc_plus4),
        .instr_out(if_id_instr)
    );

    /* Campos da instrução encaminhados para o bloco de controle */
    assign op     = if_id_instr[6:0];
    assign funct3 = if_id_instr[14:12];
    assign funct7 = if_id_instr[30];
    assign id_rs1 = if_id_instr[19:15];
    assign id_rs2 = if_id_instr[24:20];

    wire is_nop_sf    = (if_id_instr == 32'b0);
    wire is_jal_sf    = (op == 7'b1101111);
    wire is_store_sf  = (op == 7'b0100011);
    wire is_branch_sf = (op == 7'b1100011);
    wire is_rtype_sf  = (op == 7'b0110011);

    assign uses_rs1 = !is_nop_sf && !is_jal_sf;
    assign uses_rs2 = !is_nop_sf && (is_rtype_sf || is_store_sf || is_branch_sf);

    assign hazard_detect = id_ex_RegWrite && (id_ex_rd != 5'd0) &&
                           ((uses_rs1 && (id_ex_rd == id_rs1)) ||
                            (uses_rs2 && (id_ex_rd == id_rs2)));

    /* Banco de registradores (leitura assíncrona, escrita síncrona) */
    register_file_sf REGISTER_FILE (
        .clk(clk),
        .rst(rst),
        .WE3(mem_wb_RegWrite),
        .A1(if_id_instr[19:15]),
        .A2(if_id_instr[24:20]),
        .A3(mem_wb_rd),
        .WD3(wb_data),
        .RD1(rd1),
        .RD2(rd2)
    );

    /* Extensão de imediato conforme o tipo da instrução */
    extend_sf EXTEND (
        .instr(if_id_instr[31:7]),
        .immsrc(ImmSrc),
        .immext(imm_ext)
    );

    localparam [1:0] HAZARD_EXTRA_CYCLES_SF = 2'd2; //! Ciclos adicionais após detectar dependência

    always @(posedge clk) begin
        if (rst || pc_src) begin
            hazard_counter <= 2'd0;
        end else if (hazard_detect && (hazard_counter == 2'd0)) begin
            hazard_counter <= HAZARD_EXTRA_CYCLES_SF;
        end else if (hazard_counter != 2'd0) begin
            hazard_counter <= hazard_counter - 2'd1;
        end
    end

    assign hazard_stall = hazard_detect || (hazard_counter != 2'd0);

    /* Registrador ID/EX - propaga operandos e sinais de controle */
    id_ex_reg_sf ID_EX (
        .clk(clk),
        .rst(rst),
        .flush(pc_src | hazard_stall),
        .RegWrite_in(RegWrite),
        .MemWrite_in(MemWrite),
        .ResultSrc_in(ResultSrc),
        .Branch_in(Branch),
        .Jump_in(Jump),
        .LoadType_in(LoadType),
        .StoreType_in(StoreType),
        .ALUSrc_in(ALUSrc),
        .ALUControl_in(ALUControl),
        .pc_in(if_id_pc),
        .pc_plus4_in(if_id_pc_plus4),
        .rd1_in(rd1),
        .rd2_in(rd2),
        .imm_in(imm_ext),
        .rd_in(if_id_instr[11:7]),
        .RegWrite_out(id_ex_RegWrite),
        .MemWrite_out(id_ex_MemWrite),
        .ResultSrc_out(id_ex_ResultSrc),
        .Branch_out(id_ex_Branch),
        .Jump_out(id_ex_Jump),
        .LoadType_out(id_ex_LoadType),
        .StoreType_out(id_ex_StoreType),
        .ALUSrc_out(id_ex_ALUSrc),
        .ALUControl_out(id_ex_ALUControl),
        .pc_out(id_ex_pc),
        .pc_plus4_out(id_ex_pc_plus4),
        .rd1_out(id_ex_rd1),
        .rd2_out(id_ex_rd2),
        .imm_out(id_ex_imm),
        .rd_out(id_ex_rd)
    );

    /* Estágio EX + MEM */
    Mux2x1_sf #(.N(32)) MUX_SRCB (
        .a(id_ex_rd2),
        .b(id_ex_imm),
        .sel(id_ex_ALUSrc),
        .y(alu_srcB)
    );

    ALU_sf ALU_UNIT (
        .SrcA(id_ex_rd1),
        .SrcB(alu_srcB),
        .ALUControl(id_ex_ALUControl),
        .ALUResult(alu_result),
        .Zero(zero)
    );

    adder_sf ADDER_PCTARGET (
        .a(id_ex_pc),
        .b(id_ex_imm),
        .sum(pc_target)
    );

    assign pc_src = (id_ex_Branch & zero) | id_ex_Jump; //! Branch ou jump tomados

    localparam STORE_SB   = 2'b00;
    localparam STORE_SH   = 2'b01;
    localparam STORE_SW   = 2'b10;

    always @(*) begin
        if (!id_ex_MemWrite) begin
            byte_enable = 4'b0000;
        end else begin
            case (id_ex_StoreType)
                STORE_SW: byte_enable = 4'b1111;
                STORE_SH: byte_enable = alu_result[1] ? 4'b1100 : 4'b0011;
                STORE_SB: begin
                    case (alu_result[1:0])
                        2'b00: byte_enable = 4'b0001;
                        2'b01: byte_enable = 4'b0010;
                        2'b10: byte_enable = 4'b0100;
                        default: byte_enable = 4'b1000;
                    endcase
                end
                default: byte_enable = 4'b0000;
            endcase
        end
    end

    always @(*) begin
        case (id_ex_StoreType)
            STORE_SW: store_data = id_ex_rd2;
            STORE_SH: store_data = alu_result[1] ? {id_ex_rd2[15:0], 16'b0} : {16'b0, id_ex_rd2[15:0]};
            STORE_SB: begin
                case (alu_result[1:0])
                    2'b00: store_data = {24'b0, id_ex_rd2[7:0]};
                    2'b01: store_data = {16'b0, id_ex_rd2[7:0], 8'b0};
                    2'b10: store_data = {8'b0, id_ex_rd2[7:0], 16'b0};
                    default: store_data = {id_ex_rd2[7:0], 24'b0};
                endcase
            end
            default: store_data = id_ex_rd2;
        endcase
    end

    memByteAddressable32WF_sf #(
        .DATA_WIDTH(32),
        .ADDRESS_WIDTH(8)
    ) DATA_MEMORY (
        .clk(clk),
        .byteEnable(byte_enable),
        .addr(alu_result[7:0]),
        .din(store_data),
        .dout(read_data)
    );

    localparam LOAD_LB  = 3'b000;
    localparam LOAD_LH  = 3'b001;
    localparam LOAD_LW  = 3'b010;
    localparam LOAD_LBU = 3'b011;
    localparam LOAD_LHU = 3'b100;

    wire [7:0] selected_byte = (alu_result[1:0] == 2'b00) ? read_data[7:0]  :
                               (alu_result[1:0] == 2'b01) ? read_data[15:8] :
                               (alu_result[1:0] == 2'b10) ? read_data[23:16]:
                                                             read_data[31:24];

    wire [15:0] selected_half = alu_result[1] ? read_data[31:16] : read_data[15:0];

    reg [31:0] load_data_ext_reg;
    always @(*) begin
        case (id_ex_LoadType)
            LOAD_LB:  load_data_ext_reg = {{24{selected_byte[7]}}, selected_byte};
            LOAD_LBU: load_data_ext_reg = {24'b0, selected_byte};
            LOAD_LH:  load_data_ext_reg = {{16{selected_half[15]}}, selected_half};
            LOAD_LHU: load_data_ext_reg = {16'b0, selected_half};
            LOAD_LW:  load_data_ext_reg = read_data;
            default:  load_data_ext_reg = read_data;
        endcase
    end

    assign load_data_ext = load_data_ext_reg;

    /* Registrador MEM/WB */
    mem_wb_reg_sf MEM_WB (
        .clk(clk),
        .rst(rst),
        .RegWrite_in(id_ex_RegWrite),
        .ResultSrc_in(id_ex_ResultSrc),
        .ReadData_in(load_data_ext),
        .ALUResult_in(alu_result),
        .pc_plus4_in(id_ex_pc_plus4),
        .rd_in(id_ex_rd),
        .RegWrite_out(mem_wb_RegWrite),
        .ResultSrc_out(mem_wb_ResultSrc),
        .ReadData_out(mem_wb_ReadData),
        .ALUResult_out(mem_wb_ALUResult),
        .pc_plus4_out(mem_wb_PCPlus4),
        .rd_out(mem_wb_rd)
    );

    /* Estágio WB */
    assign wb_data = (mem_wb_ResultSrc == 2'b00) ? mem_wb_ALUResult :
                     (mem_wb_ResultSrc == 2'b01) ? mem_wb_ReadData :
                     mem_wb_PCPlus4; //! Para JAL gravar PC+4

    /* Atualização do PC: branch tomado versus sequência normal */
    Mux2x1_sf #(.N(32)) MUX_PCNEXT (
        .a(pc_plus4),
        .b(pc_target),
        .sel(pc_src),
        .y(pc_next)
    );

endmodule

module Control_Unit_sf (
    input  [6:0] Op,          //! Campo opcode da instrução
    input  [2:0] funct3,      //! Campo funct3 da instrução
    input        funct7,      //! Bit mais significativo do campo funct7 da instrução
    output       Branch,      //! Indica se a instrução é um branch condicional
    output [1:0] ResultSrc,   //! Seleciona a fonte de dados para Write Back (ALU_sf, Memória ou PC+4)
    output       MemWrite,    //! Habilita escrita na memória de dados
    output       ALUSrc,      //! Seleciona entre operando do registrador ou imediato para a ALU_sf
    output [1:0] ImmSrc,      //! Define o tipo de extensão a ser aplicado ao imediato
    output       RegWrite,    //! Habilita escrita no banco de registradores
    output       Jump,        //! Indica instrução JAL (desvio incondicional)
    output [2:0] LoadType,    //! Define como ajustar dados carregados
    output [1:0] StoreType,   //! Define o tamanho da escrita em memória
    output [2:0] ALUControl   //! Define a operação realizada pela ALU_sf
);

    //! Sinal intermediário que identifica qual operação a ALU_sf deve executar
    wire [1:0] ALUOp;

    Main_decoder_sf MainDecoder (
        .Op(Op),
        .funct3(funct3),
        .Branch(Branch),
        .ResultSrc(ResultSrc),
        .MemWrite(MemWrite),
        .ALUSrc(ALUSrc),
        .ImmSrc(ImmSrc),
        .RegWrite(RegWrite),
        .Jump(Jump),
        .LoadType(LoadType),
        .StoreType(StoreType),
        .ALUOp(ALUOp)
    );

    ALU_decoder_sf ALUDecoder (
        .ALUOp(ALUOp),
        .funct3(funct3),
        .funct7(funct7),
        .op(Op[5]),
        .ALUControl(ALUControl)
    );

endmodule

// RETIRADO DA TABELA 7.2 NA PÁGINA 408 DA BIBLIOGRAFIA

module Main_decoder_sf (
    input [6:0] Op,          //! Opcode da instrução (bits [6:0])
    input [2:0] funct3,      //! Campo funct3 utilizado para diferenciar cargas e armazenamentos
    output reg Branch,       //! Indica se a instrução é um branch condicional
    output reg [1:0] ResultSrc, //! Seleciona a fonte do dado para Write Back (00=ALU_sf, 01=Memória, 10=PC+4)
    output reg MemWrite,     //! Habilita escrita na memória de dados
    output reg ALUSrc,       //! Seleciona entre registrador (0) e imediato (1) para o operando B da ALU_sf
    output reg [1:0] ImmSrc, //! Define como o imediato deve ser estendido
    output reg RegWrite,     //! Habilita escrita no banco de registradores
    output reg Jump,         //! Indica instrução JAL (desvio incondicional)
    output reg [2:0] LoadType,//! Define o tipo de extensão realizado no dado carregado
    output reg [1:0] StoreType,//! Define o tamanho da escrita na memória
    output reg [1:0] ALUOp   //! Auxilia na escolha da operação da ALU_sf
);

// Instruções possíveis
localparam opcode_load  = 7'b0000011,
           opcode_store = 7'b0100011,
           R_type       = 7'b0110011,
           beq          = 7'b1100011,
           addi         = 7'b0010011, // Instrução ADDI (I-type)
           jal          = 7'b1101111; // Instrução JAL (J-type)

// Tipos de load suportados
localparam LOAD_LB  = 3'b000,
           LOAD_LH  = 3'b001,
           LOAD_LW  = 3'b010,
           LOAD_LBU = 3'b011,
           LOAD_LHU = 3'b100,
           LOAD_NONE= 3'b111;

// Tipos de store suportados
localparam STORE_SB   = 2'b00,
           STORE_SH   = 2'b01,
           STORE_SW   = 2'b10,
           STORE_NONE = 2'b11;

always @(*) begin
    Branch    = 1'b0;
    ResultSrc = 2'b00;
    MemWrite  = 1'b0;
    ALUSrc    = 1'b0;
    ImmSrc    = 2'b00;
    RegWrite  = 1'b0;
    Jump      = 1'b0;
    LoadType  = LOAD_NONE;
    StoreType = STORE_NONE;
    ALUOp     = 2'b00;
    case (Op)
        opcode_load: begin
            RegWrite  = 1'b1;
            ALUSrc    = 1'b1;
            ResultSrc = 2'b01;
            case (funct3)
                3'b000: LoadType = LOAD_LB;
                3'b001: LoadType = LOAD_LH;
                3'b010: LoadType = LOAD_LW;
                3'b100: LoadType = LOAD_LBU;
                3'b101: LoadType = LOAD_LHU;
                default: LoadType = LOAD_NONE;
            endcase
        end
        opcode_store: begin
            ImmSrc   = 2'b01;
            ALUSrc   = 1'b1;
            MemWrite = 1'b1;
            case (funct3)
                3'b000: StoreType = STORE_SB;
                3'b001: StoreType = STORE_SH;
                3'b010: StoreType = STORE_SW;
                default: StoreType = STORE_NONE;
            endcase
        end
        R_type: begin
            RegWrite = 1'b1;
            ALUOp    = 2'b10;
        end
        beq: begin
            ImmSrc = 2'b10;
            Branch = 1'b1;
            ALUOp  = 2'b01;
        end
        addi: begin
            RegWrite = 1'b1;
            ALUSrc   = 1'b1; // Operando B vem do imediato
            // ResultSrc permanece 0 para gravar o resultado da ALU_sf
        end
        jal: begin
            RegWrite  = 1'b1; // Escreve PC+4 no registrador destino
            Jump      = 1'b1; // Desvio incondicional
            ResultSrc = 2'b10; // Seleciona PC+4 para Write Back
            ImmSrc    = 2'b11; // Imediato do tipo J
        end
    endcase
end

endmodule

// RETIRADO DA TABELA 7.3 NA PÁGINA 409 DA BIBLIOGRAFIA

module ALU_decoder_sf (
    input [1:0] ALUOp,
    input [2:0] funct3,
    input       funct7,
    input       op,
    output reg [2:0] ALUControl
);

// Operações possíveis da ALU_sf
localparam ADD = 3'b000,
           SUB = 3'b001,
           AND = 3'b010,
           OR  = 3'b011,
           SLT = 3'b101;

always @(*) begin
    case (ALUOp)
        2'b00: ALUControl = ADD; // instruções lw, sw
        2'b01: ALUControl = SUB; // instrução beq
        2'b10: begin
            case (funct3)
                3'b000: begin
                    if ({op, funct7} == 2'b11) begin
                        ALUControl = SUB; // instrução sub
                    end else begin
                        ALUControl = ADD; // instrução add
                    end
                end
                3'b010: ALUControl = SLT; // instrução slt
                3'b110: ALUControl = OR;  // instrução or
                3'b111: ALUControl = AND; // instrução and
                default: ALUControl = ADD; // caso inválido
            endcase
        end
        default: ALUControl = ADD; // caso inválido
    endcase
end

endmodule

module id_ex_reg_sf (
    input        clk,               //! Sinal de clock
    input        rst,               //! Sinal de reset síncrono
    input        flush,             //! Quando ativo, anula a instrução em execução
    input        RegWrite_in,       //! Controle de escrita no Write Back
    input        MemWrite_in,       //! Controle de escrita na memória de dados
    input  [1:0] ResultSrc_in,      //! Seleção da fonte de dados para Write Back
    input        Branch_in,         //! Indica se a instrução é um branch
    input        Jump_in,           //! Indica se a instrução é um jump (JAL)
    input        ALUSrc_in,         //! Seleção do segundo operando da ALU_sf
    input  [2:0] ALUControl_in,     //! Operação a ser executada pela ALU_sf
    input  [2:0] LoadType_in,       //! Tipo de carga propagado para MEM
    input  [1:0] StoreType_in,      //! Tipo de armazenamento propagado para MEM
    input [31:0] pc_in,             //! PC do estágio ID (utilizado para cálculo de branches)
    input [31:0] pc_plus4_in,       //! PC+4 utilizado para escrita no Write Back (JAL)
    input [31:0] rd1_in,            //! Operando A da ALU_sf
    input [31:0] rd2_in,            //! Operando B (antes da seleção ALUSrc)
    input [31:0] imm_in,            //! Imediato estendido
    input  [4:0] rd_in,             //! Registrador destino
    output reg        RegWrite_out,
    output reg        MemWrite_out,
    output reg [1:0] ResultSrc_out,
    output reg        Branch_out,
    output reg        Jump_out,
    output reg        ALUSrc_out,
    output reg  [2:0] ALUControl_out,
    output reg  [2:0] LoadType_out,
    output reg  [1:0] StoreType_out,
    output reg [31:0] pc_out,
    output reg [31:0] pc_plus4_out,
    output reg [31:0] rd1_out,
    output reg [31:0] rd2_out,
    output reg [31:0] imm_out,
    output reg  [4:0] rd_out
);

    always @(posedge clk) begin
        if (rst || flush) begin
            RegWrite_out   <= 1'b0;
            MemWrite_out   <= 1'b0;
            ResultSrc_out  <= 2'b00;
            Branch_out     <= 1'b0;
            Jump_out       <= 1'b0;
            ALUSrc_out     <= 1'b0;
            ALUControl_out <= 3'b000;
            LoadType_out   <= 3'b111;
            StoreType_out  <= 2'b11;
            pc_out         <= 32'b0;
            pc_plus4_out   <= 32'b0;
            rd1_out        <= 32'b0;
            rd2_out        <= 32'b0;
            imm_out        <= 32'b0;
            rd_out         <= 5'b0;
        end else begin
            RegWrite_out   <= RegWrite_in;
            MemWrite_out   <= MemWrite_in;
            ResultSrc_out  <= ResultSrc_in;
            Branch_out     <= Branch_in;
            Jump_out       <= Jump_in;
            ALUSrc_out     <= ALUSrc_in;
            ALUControl_out <= ALUControl_in;
            LoadType_out   <= LoadType_in;
            StoreType_out  <= StoreType_in;
            pc_out         <= pc_in;
            pc_plus4_out   <= pc_plus4_in;
            rd1_out        <= rd1_in;
            rd2_out        <= rd2_in;
            imm_out        <= imm_in;
            rd_out         <= rd_in;
        end
    end

endmodule

module if_id_reg_sf (
    input        clk,           //! Sinal de clock
    input        rst,           //! Sinal de reset síncrono
    input        flush,         //! Quando ativo, injeta bolha no estágio de decodificação
    input        stall,         //! Mantém o conteúdo atual quando há hazard
    input [31:0] pc_in,         //! Valor de PC do estágio IF
    input [31:0] pc_plus4_in,   //! Valor de PC+4 do estágio IF
    input [31:0] instr_in,      //! Instrução lida na memória
    output reg [31:0] pc_out,   //! PC encaminhado para o estágio ID
    output reg [31:0] pc_plus4_out, //! PC+4 encaminhado para o estágio ID
    output reg [31:0] instr_out //! Instrução encaminhada para o estágio ID
);

    always @(posedge clk) begin
        if (rst || flush) begin
            pc_out    <= 32'b0;
            pc_plus4_out <= 32'b0;
            instr_out <= 32'b0; //! Inserção de NOP
        end else if (!stall) begin
            pc_out    <= pc_in;
            pc_plus4_out <= pc_plus4_in;
            instr_out <= instr_in;
        end
    end

endmodule

module mem_wb_reg_sf (
    input        clk,                //! Sinal de clock
    input        rst,                //! Sinal de reset síncrono
    input        RegWrite_in,        //! Controle de escrita recebido do estágio MEM
    input  [1:0] ResultSrc_in,       //! Seleção da fonte dos dados para Write Back
    input [31:0] ReadData_in,        //! Dado lido da memória de dados
    input [31:0] ALUResult_in,       //! Resultado da ALU_sf
    input [31:0] pc_plus4_in,        //! Valor de PC+4 propagado para Write Back
    input  [4:0] rd_in,              //! Registrador destino
    output reg        RegWrite_out,
    output reg [1:0] ResultSrc_out,
    output reg [31:0] ReadData_out,
    output reg [31:0] ALUResult_out,
    output reg [31:0] pc_plus4_out,
    output reg  [4:0] rd_out
);

    always @(posedge clk) begin
        if (rst) begin
            RegWrite_out  <= 1'b0;
            ResultSrc_out <= 2'b00;
            ReadData_out  <= 32'b0;
            ALUResult_out <= 32'b0;
            pc_plus4_out  <= 32'b0;
            rd_out        <= 5'b0;
        end else begin
            RegWrite_out  <= RegWrite_in;
            ResultSrc_out <= ResultSrc_in;
            ReadData_out  <= ReadData_in;
            ALUResult_out <= ALUResult_in;
            pc_plus4_out  <= pc_plus4_in;
            rd_out        <= rd_in;
        end
    end

endmodule

module instruction_memory_sf (
    input [31:0] A,      //! Endereço de leitura
    output reg [31:0] RD //! Dados lidos da memória de instruções
);

    reg [7:0] memory [0:1023]; //! Memória de instruções byte-addressable

    initial begin
        // Programa de teste: ADDI, JAL, LW, SW e ADD
        memory[10'h0] = 8'h93; // 0x00500093 -> addi x1, x0, 5
        memory[10'h1] = 8'h00;
        memory[10'h2] = 8'h50;
        memory[10'h3] = 8'h00;

        memory[10'h4] = 8'h13; // 0x00100113 -> addi x2, x0, 1
        memory[10'h5] = 8'h01;
        memory[10'h6] = 8'h10;
        memory[10'h7] = 8'h00;

        memory[10'h8] = 8'hEF; // 0x008001EF -> jal x3, +8
        memory[10'h9] = 8'h01;
        memory[10'hA] = 8'h80;
        memory[10'hB] = 8'h00;

        memory[10'hC] = 8'h13; // 0x00510113 -> addi x2, x2, 5 (deve ser pulada pelo JAL)
        memory[10'hD] = 8'h01;
        memory[10'hE] = 8'h51;
        memory[10'hF] = 8'h00;

        memory[10'h10] = 8'h13; // 0x00900213 -> addi x4, x0, 9
        memory[10'h11] = 8'h02;
        memory[10'h12] = 8'h90;
        memory[10'h13] = 8'h00;

        memory[10'h14] = 8'h23; // 0x00102023 -> sw x1, 0(x0)
        memory[10'h15] = 8'h20;
        memory[10'h16] = 8'h10;
        memory[10'h17] = 8'h00;

        memory[10'h18] = 8'h83; // 0x00002283 -> lw x5, 0(x0)
        memory[10'h19] = 8'h22;
        memory[10'h1A] = 8'h00;
        memory[10'h1B] = 8'h00;

        memory[10'h1C] = 8'h13; // 0x00128313 -> addi x6, x5, 1
        memory[10'h1D] = 8'h83;
        memory[10'h1E] = 8'h12;
        memory[10'h1F] = 8'h00;
    end

    always @(*) begin
        RD = {memory[A - 32'h1000 + 3], memory[A - 32'h1000 + 2], memory[A - 32'h1000 + 1], memory[A - 32'h1000 + 0]};
    end

endmodule

module program_counter_sf (
    input wire        clk,     //! Sinal de clock
    input wire        rst,     //! Reset síncrono
    input wire        stall,   //! Mantém o PC quando verdadeiro (bolha por hazard)
    input wire [31:0] PCNext,  //! Próximo valor do PC
    output reg [31:0] PC       //! Valor atual do PC
);

    always @(posedge clk) begin
        if (rst) begin
            PC <= 32'h1000; //! Endereço inicial da memória de instruções
        end else if (!stall) begin
            PC <= PCNext;
        end
    end

endmodule

module register_file_sf (
    input clk,         //! Sinal de clock
    input rst,         //! Sinal de reset
    input WE3,         //! Write enable input
    input [4:0] A1,    //! Endereço do primeiro registrador de leitura
    input [4:0] A2,    //! Endereço do segundo registrador de leitura
    input [4:0] A3,    //! Endereço do registrador de escrita
    input [31:0] WD3,  //! Dados a serem escritos no registrador
    output [31:0] RD1, //! Dados lidos do primeiro registrador
    output [31:0] RD2  //! Dados lidos do segundo registrador
);

    integer i;

    reg [31:0] registers [0:31]; //! Banco de registradores de 32 bits

    // Escrita síncrona
    always @(posedge clk, posedge rst) begin : ESCRITA
        if (rst) begin
            for (i = 0; i < 32; i = i + 1) begin : RESET
                registers[i] <= 32'b0;
            end
        end else if (WE3 && (A3 != 5'd0)) begin
            registers[A3] <= WD3; //! Escreve os dados no registrador especificado
        end
    end

    // Leitura combinacional (assíncrona)
    assign RD1 = (A1 == 5'd0) ? 32'd0 : registers[A1]; // Lê o primeiro registrador
    assign RD2 = (A2 == 5'd0) ? 32'd0 : registers[A2]; // Lê o segundo registrador

endmodule

module extend_sf (
    input [31:7] instr,      //! Instrução a ser processada
    input [1:0]  immsrc,     //! Comando contendo o tipo de extensão a ser realizado
    output reg [31:0] immext //! Saída contendo a extensão da instrução
);

always @(*) begin
    case (immsrc)
        2'b00: immext = { {20{instr[31]}}, instr[31:20] }; // I-type
        2'b01: immext = { {20{instr[31]}}, instr[31:25], instr[11:7] }; // S-type (store)
        2'b10: immext = { {20{instr[31]}}, instr[7], instr[30:25], instr[11:8], 1'b0 }; // B-type (branches)
        2'b11: immext = { {12{instr[31]}}, instr[19:12], instr[20], instr[30:21], 1'b0 }; // J-type (jal)
        default: immext = 32'bx; // undefined
    endcase
end

endmodule

module ALU_sf (
    input [31:0] SrcA,
    input [31:0] SrcB,
    input [2:0] ALUControl,
    output reg [31:0] ALUResult,
    output reg Zero
);

    always @(*) begin
        case (ALUControl)
            3'b000: ALUResult = SrcA + SrcB; // Soma
            3'b001: ALUResult = SrcA - SrcB; // Subtração
            3'b010: ALUResult = SrcA & SrcB; // AND
            3'b011: ALUResult = SrcA | SrcB; // OR
            3'b101: ALUResult = ($signed(SrcA) < $signed(SrcB)) ? 32'd1 : 32'd0; // SLT
            default: ALUResult = 32'd0;
        endcase

        Zero = (ALUResult == 32'd0);
    end

endmodule

module Mux2x1_sf #(parameter N = 8) (
    input [N-1:0] a,
    input [N-1:0] b,
    input sel,
    output [N-1:0] y
);

    assign y = sel ? b : a;

endmodule

module adder_sf (
    input wire [31:0] a,
    input wire [31:0] b,
    output wire [31:0] sum
);

    assign sum = a + b;

endmodule

module memByteAddressable32WF_sf #(
    parameter DATA_WIDTH    = 32, //! Largura total da palavra
    parameter ADDRESS_WIDTH = 8   //! Endereço em bytes (2^8 = 256 bytes)
) (
    input  wire                     clk,        //! Clock da memória de dados
    input  wire [3:0]               byteEnable, //! Máscara de habilitação por byte
    input  wire [ADDRESS_WIDTH-1:0] addr,       //! Endereço em bytes
    input  wire [DATA_WIDTH-1:0]    din,        //! Dado de entrada (escrita)
    output wire [DATA_WIDTH-1:0]    dout        //! Dado de saída (leitura)
);

    localparam WORD_ADDR_WIDTH = (ADDRESS_WIDTH > 2) ? (ADDRESS_WIDTH-2) : 1; //! Endereço por palavras (4 bytes)
    wire [WORD_ADDR_WIDTH-1:0] word_addr = addr[ADDRESS_WIDTH-1:2]; //! Converte endereço em bytes para palavras

    memory_write_first_sf #(.DATA_WIDTH(8), .ADDRESS_WIDTH(WORD_ADDR_WIDTH)) mem_byte0 (
        .clk(clk),
        .we(byteEnable[0]),
        .addr(word_addr),
        .din(din[7:0]),
        .dout(dout[7:0])
    );

    memory_write_first_sf #(.DATA_WIDTH(8), .ADDRESS_WIDTH(WORD_ADDR_WIDTH)) mem_byte1 (
        .clk(clk),
        .we(byteEnable[1]),
        .addr(word_addr),
        .din(din[15:8]),
        .dout(dout[15:8])
    );

    memory_write_first_sf #(.DATA_WIDTH(8), .ADDRESS_WIDTH(WORD_ADDR_WIDTH)) mem_byte2 (
        .clk(clk),
        .we(byteEnable[2]),
        .addr(word_addr),
        .din(din[23:16]),
        .dout(dout[23:16])
    );

    memory_write_first_sf #(.DATA_WIDTH(8), .ADDRESS_WIDTH(WORD_ADDR_WIDTH)) mem_byte3 (
        .clk(clk),
        .we(byteEnable[3]),
        .addr(word_addr),
        .din(din[31:24]),
        .dout(dout[31:24])
    );

endmodule

module memory_write_first_sf #(
    parameter DATA_WIDTH = 8,          //! Largura dos dados (em bits)
    parameter ADDRESS_WIDTH = 4        //! Número de bits do endereço
) (
    input  wire                     clk,  //! Clock da memória
    input  wire                     we,   //! Habilitação de escrita
    input  wire [ADDRESS_WIDTH-1:0] addr, //! Endereço da palavra
    input  wire [DATA_WIDTH-1:0]    din,  //! Dado de entrada
    output wire [DATA_WIDTH-1:0]    dout  //! Dado de saída (leitura assíncrona)
);

    localparam DEPTH = 1 << ADDRESS_WIDTH; //! Número total de posições na memória

    reg [DATA_WIDTH-1:0] mem [0:DEPTH-1]; //! Array que armazena os dados
    integer init_idx; //! Índice auxiliar para inicialização

    initial begin
        for (init_idx = 0; init_idx < DEPTH; init_idx = init_idx + 1) begin
            mem[init_idx] = {DATA_WIDTH{1'b0}}; //! Garante memória zerada e evita valores indefinidos
        end
    end

    always @(posedge clk) begin
        if (we) begin
            mem[addr] <= din; //! Escrita síncrona
        end
    end

    assign dout = mem[addr]; //! Leitura assíncrona (write-first devido ao uso de atribuição não bloqueante)

endmodule
