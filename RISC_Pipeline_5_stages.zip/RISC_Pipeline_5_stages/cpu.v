module cpu (
    input clk, //! Sinal de clock
    input rst  //! Sinal de reset
);

    /* Declaração dos sinais de interconexão entre os blocos */
    wire        Branch;       //! Indica instrução de branch
    wire [1:0]  ResultSrc;    //! Seleção da fonte para Write Back (ALU/Mem/PC+4)
    wire        MemWrite;     //! Habilita escrita na memória de dados
    wire        ALUSrc;       //! Seleciona imediato como operando B da ALU
    wire        RegWrite;     //! Habilita escrita no banco de registradores
    wire [1:0]  ImmSrc;       //! Seleciona extensão do imediato
    wire        Jump;         //! Indica instrução JAL
    wire [2:0]  LoadType;     //! Define ajuste de sinal/zero para leituras de memória
    wire [1:0]  StoreType;    //! Define o tamanho da escrita em memória
    wire [2:0]  ALUControl;   //! Operação executada pela ALU
    wire        funct7;       //! Bit 30 da instrução em ID
    wire [2:0]  funct3;       //! Campo funct3 em ID
    wire [6:0]  op;           //! Opcode da instrução em ID

    /* Datapath pipeline */
    datapath DATAPATH (
        .clk(clk),
        .rst(rst),
        .Branch(Branch),
        .ResultSrc(ResultSrc),
        .MemWrite(MemWrite),
        .ALUSrc(ALUSrc),
        .RegWrite(RegWrite),
        .ImmSrc(ImmSrc),
        .ALUControl(ALUControl),
        .funct7(funct7),
        .funct3(funct3),
        .op(op),
        .Jump(Jump),
        .LoadType(LoadType),
        .StoreType(StoreType)
    );

    /* Unidade de controle reaproveitada do processador single-cycle */
    Control_Unit CONTROL_UNIT (
        .Op(op),
        .funct3(funct3),
        .funct7(funct7),
        .Branch(Branch),
        .ResultSrc(ResultSrc),
        .MemWrite(MemWrite),
        .ALUSrc(ALUSrc),
        .ImmSrc(ImmSrc),
        .RegWrite(RegWrite),
        .Jump(Jump),
        .LoadType(LoadType),
        .StoreType(StoreType),
        .ALUControl(ALUControl)
    );

endmodule
