`timescale 1ns/1ps

module tb_cpu_pipeline_full_memory;
    reg clk = 0;
    reg rst = 1;

    cpu uut (
        .clk(clk),
        .rst(rst)
    );

    always #5 clk = ~clk;

    reg [31:0] program_words [0:16];
    reg [4:0]  expected_rd   [0:8];
    reg [31:0] expected_val  [0:8];

    integer i;
    integer write_index = 0;
    integer error_count = 0;
    integer cycle_count = 0;
    string  event_msg;

    task automatic load_instruction(input integer word_idx, input [31:0] value);
        integer base;
        begin
            base = word_idx * 4;
            uut.DATAPATH.INSTRUCTION_MEMORY.memory[base + 0] = value[7:0];
            uut.DATAPATH.INSTRUCTION_MEMORY.memory[base + 1] = value[15:8];
            uut.DATAPATH.INSTRUCTION_MEMORY.memory[base + 2] = value[23:16];
            uut.DATAPATH.INSTRUCTION_MEMORY.memory[base + 3] = value[31:24];
        end
    endtask

    task automatic set_data_byte(input integer byte_addr, input [7:0] value);
        integer word_addr;
        begin
            word_addr = byte_addr >> 2;
            case (byte_addr[1:0])
                2'b00: uut.DATAPATH.DATA_MEMORY.mem_byte0.mem[word_addr] = value;
                2'b01: uut.DATAPATH.DATA_MEMORY.mem_byte1.mem[word_addr] = value;
                2'b10: uut.DATAPATH.DATA_MEMORY.mem_byte2.mem[word_addr] = value;
                default: uut.DATAPATH.DATA_MEMORY.mem_byte3.mem[word_addr] = value;
            endcase
        end
    endtask

    function automatic [7:0] get_data_byte(input integer byte_addr);
        integer word_addr;
        begin
            word_addr = byte_addr >> 2;
            case (byte_addr[1:0])
                2'b00: get_data_byte = uut.DATAPATH.DATA_MEMORY.mem_byte0.mem[word_addr];
                2'b01: get_data_byte = uut.DATAPATH.DATA_MEMORY.mem_byte1.mem[word_addr];
                2'b10: get_data_byte = uut.DATAPATH.DATA_MEMORY.mem_byte2.mem[word_addr];
                default: get_data_byte = uut.DATAPATH.DATA_MEMORY.mem_byte3.mem[word_addr];
            endcase
        end
    endfunction

    initial begin
        error_count = 0;
        program_words[0]  = 32'h00000293;
        program_words[1]  = 32'h01000313;
        program_words[2]  = 32'h00028383;
        program_words[3]  = 32'h0002ce03;
        program_words[4]  = 32'h00229e83;
        program_words[5]  = 32'h0022df03;
        program_words[6]  = 32'h0042af83;
        program_words[7]  = 32'h00730023;
        program_words[8]  = 32'h01c300a3;
        program_words[9]  = 32'h01d31123;
        program_words[10] = 32'h01e31223;
        program_words[11] = 32'h01f32423;
        program_words[12] = 32'h07f00393;
        program_words[13] = 32'h00730623;
        program_words[14] = 32'hffe00e13;
        program_words[15] = 32'h01c31723;
        program_words[16] = 32'h0000006f;

        for (i = 0; i <= 16; i = i + 1) begin
            load_instruction(i, program_words[i]);
        end

        set_data_byte(0, 8'h12);
        set_data_byte(1, 8'h34);
        set_data_byte(2, 8'h78);
        set_data_byte(3, 8'h56);
        set_data_byte(4, 8'hf0);
        set_data_byte(5, 8'hde);
        set_data_byte(6, 8'hbc);
        set_data_byte(7, 8'h9a);

        for (i = 16; i < 32; i = i + 1) begin
            set_data_byte(i, 8'h00);
        end

        repeat (4) @(posedge clk);
        rst = 0;

        $display("\n+-----------------------------------------------------------------------------------------------------------------+");
        $display("| Cycle |    PC    |   t0(x5) |   t1(x6) |   t2(x7) |  t3(x28) |  t4(x29) |  t5(x30) |  t6(x31) | %-45s |", "Event details");
        $display("+-------+----------+----------+----------+----------+----------+----------+----------+----------+---------------------------------------------+");

        repeat (240) @(posedge clk);

        if (write_index != 9) begin
            error_count = error_count + 1;
            $error("Falha: esperadas 9 escritas válidas no estágio WB, obtidas %0d", write_index);
        end

        if (uut.DATAPATH.REGISTER_FILE.registers[5] !== 32'h00000000) begin
            error_count = error_count + 1;
            $error("Falha: t0 (x5) deveria ser 0, obtido %h", uut.DATAPATH.REGISTER_FILE.registers[5]);
        end
        if (uut.DATAPATH.REGISTER_FILE.registers[6] !== 32'h00000010) begin
            error_count = error_count + 1;
            $error("Falha: t1 (x6) deveria ser 16, obtido %h", uut.DATAPATH.REGISTER_FILE.registers[6]);
        end
        if (uut.DATAPATH.REGISTER_FILE.registers[29] !== 32'h00005678) begin
            error_count = error_count + 1;
            $error("Falha: t4 (x29) deveria ser 0x00005678, obtido %h", uut.DATAPATH.REGISTER_FILE.registers[29]);
        end
        if (uut.DATAPATH.REGISTER_FILE.registers[30] !== 32'h00005678) begin
            error_count = error_count + 1;
            $error("Falha: t5 (x30) deveria ser 0x00005678, obtido %h", uut.DATAPATH.REGISTER_FILE.registers[30]);
        end
        if (uut.DATAPATH.REGISTER_FILE.registers[31] !== 32'h9abcdef0) begin
            error_count = error_count + 1;
            $error("Falha: t6 (x31) deveria ser 0x9abcdef0, obtido %h", uut.DATAPATH.REGISTER_FILE.registers[31]);
        end
        if (uut.DATAPATH.REGISTER_FILE.registers[7] !== 32'h0000007f) begin
            error_count = error_count + 1;
            $error("Falha: t2 (x7) deveria ser 0x0000007f após os stores, obtido %h", uut.DATAPATH.REGISTER_FILE.registers[7]);
        end
        if (uut.DATAPATH.REGISTER_FILE.registers[28] !== 32'hfffffffe) begin
            error_count = error_count + 1;
            $error("Falha: t3 (x28) deveria ser 0xfffffffe após os stores, obtido %h", uut.DATAPATH.REGISTER_FILE.registers[28]);
        end

        if (get_data_byte(16) !== 8'h12) begin
            error_count = error_count + 1;
            $error("Falha: sb t2,0(t1) deveria gravar 0x12 em 0x10");
        end
        if (get_data_byte(17) !== 8'h12) begin
            error_count = error_count + 1;
            $error("Falha: sb t3,1(t1) deveria gravar 0x12 em 0x11");
        end
        if (get_data_byte(18) !== 8'h78 || get_data_byte(19) !== 8'h56) begin
            error_count = error_count + 1;
            $error("Falha: sh t4,2(t1) deveria gravar 0x5678 em little-endian em 0x12-0x13");
        end
        if (get_data_byte(20) !== 8'h78 || get_data_byte(21) !== 8'h56) begin
            error_count = error_count + 1;
            $error("Falha: sh t5,4(t1) deveria gravar 0x5678 em little-endian em 0x14-0x15");
        end
        if (get_data_byte(24) !== 8'hf0 || get_data_byte(25) !== 8'hde ||
            get_data_byte(26) !== 8'hbc || get_data_byte(27) !== 8'h9a) begin
            error_count = error_count + 1;
            $error("Falha: sw t6,8(t1) deveria gravar 0x9ABCDEF0 em 0x18-0x1B");
        end
        if (get_data_byte(28) !== 8'h7f) begin
            error_count = error_count + 1;
            $error("Falha: sb t2,12(t1) deveria gravar 0x7f em 0x1C");
        end
        if (get_data_byte(30) !== 8'hfe || get_data_byte(31) !== 8'hff) begin
            error_count = error_count + 1;
            $error("Falha: sh t3,14(t1) deveria gravar 0xFFFE em 0x1E-0x1F");
        end

        $display("+-------+----------+----------+----------+----------+----------+----------+----------+----------+---------------------------------------------+");
        $display("|                                   Memória store_area (0x10 - 0x1F)                |");
        $display("+--------+------+------+------+------+");
        $display("| End.   | +0  | +1  | +2  | +3  |");
        $display("+--------+------+------+------+------+");
        for (i = 0; i < 16; i = i + 4) begin
            $display("| 0x%02h  |  %02h  |  %02h  |  %02h  |  %02h  |",
                     8'h10 + i,
                     get_data_byte(16 + i + 0),
                     get_data_byte(16 + i + 1),
                     get_data_byte(16 + i + 2),
                     get_data_byte(16 + i + 3));
        end
        $display("+--------+------+------+------+------+" );

        $display("Programa de load/store executado em t=%0t com %0d erro(s)", $time, error_count);
        $finish;
    end

    initial begin
        expected_rd[0]  = 5;  expected_val[0]  = 32'h00000000;
        expected_rd[1]  = 6;  expected_val[1]  = 32'h00000010;
        expected_rd[2]  = 7;  expected_val[2]  = 32'h00000012;
        expected_rd[3]  = 28; expected_val[3]  = 32'h00000012;
        expected_rd[4]  = 29; expected_val[4]  = 32'h00005678;
        expected_rd[5]  = 30; expected_val[5]  = 32'h00005678;
        expected_rd[6]  = 31; expected_val[6]  = 32'h9abcdef0;
        expected_rd[7]  = 7;  expected_val[7]  = 32'h0000007f;
        expected_rd[8]  = 28; expected_val[8]  = 32'hfffffffe;
    end

    always @(posedge clk) begin
        if (rst) begin
            cycle_count = 0;
        end else begin
            cycle_count = cycle_count + 1;

            $write("| %5d | %08h | %08h | %08h | %08h | %08h | %08h | %08h | %08h |",
                   cycle_count,
                   uut.DATAPATH.pc,
                   uut.DATAPATH.REGISTER_FILE.registers[5],
                   uut.DATAPATH.REGISTER_FILE.registers[6],
                   uut.DATAPATH.REGISTER_FILE.registers[7],
                   uut.DATAPATH.REGISTER_FILE.registers[28],
                   uut.DATAPATH.REGISTER_FILE.registers[29],
                   uut.DATAPATH.REGISTER_FILE.registers[30],
                   uut.DATAPATH.REGISTER_FILE.registers[31]);

            if (uut.DATAPATH.id_ex_MemWrite) begin
                event_msg = $sformatf("store %s (addr=0x%02h, be=%b, dado=%08h)",
                                      (uut.DATAPATH.id_ex_StoreType == 2'd0) ? "SB" :
                                      (uut.DATAPATH.id_ex_StoreType == 2'd1) ? "SH" : "SW",
                                      uut.DATAPATH.alu_result[7:0],
                                      uut.DATAPATH.byte_enable,
                                      uut.DATAPATH.store_data);

                if (uut.DATAPATH.mem_wb_RegWrite && uut.DATAPATH.mem_wb_rd != 5'd0) begin
                    event_msg = $sformatf("%s; wb x%0d <= %08h (src=%0d)",
                                          event_msg,
                                          uut.DATAPATH.mem_wb_rd,
                                          uut.DATAPATH.wb_data,
                                          uut.DATAPATH.mem_wb_ResultSrc);
                end
            end else if (uut.DATAPATH.mem_wb_RegWrite && uut.DATAPATH.mem_wb_rd != 5'd0) begin
                event_msg = $sformatf("wb  x%0d <= %08h (src=%0d)",
                                      uut.DATAPATH.mem_wb_rd,
                                      uut.DATAPATH.wb_data,
                                      uut.DATAPATH.mem_wb_ResultSrc);
            end else begin
                event_msg = "pipeline busy";
            end

            if (event_msg.len() > 45) begin
                event_msg = {event_msg.substr(0, 42), "..."};
            end

            $display(" %-45s |", event_msg);
        end

        if (!rst && uut.DATAPATH.mem_wb_RegWrite) begin
            if (uut.DATAPATH.mem_wb_rd != 5'd0) begin
                if (write_index > 8) begin
                    error_count = error_count + 1;
                    $error("Falha: escritas extras detectadas em rd=%0d val=%h", uut.DATAPATH.mem_wb_rd, uut.DATAPATH.wb_data);
                end else begin
                    if (uut.DATAPATH.mem_wb_rd !== expected_rd[write_index]) begin
                        error_count = error_count + 1;
                        $error("Falha: esperado rd=%0d na escrita #%0d, obtido %0d", expected_rd[write_index], write_index + 1, uut.DATAPATH.mem_wb_rd);
                    end
                    if (uut.DATAPATH.wb_data !== expected_val[write_index]) begin
                        error_count = error_count + 1;
                        $error("Falha: esperado valor %h na escrita #%0d, obtido %h", expected_val[write_index], write_index + 1, uut.DATAPATH.wb_data);
                    end
                end
                write_index = write_index + 1;
            end
        end
    end
endmodule
