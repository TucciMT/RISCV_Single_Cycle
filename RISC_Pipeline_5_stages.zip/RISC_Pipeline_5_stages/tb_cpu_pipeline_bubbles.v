`timescale 1ns/1ps

module tb_cpu_pipeline_bubbles;
    reg clk = 0;
    reg rst = 1;

    cpu uut (
        .clk(clk),
        .rst(rst)
    );

    always #5 clk = ~clk;

    integer i;
    integer x5_writes;
    integer x6_writes;
    integer x6_total_writes;
    integer x28_writes;
    integer running_sum;
    reg success;
    reg [31:0] write_val;
    integer error_count;

    reg [31:0] program_words [0:12];
    reg [31:0] data_values   [0:9];

    task automatic load_instruction(input integer word_idx, input [31:0] value);
        integer base;
        begin
            base = word_idx * 4;
            uut.DATAPATH.INSTRUCTION_MEMORY.memory[base + 0] = value[7:0];
            uut.DATAPATH.INSTRUCTION_MEMORY.memory[base + 1] = value[15:8];
            uut.DATAPATH.INSTRUCTION_MEMORY.memory[base + 2] = value[23:16];
            uut.DATAPATH.INSTRUCTION_MEMORY.memory[base + 3] = value[31:24];
        end
    endtask

    task automatic load_data_word(input integer word_idx, input [31:0] value);
        begin
            uut.DATAPATH.DATA_MEMORY.mem_byte0.mem[word_idx] = value[7:0];
            uut.DATAPATH.DATA_MEMORY.mem_byte1.mem[word_idx] = value[15:8];
            uut.DATAPATH.DATA_MEMORY.mem_byte2.mem[word_idx] = value[23:16];
            uut.DATAPATH.DATA_MEMORY.mem_byte3.mem[word_idx] = value[31:24];
        end
    endtask

    initial begin
        program_words[0]  = 32'h00a00293; // addi x5, x0, 10
        program_words[1]  = 32'h00000313; // addi x6, x0, 0
        program_words[2]  = 32'h00000393; // addi x7, x0, 0
        program_words[3]  = 32'h02028063; // beq x5, x0, end
        program_words[4]  = 32'h0003ae03; // lw x28, 0(x7)
        program_words[5]  = 32'h00000013; // nop (bubble 1)
        program_words[6]  = 32'h00000013; // nop (bubble 2)
        program_words[7]  = 32'h01c30333; // add x6, x6, x28
        program_words[8]  = 32'h00438393; // addi x7, x7, 4
        program_words[9]  = 32'hfff28293; // addi x5, x5, -1
        program_words[10] = 32'hfe0002e3; // beq x0, x0, loop
        program_words[11] = 32'h00000013; // nop (end)
        program_words[12] = 32'hfc0008e3; // beq x0, x0, start

        data_values[0] = 32'd1;
        data_values[1] = 32'd2;
        data_values[2] = 32'd3;
        data_values[3] = 32'd4;
        data_values[4] = 32'd5;
        data_values[5] = 32'd6;
        data_values[6] = 32'd7;
        data_values[7] = 32'd8;
        data_values[8] = 32'd9;
        data_values[9] = 32'd10;

        for (i = 0; i <= 12; i = i + 1) begin
            load_instruction(i, program_words[i]);
        end

        for (i = 0; i < 10; i = i + 1) begin
            load_data_word(i, data_values[i]);
        end

        #20;
        rst = 0;

        repeat (800) @(posedge clk);
        if (!success) begin
            error_count = error_count + 1;
            $error("Timeout: soma não completada dentro do número de ciclos esperado");
        end
        $display("Teste com bolhas encerrado em t=%0t com %0d erro(s)", $time, error_count);
        $finish;
    end

    initial begin
        x5_writes  = 0;
        x6_writes  = 0;
        x6_total_writes = 0;
        x28_writes = 0;
        running_sum = 0;
        success    = 0;
        write_val  = 0;
        error_count = 0;
    end

    always @(posedge clk) begin
        if (rst) begin
            x5_writes  <= 0;
            x6_writes  <= 0;
            x6_total_writes <= 0;
            x28_writes <= 0;
            running_sum <= 0;
            success    <= 0;
            write_val  <= 0;
            error_count <= 0;
        end else begin
            $display("t=%0t | PC=%h | x5=%h x6=%h x7=%h", $time,
                     uut.DATAPATH.PROGRAM_COUNTER.PC,
                     uut.DATAPATH.REGISTER_FILE.registers[5],
                     uut.DATAPATH.REGISTER_FILE.registers[6],
                     uut.DATAPATH.REGISTER_FILE.registers[7]);

            if (uut.DATAPATH.MEM_WB.RegWrite_out) begin
                write_val = uut.DATAPATH.wb_data;

                case (uut.DATAPATH.MEM_WB.rd_out)
                    5'd5: begin
                        integer expected_val;
                        if (x5_writes == 0) begin
                            expected_val = 10;
                        end else begin
                            expected_val = 10 - x5_writes;
                        end

                        if (write_val !== expected_val) begin
                            error_count = error_count + 1;
                            $error("Falha: esperado x5=%0d, obtido %0d na escrita #%0d", expected_val, write_val, x5_writes);
                        end

                        x5_writes <= x5_writes + 1;

                        if (write_val == 0) begin
                            if (running_sum !== 55) begin
                                error_count = error_count + 1;
                                $error("Falha: soma final esperada 55, obtido %0d", running_sum);
                            end
                            if (x6_writes !== 10) begin
                                error_count = error_count + 1;
                                $error("Falha: esperadas 10 escritas em x6, obtido %0d", x6_writes);
                            end
                            if (x28_writes !== 10) begin
                                error_count = error_count + 1;
                                $error("Falha: esperadas 10 escritas em x28, obtido %0d", x28_writes);
                            end
                            if (uut.DATAPATH.REGISTER_FILE.registers[6] !== 32'd55) begin
                                error_count = error_count + 1;
                                $error("Falha: x6 deveria conter 55, obtido %0d", uut.DATAPATH.REGISTER_FILE.registers[6]);
                            end
                            if (uut.DATAPATH.REGISTER_FILE.registers[7] !== 32'd40) begin
                                error_count = error_count + 1;
                                $error("Falha: x7 deveria conter 40, obtido %0d", uut.DATAPATH.REGISTER_FILE.registers[7]);
                            end
                            if (uut.DATAPATH.REGISTER_FILE.registers[28] !== data_values[9]) begin
                                error_count = error_count + 1;
                                $error("Falha: x28 deveria conter último valor carregado (10), obtido %0d", uut.DATAPATH.REGISTER_FILE.registers[28]);
                            end
                            success = 1;
                            $display("Teste com bolhas concluído em t=%0t com %0d erro(s)", $time, error_count);
                            $finish;
                        end
                    end
                    5'd6: begin
                        integer expected_sum;
                        reg [31:0] instr_addr;
                        instr_addr = uut.DATAPATH.MEM_WB.pc_plus4_out - 32'd4;

                        if (instr_addr == 32'h00001004) begin
                            if (write_val !== 0) begin
                                error_count = error_count + 1;
                                $error("Falha: esperado x6=0 na inicialização, obtido %0d", write_val);
                            end
                        end else begin
                            if (x6_writes >= 10) begin
                                error_count = error_count + 1;
                                $error("Falha: escritas extras detectadas em x6");
                            end else begin
                                expected_sum = running_sum + data_values[x6_writes];
                                if (write_val !== expected_sum) begin
                                    error_count = error_count + 1;
                                    $error("Falha: esperado x6=%0d, obtido %0d na escrita #%0d", expected_sum, write_val, x6_writes + 1);
                                    running_sum <= write_val;
                                end else begin
                                    running_sum <= expected_sum;
                                end
                                x6_writes   <= x6_writes + 1;
                            end
                        end

                        x6_total_writes <= x6_total_writes + 1;
                    end
                    5'd28: begin
                        if (x28_writes >= 10) begin
                            error_count = error_count + 1;
                            $error("Falha: escritas extras detectadas em x28");
                        end else begin
                            if (write_val !== data_values[x28_writes]) begin
                                error_count = error_count + 1;
                                $error("Falha: esperado x28=%0d, obtido %0d", data_values[x28_writes], write_val);
                            end
                            x28_writes <= x28_writes + 1;
                        end
                    end
                    default: begin
                    end
                endcase
            end
        end
    end
endmodule
