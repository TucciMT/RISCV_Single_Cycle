module Control_Unit (
    input  [6:0] Op,          //! Campo opcode da instrução
    input  [2:0] funct3,      //! Campo funct3 da instrução
    input        funct7,      //! Bit mais significativo do campo funct7 da instrução
    output       Branch,      //! Indica se a instrução é um branch condicional
    output [1:0] ResultSrc,   //! Seleciona a fonte de dados para Write Back (ALU, Memória ou PC+4)
    output       MemWrite,    //! Habilita escrita na memória de dados
    output       ALUSrc,      //! Seleciona entre operando do registrador ou imediato para a ALU
    output [1:0] ImmSrc,      //! Define o tipo de extensão a ser aplicado ao imediato
    output       RegWrite,    //! Habilita escrita no banco de registradores
    output       Jump,        //! Indica instrução JAL (desvio incondicional)
    output [2:0] LoadType,    //! Define como os dados carregados devem ser ajustados (sinal/zero)
    output [1:0] StoreType,   //! Define o tamanho da escrita na memória de dados
    output [2:0] ALUControl   //! Define a operação realizada pela ALU
);

    //! Sinal intermediário que identifica qual operação a ALU deve executar
    wire [1:0] ALUOp;

    Main_decoder MainDecoder (
        .Op(Op),
        .funct3(funct3),
        .Branch(Branch),
        .ResultSrc(ResultSrc),
        .MemWrite(MemWrite),
        .ALUSrc(ALUSrc),
        .ImmSrc(ImmSrc),
        .RegWrite(RegWrite),
        .Jump(Jump),
        .LoadType(LoadType),
        .StoreType(StoreType),
        .ALUOp(ALUOp)
    );

    ALU_decoder ALUDecoder (
        .ALUOp(ALUOp),
        .funct3(funct3),
        .funct7(funct7),
        .op(Op[5]),
        .ALUControl(ALUControl)
    );

endmodule
