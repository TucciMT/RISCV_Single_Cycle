// RETIRADO DA TABELA 7.2 NA PÁGINA 408 DA BIBLIOGRAFIA

module Main_decoder (
    input [6:0] Op,          //! Opcode da instrução (bits [6:0])
    input [2:0] funct3,      //! Campo funct3 utilizado para diferenciar cargas e armazenamentos
    output reg Branch,       //! Indica se a instrução é um branch condicional
    output reg [1:0] ResultSrc, //! Seleciona a fonte do dado para Write Back (00=ALU, 01=Memória, 10=PC+4)
    output reg MemWrite,     //! Habilita escrita na memória de dados
    output reg ALUSrc,       //! Seleciona entre registrador (0) e imediato (1) para o operando B da ALU
    output reg [1:0] ImmSrc, //! Define como o imediato deve ser estendido
    output reg RegWrite,     //! Habilita escrita no banco de registradores
    output reg Jump,         //! Indica instrução JAL (desvio incondicional)
    output reg [2:0] LoadType,//! Define o tipo de extensão realizado no dado carregado
    output reg [1:0] StoreType,//! Define o tamanho da escrita na memória
    output reg [1:0] ALUOp   //! Auxilia na escolha da operação da ALU
);

// Instruções possíveis
localparam opcode_load  = 7'b0000011,
           opcode_store = 7'b0100011,
           R_type       = 7'b0110011,
           beq          = 7'b1100011,
           addi         = 7'b0010011, // Instrução ADDI (I-type)
           jal          = 7'b1101111; // Instrução JAL (J-type)

// Tipos de load suportados
localparam LOAD_LB  = 3'b000,
           LOAD_LH  = 3'b001,
           LOAD_LW  = 3'b010,
           LOAD_LBU = 3'b011,
           LOAD_LHU = 3'b100,
           LOAD_NONE= 3'b111;

// Tipos de store suportados
localparam STORE_SB   = 2'b00,
           STORE_SH   = 2'b01,
           STORE_SW   = 2'b10,
           STORE_NONE = 2'b11;

always @(*) begin
    Branch    = 1'b0;
    ResultSrc = 2'b00;
    MemWrite  = 1'b0;
    ALUSrc    = 1'b0;
    ImmSrc    = 2'b00;
    RegWrite  = 1'b0;
    Jump      = 1'b0;
    LoadType  = LOAD_NONE;
    StoreType = STORE_NONE;
    ALUOp     = 2'b00;
    case (Op)
        opcode_load: begin
            RegWrite  = 1'b1;
            ALUSrc    = 1'b1;
            ResultSrc = 2'b01;
            case (funct3)
                3'b000: LoadType = LOAD_LB;
                3'b001: LoadType = LOAD_LH;
                3'b010: LoadType = LOAD_LW;
                3'b100: LoadType = LOAD_LBU;
                3'b101: LoadType = LOAD_LHU;
                default: LoadType = LOAD_NONE;
            endcase
        end
        opcode_store: begin
            ImmSrc   = 2'b01;
            ALUSrc   = 1'b1;
            MemWrite = 1'b1;
            case (funct3)
                3'b000: StoreType = STORE_SB;
                3'b001: StoreType = STORE_SH;
                3'b010: StoreType = STORE_SW;
                default: StoreType = STORE_NONE;
            endcase
        end
        R_type: begin
            RegWrite = 1'b1;
            ALUOp    = 2'b10;
        end
        beq: begin
            ImmSrc = 2'b10;
            Branch = 1'b1;
            ALUOp  = 2'b01;
        end
        addi: begin
            RegWrite = 1'b1;
            ALUSrc   = 1'b1; // Operando B vem do imediato
            // ResultSrc permanece 0 para gravar o resultado da ALU
        end
        jal: begin
            RegWrite  = 1'b1; // Escreve PC+4 no registrador destino
            Jump      = 1'b1; // Desvio incondicional
            ResultSrc = 2'b10; // Seleciona PC+4 para Write Back
            ImmSrc    = 2'b11; // Imediato do tipo J
        end
    endcase
end

endmodule
