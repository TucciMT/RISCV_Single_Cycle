module id_ex_reg (
    input        clk,               //! Sinal de clock
    input        rst,               //! Sinal de reset síncrono
    input        flush,             //! Quando ativo, anula a instrução em execução
    input        RegWrite_in,       //! Controle de escrita no Write Back
    input        MemWrite_in,       //! Controle de escrita na memória de dados
    input  [1:0] ResultSrc_in,      //! Seleção da fonte de dados para Write Back
    input        Branch_in,         //! Indica se a instrução é um branch
    input        Jump_in,           //! Indica se a instrução é um jump (JAL)
    input        ALUSrc_in,         //! Seleção do segundo operando da ALU
    input  [2:0] ALUControl_in,     //! Operação a ser executada pela ALU
    input  [2:0] LoadType_in,       //! Tipo de carga propagado para MEM
    input  [1:0] StoreType_in,      //! Tipo de armazenamento propagado para MEM
    input [31:0] pc_in,             //! PC do estágio ID (utilizado para cálculo de branches)
    input [31:0] pc_plus4_in,       //! PC+4 utilizado para escrita no Write Back (JAL)
    input [31:0] rd1_in,            //! Operando A da ALU
    input [31:0] rd2_in,            //! Operando B (antes da seleção ALUSrc)
    input [31:0] imm_in,            //! Imediato estendido
    input  [4:0] rd_in,             //! Registrador destino
    output reg        RegWrite_out,
    output reg        MemWrite_out,
    output reg [1:0] ResultSrc_out,
    output reg        Branch_out,
    output reg        Jump_out,
    output reg        ALUSrc_out,
    output reg  [2:0] ALUControl_out,
    output reg  [2:0] LoadType_out,
    output reg  [1:0] StoreType_out,
    output reg [31:0] pc_out,
    output reg [31:0] pc_plus4_out,
    output reg [31:0] rd1_out,
    output reg [31:0] rd2_out,
    output reg [31:0] imm_out,
    output reg  [4:0] rd_out
);

    always @(posedge clk) begin
        if (rst || flush) begin
            RegWrite_out   <= 1'b0;
            MemWrite_out   <= 1'b0;
            ResultSrc_out  <= 2'b00;
            Branch_out     <= 1'b0;
            Jump_out       <= 1'b0;
            ALUSrc_out     <= 1'b0;
            ALUControl_out <= 3'b000;
            LoadType_out   <= 3'b111;
            StoreType_out  <= 2'b11;
            pc_out         <= 32'b0;
            pc_plus4_out   <= 32'b0;
            rd1_out        <= 32'b0;
            rd2_out        <= 32'b0;
            imm_out        <= 32'b0;
            rd_out         <= 5'b0;
        end else begin
            RegWrite_out   <= RegWrite_in;
            MemWrite_out   <= MemWrite_in;
            ResultSrc_out  <= ResultSrc_in;
            Branch_out     <= Branch_in;
            Jump_out       <= Jump_in;
            ALUSrc_out     <= ALUSrc_in;
            ALUControl_out <= ALUControl_in;
            LoadType_out   <= LoadType_in;
            StoreType_out  <= StoreType_in;
            pc_out         <= pc_in;
            pc_plus4_out   <= pc_plus4_in;
            rd1_out        <= rd1_in;
            rd2_out        <= rd2_in;
            imm_out        <= imm_in;
            rd_out         <= rd_in;
        end
    end

endmodule
