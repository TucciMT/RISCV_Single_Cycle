module memByteAddressable32WF #(
    parameter DATA_WIDTH    = 32, //! Largura total da palavra
    parameter ADDRESS_WIDTH = 8   //! Endereço em bytes (2^8 = 256 bytes)
) (
    input  wire                     clk,        //! Clock da memória de dados
    input  wire [3:0]               byteEnable, //! Máscara de habilitação por byte
    input  wire [ADDRESS_WIDTH-1:0] addr,       //! Endereço em bytes
    input  wire [DATA_WIDTH-1:0]    din,        //! Dado de entrada (escrita)
    output wire [DATA_WIDTH-1:0]    dout        //! Dado de saída (leitura)
);

    localparam WORD_ADDR_WIDTH = (ADDRESS_WIDTH > 2) ? (ADDRESS_WIDTH-2) : 1; //! Endereço por palavras (4 bytes)
    wire [WORD_ADDR_WIDTH-1:0] word_addr = addr[ADDRESS_WIDTH-1:2]; //! Converte endereço em bytes para palavras

    memory_write_first #(
        .DATA_WIDTH(8),
        .ADDRESS_WIDTH(WORD_ADDR_WIDTH),
        .BYTE_LANE(0)
    ) mem_byte0 (
        .clk(clk),
        .we(byteEnable[0]),
        .addr(word_addr),
        .din(din[7:0]),
        .dout(dout[7:0])
    );

    memory_write_first #(
        .DATA_WIDTH(8),
        .ADDRESS_WIDTH(WORD_ADDR_WIDTH),
        .BYTE_LANE(1)
    ) mem_byte1 (
        .clk(clk),
        .we(byteEnable[1]),
        .addr(word_addr),
        .din(din[15:8]),
        .dout(dout[15:8])
    );

    memory_write_first #(
        .DATA_WIDTH(8),
        .ADDRESS_WIDTH(WORD_ADDR_WIDTH),
        .BYTE_LANE(2)
    ) mem_byte2 (
        .clk(clk),
        .we(byteEnable[2]),
        .addr(word_addr),
        .din(din[23:16]),
        .dout(dout[23:16])
    );

    memory_write_first #(
        .DATA_WIDTH(8),
        .ADDRESS_WIDTH(WORD_ADDR_WIDTH),
        .BYTE_LANE(3)
    ) mem_byte3 (
        .clk(clk),
        .we(byteEnable[3]),
        .addr(word_addr),
        .din(din[31:24]),
        .dout(dout[31:24])
    );

endmodule
