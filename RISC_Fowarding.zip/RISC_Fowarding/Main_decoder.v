// RETIRADO DA TABELA 7.2 NA PÁGINA 408 DA BIBLIOGRAFIA

module Main_decoder (
    input [6:0] Op,          //! Opcode da instrução (bits [6:0])
    input [2:0] funct3,      //! Campo funct3 utilizado para diferenciar cargas e armazenamentos
    input [6:0] funct7,      //! Campo funct7 completo (para operações de ponto flutuante)
    input [4:0] rs2,         //! Campo rs2 utilizado em instruções da FPU
    output reg Branch,       //! Indica se a instrução é um branch condicional
    output reg [1:0] ResultSrc, //! Seleciona a fonte do dado para Write Back (00=ALU/FPU, 01=Memória, 10=PC+4)
    output reg MemWrite,     //! Habilita escrita na memória de dados
    output reg ALUSrc,       //! Seleciona entre registrador (0) e imediato (1) para o operando B da ALU
    output reg [1:0] ImmSrc, //! Define como o imediato deve ser estendido
    output reg RegWrite,     //! Habilita escrita no banco de registradores inteiros
    output reg RegWriteF,    //! Habilita escrita no banco de registradores de ponto flutuante
    output reg FloatOp,      //! Seleciona saída da FPU
    output reg [4:0] FPUControl, //! Operação a ser executada pela FPU
    output reg FPUSrcAInt,   //! Seleciona origem do operando A da FPU (0=registro F, 1=registro inteiro)
    output reg FPUSrcBInt,   //! Seleciona origem do operando B da FPU (0=registro F, 1=registro inteiro)
    output reg Jump,         //! Indica instrução JAL (desvio incondicional)
    output reg [2:0] LoadType,//! Define o tipo de extensão realizado no dado carregado
    output reg [1:0] StoreType,//! Define o tamanho da escrita na memória
    output reg       StoreFloat,//! Indica que o dado a ser armazenado vem do banco F
    output reg       ALUSrcA_PC,//! Seleciona o PC como operando A da ALU
    output reg [1:0] ALUOp   //! Auxilia na escolha da operação da ALU
);

// Instruções possíveis
localparam opcode_load        = 7'b0000011,
           opcode_store       = 7'b0100011,
           opcode_float_load  = 7'b0000111,
           opcode_float_store = 7'b0100111,
           R_type        = 7'b0110011,
           opcode_branch = 7'b1100011,
           opcode_addi   = 7'b0010011,
           opcode_auipc  = 7'b0010111,
           opcode_lui    = 7'b0110111,
           opcode_jal    = 7'b1101111,
           opcode_fp     = 7'b1010011; // Operações de ponto flutuante

// Tipos de load suportados
localparam LOAD_LB  = 3'b000,
           LOAD_LH  = 3'b001,
           LOAD_LW  = 3'b010,
           LOAD_LBU = 3'b011,
           LOAD_LHU = 3'b100,
           LOAD_NONE= 3'b111;

// Tipos de store suportados
localparam STORE_SB   = 2'b00,
           STORE_SH   = 2'b01,
           STORE_SW   = 2'b10,
           STORE_NONE = 2'b11;

always @(*) begin
    Branch     = 1'b0;
    ResultSrc  = 2'b00;
    MemWrite   = 1'b0;
    ALUSrc     = 1'b0;
    ImmSrc     = 2'b00;
    RegWrite   = 1'b0;
    RegWriteF  = 1'b0;
    FloatOp    = 1'b0;
    FPUControl = 5'b00000;
    FPUSrcAInt = 1'b0;
    FPUSrcBInt = 1'b0;
    Jump       = 1'b0;
    LoadType   = LOAD_NONE;
    StoreType  = STORE_NONE;
    ALUOp      = 2'b00;
    StoreFloat = 1'b0;
    ALUSrcA_PC = 1'b0;
    case (Op)
        opcode_load: begin
            RegWrite  = 1'b1;
            ALUSrc    = 1'b1;
            ResultSrc = 2'b01;
            case (funct3)
                3'b000: LoadType = LOAD_LB;
                3'b001: LoadType = LOAD_LH;
                3'b010: LoadType = LOAD_LW;
                3'b100: LoadType = LOAD_LBU;
                3'b101: LoadType = LOAD_LHU;
                default: LoadType = LOAD_NONE;
            endcase
        end
        opcode_store: begin
            ImmSrc   = 2'b01;
            ALUSrc   = 1'b1;
            MemWrite = 1'b1;
            case (funct3)
                3'b000: StoreType = STORE_SB;
                3'b001: StoreType = STORE_SH;
                3'b010: StoreType = STORE_SW;
                default: StoreType = STORE_NONE;
            endcase
        end
        opcode_float_load: begin
            RegWriteF = 1'b1;
            ALUSrc    = 1'b1;
            ResultSrc = 2'b01;
            LoadType  = LOAD_LW;
        end
        opcode_float_store: begin
            ImmSrc     = 2'b01;
            ALUSrc     = 1'b1;
            MemWrite   = 1'b1;
            StoreType  = STORE_SW;
            StoreFloat = 1'b1;
        end
        R_type: begin
            RegWrite = 1'b1;
            ALUOp    = 2'b10;
        end
        opcode_branch: begin
            ImmSrc = 2'b10;
            Branch = 1'b1;
            ALUOp  = 2'b01;
        end
        opcode_addi: begin
            RegWrite = 1'b1;
            ALUSrc   = 1'b1; // Operando B vem do imediato
            // ResultSrc permanece 0 para gravar o resultado da ALU
        end
        opcode_lui: begin
            RegWrite = 1'b1;
            ALUSrc   = 1'b1;
        end
        opcode_auipc: begin
            RegWrite   = 1'b1;
            ALUSrc     = 1'b1;
            ALUSrcA_PC = 1'b1;
        end
        opcode_jal: begin
            RegWrite  = 1'b1; // Escreve PC+4 no registrador destino
            Jump      = 1'b1; // Desvio incondicional
            ResultSrc = 2'b10; // Seleciona PC+4 para Write Back
            ImmSrc    = 2'b11; // Imediato do tipo J
        end
        opcode_fp: begin
            FloatOp   = 1'b1;
            ALUSrc    = 1'b0;
            case (funct7)
                7'b0000000: begin // FADD.S
                    FPUControl = 5'd4;
                    RegWriteF  = 1'b1;
                    FPUSrcBInt = 1'b0;
                end
                7'b0000100: begin // FSUB.S
                    FPUControl = 5'd5;
                    RegWriteF  = 1'b1;
                    FPUSrcBInt = 1'b0;
                end
                7'b0001000: begin // FMUL.S
                    FPUControl = 5'd6;
                    RegWriteF  = 1'b1;
                    FPUSrcBInt = 1'b0;
                end
                7'b0010100: begin // FMIN/FMAX.S
                    FPUSrcBInt = 1'b0;
                    if (funct3 == 3'b000) begin
                        FPUControl = 5'd7;
                        RegWriteF  = 1'b1;
                    end else if (funct3 == 3'b001) begin
                        FPUControl = 5'd8;
                        RegWriteF  = 1'b1;
                    end
                end
                7'b1010000: begin // Comparações FEQ/FLT/FLE escrevem em registradores inteiros
                    RegWrite = 1'b1;
                    FPUSrcBInt = 1'b0;
                    case (funct3)
                        3'b010: FPUControl = 5'd9;  // feq.s
                        3'b001: FPUControl = 5'd10; // flt.s
                        3'b000: FPUControl = 5'd11; // fle.s
                        default: RegWrite = 1'b0;
                    endcase
                end
                7'b1110000: begin // FMV.X.W
                    if ((funct3 == 3'b000) && (rs2 == 5'b00000)) begin
                        FPUControl = 5'd12;
                        RegWrite   = 1'b1;
                        FPUSrcBInt = 1'b1;
                    end
                end
                7'b1111000: begin // FMV.W.X
                    if ((funct3 == 3'b000) && (rs2 == 5'b00000)) begin
                        FPUControl = 5'd13;
                        RegWriteF  = 1'b1;
                        FPUSrcAInt = 1'b1;
                        FPUSrcBInt = 1'b1;
                    end
                end
                7'b1100000: begin // FCVT.W.S / FCVT.WU.S (rm campo funct3)
                    // rm = 111 significa modo dinâmico; rm = 000 é RNE padrão.
                    // Aceitamos qualquer modo válido (exceto valores reservados 101/110).
                    if ((funct3 != 3'b101) && (funct3 != 3'b110) && (rs2 == 5'b00000)) begin
                        FPUControl = 5'd15;
                        RegWrite   = 1'b1;
                        FPUSrcBInt = 1'b1;
                    end
                end
                7'b1101000: begin // FCVT.S.W / FCVT.S.WU (rm campo funct3)
                    if ((funct3 != 3'b101) && (funct3 != 3'b110) && (rs2 == 5'b00000)) begin
                        FPUControl = 5'd14;
                        RegWriteF  = 1'b1;
                        FPUSrcAInt = 1'b1;
                        FPUSrcBInt = 1'b1;
                    end
                end
                default: begin
                    FloatOp = 1'b0; // Operação não suportada
                end
            endcase
        end
    endcase
end

endmodule
