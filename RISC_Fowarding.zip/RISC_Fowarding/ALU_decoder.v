// RETIRADO DA TABELA 7.3 NA PÁGINA 409 DA BIBLIOGRAFIA

module ALU_decoder (
    input [1:0] ALUOp,
    input [2:0] funct3,
    input       funct7,
    input       op,
    output reg [2:0] ALUControl
);

// Operações possíveis da ALU
localparam ADD = 3'b000,
           SUB = 3'b001,
           AND = 3'b010,
           OR  = 3'b011,
           SLT = 3'b101;

always @(*) begin
    case (ALUOp)
        2'b00: ALUControl = ADD; // instruções lw, sw
        2'b01: ALUControl = SUB; // instrução beq
        2'b10: begin
            case (funct3)
                3'b000: begin
                    if ({op, funct7} == 2'b11) begin
                        ALUControl = SUB; // instrução sub
                    end else begin
                        ALUControl = ADD; // instrução add
                    end
                end
                3'b010: ALUControl = SLT; // instrução slt
                3'b110: ALUControl = OR;  // instrução or
                3'b111: ALUControl = AND; // instrução and
                default: ALUControl = ADD; // caso inválido
            endcase
        end
        default: ALUControl = ADD; // caso inválido
    endcase
end

endmodule
