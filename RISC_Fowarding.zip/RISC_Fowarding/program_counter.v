module program_counter (
    input wire        clk,     //! Sinal de clock
    input wire        rst,     //! Reset síncrono
    input wire        stall,   //! Mantém o PC quando verdadeiro (bolha por hazard)
    input wire [31:0] PCNext,  //! Próximo valor do PC
    output reg [31:0] PC       //! Valor atual do PC
);

    always @(posedge clk) begin
        if (rst) begin
            PC <= 32'h1000; //! Endereço inicial da memória de instruções
        end else if (!stall) begin
            PC <= PCNext;
        end
    end

endmodule
