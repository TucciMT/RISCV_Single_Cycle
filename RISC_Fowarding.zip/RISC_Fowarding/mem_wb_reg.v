module mem_wb_reg (
    input        clk,                //! Sinal de clock
    input        rst,                //! Sinal de reset síncrono
    input        RegWrite_in,        //! Controle de escrita recebido do estágio MEM
    input        RegWriteF_in,       //! Controle de escrita do banco F recebido do estágio MEM
    input  [1:0] ResultSrc_in,       //! Seleção da fonte dos dados para Write Back
    input [31:0] ReadData_in,        //! Dado lido da memória de dados
    input [31:0] ALUResult_in,       //! Resultado da ALU
    input [31:0] pc_plus4_in,        //! Valor de PC+4 propagado para Write Back
    input  [4:0] rd_in,              //! Registrador destino
    output reg        RegWrite_out,
    output reg        RegWriteF_out,
    output reg [1:0] ResultSrc_out,
    output reg [31:0] ReadData_out,
    output reg [31:0] ALUResult_out,
    output reg [31:0] pc_plus4_out,
    output reg  [4:0] rd_out
);

    always @(posedge clk) begin
        if (rst) begin
            RegWrite_out  <= 1'b0;
            RegWriteF_out <= 1'b0;
            ResultSrc_out <= 2'b00;
            ReadData_out  <= 32'b0;
            ALUResult_out <= 32'b0;
            pc_plus4_out  <= 32'b0;
            rd_out        <= 5'b0;
        end else begin
            RegWrite_out  <= RegWrite_in;
            RegWriteF_out <= RegWriteF_in;
            ResultSrc_out <= ResultSrc_in;
            ReadData_out  <= ReadData_in;
            ALUResult_out <= ALUResult_in;
            pc_plus4_out  <= pc_plus4_in;
            rd_out        <= rd_in;
        end
    end

endmodule
