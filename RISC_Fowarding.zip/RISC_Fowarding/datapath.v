`include "RISC_Fowarding/forwarding_control.v"

module datapath (
    input           clk,          //! Sinal de clock
    input           rst,          //! Sinal de reset síncrono
    input           Branch,       //! Indica se a instrução corrente é um branch
    input  [1:0]    ResultSrc,    //! Seleção da fonte de dados para Write Back (estágio ID)
    input           MemWrite,     //! Controle de escrita da memória de dados (estágio ID)
    input           ALUSrc,       //! Seleção do operando B da ALU (estágio ID)
    input           ALUSrcA_PC,   //! Seleção do PC como operando A da ALU
    input           RegWrite,     //! Controle de escrita do banco de registradores (estágio ID)
    input           RegWriteF,    //! Controle de escrita do banco de registradores de ponto flutuante
    input  [1:0]    ImmSrc,       //! Seleção do formato de imediato (estágio ID)
    input  [2:0]    ALUControl,   //! Operação da ALU (estágio ID)
    input  [4:0]    FPUControl,   //! Operação da FPU (estágio ID)
    input           FloatOp,      //! Seleciona a saída da FPU em vez da ALU
    input           FPUSrcAInt,   //! Seleciona o operando A da FPU a partir do banco inteiro
    input           FPUSrcBInt,   //! Seleciona o operando B da FPU a partir do banco inteiro
    input           Jump,         //! Indicação de instrução JAL no estágio ID
    input  [2:0]    LoadType,     //! Define ajuste de sinal/zero para leituras de memória
    input  [1:0]    StoreType,    //! Define o tamanho da escrita em memória
    input           FloatStore,   //! Indica que o dado da memória vem do banco de registradores F
    output [6:0]    funct7,       //! Campo funct7 completo para o bloco de controle
    output [2:0]    funct3,       //! Campo funct3 encaminhado para a controladora
    output [4:0]    rs2,          //! Campo rs2 encaminhado para a controladora
    output [6:0]    op            //! Opcode encaminhado para a controladora
);

    /* Declaração dos fios utilizados ao longo do datapath */
    wire [31:0] pc_next;          //! Próximo valor do contador de programa
    wire [31:0] pc;               //! Valor atual do contador de programa
    wire [31:0] pc_plus4;         //! PC + 4 (próxima instrução sequencial)
    wire [31:0] instr;            //! Instrução lida na memória
    wire [31:0] if_id_pc;         //! PC armazenado no registrador IF/ID
    wire [31:0] if_id_pc_plus4;   //! PC+4 no estágio IF/ID
    wire [31:0] if_id_instr;      //! Instrução armazenada no registrador IF/ID
    wire [31:0] imm_ext;          //! Imediato estendido
    wire [31:0] imm_base;         //! Imediato padrão gerado pelo bloco extend
    wire [31:0] rd1;              //! Operando A lido do banco de registradores
    wire [31:0] rd2;              //! Operando B lido do banco de registradores
    wire [31:0] frd1;             //! Operando A lido do banco de registradores de ponto flutuante
    wire [31:0] frd2;             //! Operando B lido do banco de registradores de ponto flutuante
    wire [31:0] id_ex_pc;         //! PC armazenado no registrador ID/EX
    wire [31:0] id_ex_pc_plus4;   //! PC+4 propagado para ID/EX
    wire [31:0] id_ex_rd1;        //! Operando A no estágio EX
    wire [31:0] id_ex_rd2;        //! Operando B (antes da seleção) no estágio EX
    wire [31:0] id_ex_frd1;       //! Operando A da FPU no estágio EX
    wire [31:0] id_ex_frd2;       //! Operando B da FPU no estágio EX
    wire [31:0] id_ex_imm;        //! Imediato no estágio EX
    wire [4:0]  id_ex_rs1;        //! Campo rs1 no estágio EX
    wire [4:0]  id_ex_rs2;        //! Campo rs2 no estágio EX
    wire [4:0]  id_ex_rd;         //! Registrador destino no estágio EX/MEM
    wire        id_ex_RegWrite;   //! Controle RegWrite no estágio EX/MEM
    wire        id_ex_MemWrite;   //! Controle MemWrite no estágio EX/MEM
    wire [1:0]  id_ex_ResultSrc;  //! Controle ResultSrc no estágio EX/MEM
    wire        id_ex_RegWriteF;  //! Controle RegWriteF no estágio EX/MEM
    wire [4:0]  id_ex_FPUControl; //! Operação da FPU no estágio EX
    wire        id_ex_FloatOp;    //! Seleciona o resultado da FPU no estágio EX
    wire        id_ex_FPUSrcAInt; //! Seleção da origem do operando A da FPU
    wire        id_ex_FPUSrcBInt; //! Seleção da origem do operando B da FPU
    wire        id_ex_FloatStore; //! Identifica armazenamentos vindos do banco F
    wire        id_ex_Branch;     //! Indicação de branch no estágio EX
    wire        id_ex_Jump;       //! Indicação de jump no estágio EX
    wire        id_ex_ALUSrcA_PC; //! Seleciona o PC como operando A no estágio EX
    wire        id_ex_ALUSrc;     //! Seleção do operando B da ALU no estágio EX
    wire [2:0]  id_ex_ALUControl; //! Operação da ALU no estágio EX
    wire [2:0]  id_ex_LoadType;   //! Tipo de carga propagado para o estágio MEM
    wire [1:0]  id_ex_StoreType;  //! Tipo de armazenamento propagado para o estágio MEM
    wire [31:0] alu_srcB;         //! Operando B efetivo da ALU
    wire [31:0] alu_srcA;         //! Operando A efetivo da ALU
    wire [31:0] alu_result;       //! Resultado da operação da ALU
    wire [31:0] fpu_srcA;         //! Operando A efetivo da FPU
    wire [31:0] fpu_srcB;         //! Operando B efetivo da FPU
    wire [31:0] fpu_result;       //! Resultado da operação da FPU
    wire [31:0] ex_result;        //! Resultado selecionado entre ALU e FPU
    wire [31:0] ex_mem_result;    //! Resultado registrado no estágio EX/MEM
    wire        zero;             //! Flag zero da ALU
    wire [31:0] pc_target;        //! Endereço alvo do branch/jump
    wire        pc_src;           //! Indica se o próximo PC deve ser o alvo do branch/jump
    wire [31:0] read_data;        //! Dado lido da memória de dados
    wire [31:0] load_data_ext;    //! Dado de leitura ajustado conforme o tipo de carga
    wire [31:0] wb_data;          //! Dado a ser escrito no banco de registradores
    wire        mem_wb_RegWrite;  //! Controle RegWrite no estágio WB
    wire [1:0]  mem_wb_ResultSrc; //! Seleção da fonte de dados no estágio WB
    wire [31:0] mem_wb_ReadData;  //! Dado vindo da memória no estágio WB
    wire [31:0] mem_wb_ALUResult; //! Resultado da ALU propagado para WB
    wire [4:0]  mem_wb_rd;        //! Registrador destino no estágio WB
    wire [31:0] mem_wb_PCPlus4;   //! Valor de PC+4 propagado até o estágio WB
    wire        mem_wb_RegWriteF; //! Controle de escrita no banco F no estágio WB
    wire        ex_mem_RegWrite;  //! Controle RegWrite no estágio EX/MEM
    wire        ex_mem_RegWriteF; //! Controle RegWriteF no estágio EX/MEM
    wire        ex_mem_MemWrite;  //! Controle MemWrite no estágio EX/MEM
    wire [1:0]  ex_mem_ResultSrc; //! Seleção da fonte de dados no estágio EX/MEM
    wire [2:0]  ex_mem_LoadType;  //! Tipo de carga no estágio EX/MEM
    wire [1:0]  ex_mem_StoreType; //! Tipo de armazenamento no estágio EX/MEM
    wire        ex_mem_FloatStore;//! Indica armazenamentos vindos do banco F no estágio EX/MEM
    wire [31:0] ex_mem_store_data;//! Dado bruto para escrita armazenado em EX/MEM
    wire [31:0] ex_mem_pc_plus4;  //! PC+4 armazenado no estágio EX/MEM
    wire [4:0]  ex_mem_rd;        //! Registrador destino no estágio EX/MEM
    reg  [3:0]  byte_enable;      //! Máscara de escrita por byte na memória de dados
    reg  [31:0] store_data;       //! Dado alinhado para escrita parcial
    wire        hazard_stall;     //! Indica necessidade de manter IF e ID parados
    wire        load_use_hazard_int; //! Hazard load-use para registradores inteiros
    wire        load_use_hazard_float; //! Hazard load-use para registradores F
    wire [1:0]  forwardA_int;     //! Seleção de forwarding para operando A inteiro
    wire [1:0]  forwardB_int;     //! Seleção de forwarding para operando B inteiro
    wire [1:0]  forwardA_float;   //! Seleção de forwarding para operando A flutuante
    wire [1:0]  forwardB_float;   //! Seleção de forwarding para operando B flutuante
    wire [31:0] forwardA_int_data;   //! Valor inteiro encaminhado para operando A
    wire [31:0] forwardB_int_data;   //! Valor inteiro encaminhado para operando B
    wire [31:0] forwardA_float_data; //! Valor flutuante encaminhado para operando A
    wire [31:0] forwardB_float_data; //! Valor flutuante encaminhado para operando B
    wire [31:0] store_data_forwarded; //! Dado encaminhado para operações de store
    wire        uses_rs1;         //! Verdadeiro quando a instrução em ID utiliza rs1
    wire        uses_rs2;         //! Verdadeiro quando a instrução em ID utiliza rs2
    wire [4:0]  id_rs1;           //! Campo rs1 da instrução em ID
    wire [4:0]  id_rs2;           //! Campo rs2 da instrução em ID

    /* Estágio IF */
    program_counter PROGRAM_COUNTER (
        .clk(clk),
        .rst(rst),
        .stall(hazard_stall),
        .PCNext(pc_next),
        .PC(pc)
    );

    instruction_memory INSTRUCTION_MEMORY (
        .A(pc),
        .RD(instr)
    );

    adder ADDER_PC (
        .a(pc),
        .b(32'd4),
        .sum(pc_plus4)
    );

    /* Registrador IF/ID com sinal de flush quando um branch é tomado */
    if_id_reg IF_ID (
        .clk(clk),
        .rst(rst),
        .flush(pc_src),
        .stall(hazard_stall),
        .pc_in(pc),
        .pc_plus4_in(pc_plus4),
        .instr_in(instr),
        .pc_out(if_id_pc),
        .pc_plus4_out(if_id_pc_plus4),
        .instr_out(if_id_instr)
    );

    /* Campos da instrução encaminhados para o bloco de controle */
    assign op     = if_id_instr[6:0];
    assign funct3 = if_id_instr[14:12];
    assign funct7 = if_id_instr[31:25];
    assign rs2    = if_id_instr[24:20];
    assign id_rs1 = if_id_instr[19:15];
    assign id_rs2 = if_id_instr[24:20];

    wire is_nop    = (if_id_instr == 32'b0);
    wire is_jal    = (op == 7'b1101111);
    wire is_store_int  = (op == 7'b0100011);
    wire is_store_float= (op == 7'b0100111);
    wire is_branch = (op == 7'b1100011);
    wire is_rtype  = (op == 7'b0110011);
    wire is_float  = (op == 7'b1010011);
    wire is_lui    = (op == 7'b0110111);
    wire is_auipc  = (op == 7'b0010111);

    wire uses_int_rs1   = (!is_nop && !is_jal && !is_float && !is_lui && !is_auipc) ||
                          (is_float && FPUSrcAInt);
    wire uses_int_rs2   = (!is_nop && (is_rtype || is_store_int || is_branch) && !is_float) ||
                          (is_float && FPUSrcBInt);
    wire uses_float_rs1 = is_float && !FPUSrcAInt;
    wire uses_float_rs2 = (is_float && !FPUSrcBInt) || is_store_float;

    wire uses_int_rs1_ex  = uses_int_rs1;
    wire uses_int_rs2_ex  = uses_int_rs2;
    wire uses_float_rs1_ex = uses_float_rs1;
    wire uses_float_rs2_ex = uses_float_rs2;

    assign uses_rs1 = uses_int_rs1;
    assign uses_rs2 = uses_int_rs2;

    /* Banco de registradores (leitura assíncrona, escrita síncrona) */
    register_file REGISTER_FILE (
        .clk(clk),
        .rst(rst),
        .WE3(mem_wb_RegWrite),
        .A1(if_id_instr[19:15]),
        .A2(if_id_instr[24:20]),
        .A3(mem_wb_rd),
        .WD3(wb_data),
        .RD1(rd1),
        .RD2(rd2)
    );

    register_file_f REGISTER_FILE_F (
        .clk(clk),
        .rst(rst),
        .WE3(mem_wb_RegWriteF),
        .A1(if_id_instr[19:15]),
        .A2(if_id_instr[24:20]),
        .A3(mem_wb_rd),
        .WD3(wb_data),
        .RD1(frd1),
        .RD2(frd2)
    );

    /* Extensão de imediato conforme o tipo da instrução */
    extend EXTEND (
        .instr(if_id_instr[31:7]),
        .immsrc(ImmSrc),
        .immext(imm_base)
    );

    wire [31:0] imm_u_type = {if_id_instr[31:12], 12'b0};

    assign imm_ext = (is_lui || is_auipc) ? imm_u_type : imm_base;

    assign load_use_hazard_int = (id_ex_ResultSrc == 2'b01) && id_ex_RegWrite && (id_ex_rd != 5'd0) &&
                                 ((uses_int_rs1_ex && (id_ex_rd == id_rs1)) ||
                                  (uses_int_rs2_ex && (id_ex_rd == id_rs2)));

    assign load_use_hazard_float = (id_ex_ResultSrc == 2'b01) && id_ex_RegWriteF && (id_ex_rd != 5'd0) &&
                                   ((uses_float_rs1_ex && (id_ex_rd == id_rs1)) ||
                                    (uses_float_rs2_ex && (id_ex_rd == id_rs2)));

    assign hazard_stall = load_use_hazard_int || load_use_hazard_float;

    /* Registrador ID/EX - propaga operandos e sinais de controle */
    id_ex_reg ID_EX (
        .clk(clk),
        .rst(rst),
        .flush(pc_src | hazard_stall),
        .RegWrite_in(RegWrite),
        .RegWriteF_in(RegWriteF),
        .MemWrite_in(MemWrite),
        .ResultSrc_in(ResultSrc),
        .Branch_in(Branch),
        .Jump_in(Jump),
        .LoadType_in(LoadType),
        .StoreType_in(StoreType),
        .ALUSrcA_PC_in(ALUSrcA_PC),
        .ALUSrc_in(ALUSrc),
        .ALUControl_in(ALUControl),
        .FPUControl_in(FPUControl),
        .FloatOp_in(FloatOp),
        .FPUSrcAInt_in(FPUSrcAInt),
        .FPUSrcBInt_in(FPUSrcBInt),
        .FloatStore_in(FloatStore),
        .pc_in(if_id_pc),
        .pc_plus4_in(if_id_pc_plus4),
        .rd1_in(rd1),
        .rd2_in(rd2),
        .frd1_in(frd1),
        .frd2_in(frd2),
        .imm_in(imm_ext),
        .rs1_in(if_id_instr[19:15]),
        .rs2_in(if_id_instr[24:20]),
        .rd_in(if_id_instr[11:7]),
        .RegWrite_out(id_ex_RegWrite),
        .RegWriteF_out(id_ex_RegWriteF),
        .MemWrite_out(id_ex_MemWrite),
        .ResultSrc_out(id_ex_ResultSrc),
        .Branch_out(id_ex_Branch),
        .Jump_out(id_ex_Jump),
        .LoadType_out(id_ex_LoadType),
        .StoreType_out(id_ex_StoreType),
        .ALUSrcA_PC_out(id_ex_ALUSrcA_PC),
        .ALUSrc_out(id_ex_ALUSrc),
        .ALUControl_out(id_ex_ALUControl),
        .FPUControl_out(id_ex_FPUControl),
        .FloatOp_out(id_ex_FloatOp),
        .FPUSrcAInt_out(id_ex_FPUSrcAInt),
        .FPUSrcBInt_out(id_ex_FPUSrcBInt),
        .FloatStore_out(id_ex_FloatStore),
        .pc_out(id_ex_pc),
        .pc_plus4_out(id_ex_pc_plus4),
        .rd1_out(id_ex_rd1),
        .rd2_out(id_ex_rd2),
        .frd1_out(id_ex_frd1),
        .frd2_out(id_ex_frd2),
        .imm_out(id_ex_imm),
        .rs1_out(id_ex_rs1),
        .rs2_out(id_ex_rs2),
        .rd_out(id_ex_rd)
    );

    /* Unidade de forwarding e estágio EX */
    forwarding_control FORWARDING_UNIT (
        .id_ex_rs1(id_ex_rs1),
        .id_ex_rs2(id_ex_rs2),
        .id_ex_rs1_f(id_ex_rs1),
        .id_ex_rs2_f(id_ex_rs2),
        .ex_mem_rd(ex_mem_rd),
        .mem_wb_rd(mem_wb_rd),
        .ex_mem_RegWrite(ex_mem_RegWrite),
        .mem_wb_RegWrite(mem_wb_RegWrite),
        .ex_mem_RegWriteF(ex_mem_RegWriteF),
        .mem_wb_RegWriteF(mem_wb_RegWriteF),
        .forwardA_int(forwardA_int),
        .forwardB_int(forwardB_int),
        .forwardA_float(forwardA_float),
        .forwardB_float(forwardB_float)
    );

    Mux4x1 #(.N(32)) MUX_FWD_A_INT (
        .a(id_ex_rd1),
        .b(wb_data),
        .c(ex_mem_result),
        .d(32'b0),
        .sel(forwardA_int),
        .y(forwardA_int_data)
    );

    Mux4x1 #(.N(32)) MUX_FWD_B_INT (
        .a(id_ex_rd2),
        .b(wb_data),
        .c(ex_mem_result),
        .d(32'b0),
        .sel(forwardB_int),
        .y(forwardB_int_data)
    );

    Mux4x1 #(.N(32)) MUX_FWD_A_FLOAT (
        .a(id_ex_frd1),
        .b(wb_data),
        .c(ex_mem_result),
        .d(32'b0),
        .sel(forwardA_float),
        .y(forwardA_float_data)
    );

    Mux4x1 #(.N(32)) MUX_FWD_B_FLOAT (
        .a(id_ex_frd2),
        .b(wb_data),
        .c(ex_mem_result),
        .d(32'b0),
        .sel(forwardB_float),
        .y(forwardB_float_data)
    );

    assign store_data_forwarded = id_ex_FloatStore ? forwardB_float_data : forwardB_int_data;

    Mux2x1 #(.N(32)) MUX_SRCB (
        .a(forwardB_int_data),
        .b(id_ex_imm),
        .sel(id_ex_ALUSrc),
        .y(alu_srcB)
    );

    assign alu_srcA = id_ex_ALUSrcA_PC ? id_ex_pc : forwardA_int_data;

    ALU ALU_UNIT (
        .SrcA(alu_srcA),
        .SrcB(alu_srcB),
        .ALUControl(id_ex_ALUControl),
        .ALUResult(alu_result),
        .Zero(zero)
    );

    assign fpu_srcA = id_ex_FPUSrcAInt ? forwardA_int_data : forwardA_float_data;
    assign fpu_srcB = id_ex_FPUSrcBInt ? forwardB_int_data : forwardB_float_data;

    FPU FPU_UNIT (
        .A(fpu_srcA),
        .B(fpu_srcB),
        .sel(id_ex_FPUControl),
        .Result(fpu_result)
    );

    Mux2x1 #(.N(32)) MUX_ALU_FPU (
        .a(alu_result),
        .b(fpu_result),
        .sel(id_ex_FloatOp),
        .y(ex_result)
    );

    adder ADDER_PCTARGET (
        .a(id_ex_pc),
        .b(id_ex_imm),
        .sum(pc_target)
    );

    assign pc_src = (id_ex_Branch & zero) | id_ex_Jump; //! Branch ou jump tomados

    ex_mem_reg EX_MEM (
        .clk(clk),
        .rst(rst),
        .RegWrite_in(id_ex_RegWrite),
        .RegWriteF_in(id_ex_RegWriteF),
        .MemWrite_in(id_ex_MemWrite),
        .ResultSrc_in(id_ex_ResultSrc),
        .LoadType_in(id_ex_LoadType),
        .StoreType_in(id_ex_StoreType),
        .FloatStore_in(id_ex_FloatStore),
        .ex_result_in(ex_result),
        .store_data_in(store_data_forwarded),
        .pc_plus4_in(id_ex_pc_plus4),
        .rd_in(id_ex_rd),
        .RegWrite_out(ex_mem_RegWrite),
        .RegWriteF_out(ex_mem_RegWriteF),
        .MemWrite_out(ex_mem_MemWrite),
        .ResultSrc_out(ex_mem_ResultSrc),
        .LoadType_out(ex_mem_LoadType),
        .StoreType_out(ex_mem_StoreType),
        .FloatStore_out(ex_mem_FloatStore),
        .ex_result_out(ex_mem_result),
        .store_data_out(ex_mem_store_data),
        .pc_plus4_out(ex_mem_pc_plus4),
        .rd_out(ex_mem_rd)
    );

    localparam STORE_SB   = 2'b00;
    localparam STORE_SH   = 2'b01;
    localparam STORE_SW   = 2'b10;

    always @(*) begin
        if (!ex_mem_MemWrite) begin
            byte_enable = 4'b0000;
        end else begin
            case (ex_mem_StoreType)
                STORE_SW: byte_enable = 4'b1111;
                STORE_SH: byte_enable = ex_mem_result[1] ? 4'b1100 : 4'b0011;
                STORE_SB: begin
                    case (ex_mem_result[1:0])
                        2'b00: byte_enable = 4'b0001;
                        2'b01: byte_enable = 4'b0010;
                        2'b10: byte_enable = 4'b0100;
                        default: byte_enable = 4'b1000;
                    endcase
                end
                default: byte_enable = 4'b0000;
            endcase
        end
    end

    always @(*) begin
        case (ex_mem_StoreType)
            STORE_SW: store_data = ex_mem_store_data;
            STORE_SH: store_data = ex_mem_result[1] ? {ex_mem_store_data[15:0], 16'b0} : {16'b0, ex_mem_store_data[15:0]};
            STORE_SB: begin
                case (ex_mem_result[1:0])
                    2'b00: store_data = {24'b0, ex_mem_store_data[7:0]};
                    2'b01: store_data = {16'b0, ex_mem_store_data[7:0], 8'b0};
                    2'b10: store_data = {8'b0, ex_mem_store_data[7:0], 16'b0};
                    default: store_data = {ex_mem_store_data[7:0], 24'b0};
                endcase
            end
            default: store_data = ex_mem_store_data;
        endcase
    end

    memByteAddressable32WF #(
        .DATA_WIDTH(32),
        .ADDRESS_WIDTH(8)
    ) DATA_MEMORY (
        .clk(clk),
        .byteEnable(byte_enable),
        .addr(ex_mem_result[7:0]),
        .din(store_data),
        .dout(read_data)
    );

    localparam LOAD_LB  = 3'b000;
    localparam LOAD_LH  = 3'b001;
    localparam LOAD_LW  = 3'b010;
    localparam LOAD_LBU = 3'b011;
    localparam LOAD_LHU = 3'b100;

    wire [7:0] selected_byte = (ex_mem_result[1:0] == 2'b00) ? read_data[7:0]  :
                               (ex_mem_result[1:0] == 2'b01) ? read_data[15:8] :
                               (ex_mem_result[1:0] == 2'b10) ? read_data[23:16]:
                                                             read_data[31:24];

    wire [15:0] selected_half = ex_mem_result[1] ? read_data[31:16] : read_data[15:0];

    reg [31:0] load_data_ext_reg;
    always @(*) begin
        case (ex_mem_LoadType)
            LOAD_LB:  load_data_ext_reg = {{24{selected_byte[7]}}, selected_byte};
            LOAD_LBU: load_data_ext_reg = {24'b0, selected_byte};
            LOAD_LH:  load_data_ext_reg = {{16{selected_half[15]}}, selected_half};
            LOAD_LHU: load_data_ext_reg = {16'b0, selected_half};
            LOAD_LW:  load_data_ext_reg = read_data;
            default:  load_data_ext_reg = read_data;
        endcase
    end

    assign load_data_ext = load_data_ext_reg;

    /* Registrador MEM/WB */
    mem_wb_reg MEM_WB (
        .clk(clk),
        .rst(rst),
        .RegWrite_in(ex_mem_RegWrite),
        .RegWriteF_in(ex_mem_RegWriteF),
        .ResultSrc_in(ex_mem_ResultSrc),
        .ReadData_in(load_data_ext),
        .ALUResult_in(ex_mem_result),
        .pc_plus4_in(ex_mem_pc_plus4),
        .rd_in(ex_mem_rd),
        .RegWrite_out(mem_wb_RegWrite),
        .RegWriteF_out(mem_wb_RegWriteF),
        .ResultSrc_out(mem_wb_ResultSrc),
        .ReadData_out(mem_wb_ReadData),
        .ALUResult_out(mem_wb_ALUResult),
        .pc_plus4_out(mem_wb_PCPlus4),
        .rd_out(mem_wb_rd)
    );

    /* Estágio WB */
    assign wb_data = (mem_wb_ResultSrc == 2'b00) ? mem_wb_ALUResult :
                     (mem_wb_ResultSrc == 2'b01) ? mem_wb_ReadData :
                     mem_wb_PCPlus4; //! Para JAL gravar PC+4

    /* Atualização do PC: branch tomado versus sequência normal */
    Mux2x1 #(.N(32)) MUX_PCNEXT (
        .a(pc_plus4),
        .b(pc_target),
        .sel(pc_src),
        .y(pc_next)
    );

endmodule
