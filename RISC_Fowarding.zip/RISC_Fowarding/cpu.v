module cpu (
    input clk, //! Sinal de clock
    input rst  //! Sinal de reset
);

    /* Declaração dos sinais de interconexão entre os blocos */
    wire        Branch;       //! Indica instrução de branch
    wire [1:0]  ResultSrc;    //! Seleção da fonte para Write Back (ALU/Mem/PC+4)
    wire        MemWrite;     //! Habilita escrita na memória de dados
    wire        ALUSrc;       //! Seleciona imediato como operando B da ALU
    wire        ALUSrcA_PC;   //! Seleciona o PC como operando A da ALU
    wire        RegWrite;     //! Habilita escrita no banco de registradores inteiros
    wire        RegWriteF;    //! Habilita escrita no banco de registradores de ponto flutuante
    wire [1:0]  ImmSrc;       //! Seleciona extensão do imediato
    wire        Jump;         //! Indica instrução JAL
    wire [2:0]  LoadType;     //! Define ajuste de sinal/zero para leituras de memória
    wire [1:0]  StoreType;    //! Define o tamanho da escrita em memória
    wire        StoreFloat;   //! Indica armazenamentos vindos do banco F
    wire [2:0]  ALUControl;   //! Operação executada pela ALU
    wire [4:0]  FPUControl;   //! Operação executada pela FPU
    wire        FloatOp;      //! Seleção do resultado da FPU
    wire        FPUSrcAInt;   //! Seleciona operando A da FPU do banco inteiro
    wire        FPUSrcBInt;   //! Seleciona operando B da FPU do banco inteiro
    wire [6:0]  funct7;       //! Campo funct7 completo da instrução em ID
    wire [2:0]  funct3;       //! Campo funct3 em ID
    wire [4:0]  rs2;          //! Campo rs2 em ID
    wire [6:0]  op;           //! Opcode da instrução em ID

    /* Datapath pipeline */
    datapath DATAPATH (
        .clk(clk),
        .rst(rst),
        .Branch(Branch),
        .ResultSrc(ResultSrc),
        .MemWrite(MemWrite),
        .ALUSrc(ALUSrc),
        .ALUSrcA_PC(ALUSrcA_PC),
        .RegWrite(RegWrite),
        .RegWriteF(RegWriteF),
        .ImmSrc(ImmSrc),
        .ALUControl(ALUControl),
        .FPUControl(FPUControl),
        .FloatOp(FloatOp),
        .FPUSrcAInt(FPUSrcAInt),
        .FPUSrcBInt(FPUSrcBInt),
        .funct7(funct7),
        .funct3(funct3),
        .rs2(rs2),
        .op(op),
        .Jump(Jump),
        .LoadType(LoadType),
        .StoreType(StoreType),
        .FloatStore(StoreFloat)
    );

    /* Unidade de controle reaproveitada do processador single-cycle */
    Control_Unit CONTROL_UNIT (
        .Op(op),
        .funct3(funct3),
        .funct7(funct7),
        .rs2(rs2),
        .Branch(Branch),
        .ResultSrc(ResultSrc),
        .MemWrite(MemWrite),
        .ALUSrc(ALUSrc),
        .ALUSrcA_PC(ALUSrcA_PC),
        .ImmSrc(ImmSrc),
        .RegWrite(RegWrite),
        .RegWriteF(RegWriteF),
        .FloatOp(FloatOp),
        .FPUControl(FPUControl),
        .FPUSrcAInt(FPUSrcAInt),
        .FPUSrcBInt(FPUSrcBInt),
        .Jump(Jump),
        .LoadType(LoadType),
        .StoreType(StoreType),
        .StoreFloat(StoreFloat),
        .ALUControl(ALUControl)
    );

endmodule
