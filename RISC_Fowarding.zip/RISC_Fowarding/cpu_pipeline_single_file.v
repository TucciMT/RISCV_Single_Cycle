// Arquivo auto-gerado para facilitar testes: contém todas as definições em um único arquivo.
module cpu_pipeline_single_file (
    input clk, //! Sinal de clock
    input rst  //! Sinal de reset
);

    /* Declaração dos sinais de interconexão entre os blocos */
    wire        Branch;       //! Indica instrução de branch
    wire [1:0]  ResultSrc;    //! Seleção da fonte para Write Back (ALU_sf/Mem/PC+4)
    wire        MemWrite;     //! Habilita escrita na memória de dados
    wire        ALUSrc;       //! Seleciona imediato como operando B da ALU_sf
    wire        ALUSrcA_PC;   //! Seleciona o PC como operando A da ALU_sf
    wire        RegWrite;     //! Habilita escrita no banco de registradores
    wire        RegWriteF;    //! Habilita escrita no banco de registradores de ponto flutuante
    wire [1:0]  ImmSrc;       //! Seleciona extensão do imediato
    wire [2:0]  ALUControl;   //! Operação executada pela ALU_sf
    wire [4:0]  FPUControl;   //! Operação executada pela FPU
    wire        FloatOp;      //! Seleciona resultado vindo da FPU
    wire        FPUSrcAInt;   //! Seleciona o operando A da FPU a partir do banco inteiro
    wire        FPUSrcBInt;   //! Seleciona o operando B da FPU a partir do banco inteiro
    wire        Jump;         //! Indica instrução JAL
    wire [2:0]  LoadType;     //! Ajuste de sinal/zero para leituras
    wire [1:0]  StoreType;    //! Tamanho da escrita em memória
    wire        StoreFloat;   //! Indica armazenamentos vindos do banco F
    wire [6:0]  funct7;       //! Campo funct7 completo da instrução em ID
    wire [2:0]  funct3;       //! Campo funct3 em ID
    wire [4:0]  rs2;          //! Campo rs2 em ID (utilizado por instruções de ponto flutuante)
    wire [6:0]  op;           //! Opcode da instrução em ID

    /* Datapath pipeline */
    datapath_sf DATAPATH (
        .clk(clk),
        .rst(rst),
        .Branch(Branch),
        .ResultSrc(ResultSrc),
        .MemWrite(MemWrite),
        .ALUSrc(ALUSrc),
        .ALUSrcA_PC(ALUSrcA_PC),
        .RegWrite(RegWrite),
        .RegWriteF(RegWriteF),
        .ImmSrc(ImmSrc),
        .ALUControl(ALUControl),
        .FPUControl(FPUControl),
        .FloatOp(FloatOp),
        .FPUSrcAInt(FPUSrcAInt),
        .FPUSrcBInt(FPUSrcBInt),
        .funct7(funct7),
        .funct3(funct3),
        .rs2(rs2),
        .op(op),
        .Jump(Jump),
        .LoadType(LoadType),
        .StoreType(StoreType),
        .FloatStore(StoreFloat)
    );

    /* Unidade de controle reaproveitada do processador single-cycle */
    Control_Unit_sf CONTROL_UNIT (
        .Op(op),
        .funct3(funct3),
        .funct7(funct7),
        .rs2(rs2),
        .Branch(Branch),
        .ResultSrc(ResultSrc),
        .MemWrite(MemWrite),
        .ALUSrc(ALUSrc),
        .ALUSrcA_PC(ALUSrcA_PC),
        .ImmSrc(ImmSrc),
        .RegWrite(RegWrite),
        .RegWriteF(RegWriteF),
        .FloatOp(FloatOp),
        .FPUControl(FPUControl),
        .FPUSrcAInt(FPUSrcAInt),
        .FPUSrcBInt(FPUSrcBInt),
        .Jump(Jump),
        .LoadType(LoadType),
        .StoreType(StoreType),
        .StoreFloat(StoreFloat),
        .ALUControl(ALUControl)
    );

endmodule

module datapath_sf (
    input           clk,          //! Sinal de clock
    input           rst,          //! Sinal de reset síncrono
    input           Branch,       //! Indica se a instrução corrente é um branch
    input  [1:0]    ResultSrc,    //! Seleção da fonte de dados para Write Back (estágio ID)
    input           MemWrite,     //! Controle de escrita da memória de dados (estágio ID)
    input           ALUSrc,       //! Seleção do operando B da ALU_sf (estágio ID)
    input           ALUSrcA_PC,   //! Seleção do PC como operando A da ALU_sf
    input           RegWrite,     //! Controle de escrita do banco de registradores (estágio ID)
    input           RegWriteF,    //! Controle de escrita do banco de registradores de ponto flutuante
    input  [1:0]    ImmSrc,       //! Seleção do formato de imediato (estágio ID)
    input  [2:0]    ALUControl,   //! Operação da ALU_sf (estágio ID)
    input  [4:0]    FPUControl,   //! Operação da FPU (estágio ID)
    input           FloatOp,      //! Seleciona o resultado da FPU
    input           FPUSrcAInt,   //! Seleciona o operando A da FPU a partir do banco inteiro
    input           FPUSrcBInt,   //! Seleciona o operando B da FPU a partir do banco inteiro
    input           Jump,         //! Indicação de instrução JAL no estágio ID
    input  [2:0]    LoadType,     //! Ajuste de sinal/zero para leituras
    input  [1:0]    StoreType,    //! Tamanho da escrita em memória
    input           FloatStore,   //! Indica que o dado da memória vem do banco F
    output [6:0]    funct7,       //! Campo funct7 completo para o bloco de controle
    output [2:0]    funct3,       //! Campo funct3 encaminhado para a controladora
    output [4:0]    rs2,          //! Campo rs2 utilizado em instruções de ponto flutuante
    output [6:0]    op            //! Opcode encaminhado para a controladora
);

    /* Declaração dos fios utilizados ao longo do datapath_sf */
    wire [31:0] pc_next;          //! Próximo valor do contador de programa
    wire [31:0] pc;               //! Valor atual do contador de programa
    wire [31:0] pc_plus4;         //! PC + 4 (próxima instrução sequencial)
    wire [31:0] instr;            //! Instrução lida na memória
    wire [31:0] if_id_pc;         //! PC armazenado no registrador IF/ID
    wire [31:0] if_id_pc_plus4;   //! PC+4 no estágio IF/ID
    wire [31:0] if_id_instr;      //! Instrução armazenada no registrador IF/ID
    wire [31:0] imm_ext;          //! Imediato estendido
    wire [31:0] imm_base;         //! Imediato padrão gerado pelo bloco extend
    wire [31:0] rd1;              //! Operando A lido do banco de registradores
    wire [31:0] rd2;              //! Operando B lido do banco de registradores
    wire [31:0] frd1;             //! Operando A lido do banco de registradores de ponto flutuante
    wire [31:0] frd2;             //! Operando B lido do banco de registradores de ponto flutuante
    wire [31:0] id_ex_pc;         //! PC armazenado no registrador ID/EX
    wire [31:0] id_ex_pc_plus4;   //! PC+4 propagado para ID/EX
    wire [31:0] id_ex_rd1;        //! Operando A no estágio EX
    wire [31:0] id_ex_rd2;        //! Operando B (antes da seleção) no estágio EX
    wire [31:0] id_ex_frd1;       //! Operando A da FPU no estágio EX
    wire [31:0] id_ex_frd2;       //! Operando B da FPU no estágio EX
    wire [31:0] id_ex_imm;        //! Imediato no estágio EX
    wire [4:0]  id_ex_rs1;        //! Campo rs1 no estágio EX
    wire [4:0]  id_ex_rs2;        //! Campo rs2 no estágio EX
    wire [4:0]  id_ex_rd;         //! Registrador destino no estágio EX/MEM
    wire        id_ex_RegWrite;   //! Controle RegWrite no estágio EX/MEM
    wire        id_ex_MemWrite;   //! Controle MemWrite no estágio EX/MEM
    wire [1:0]  id_ex_ResultSrc;  //! Controle ResultSrc no estágio EX/MEM
    wire        id_ex_RegWriteF;  //! Controle RegWriteF no estágio EX/MEM
    wire [4:0]  id_ex_FPUControl; //! Operação da FPU no estágio EX
    wire        id_ex_FloatOp;    //! Seleção entre ALU_sf e FPU no estágio EX
    wire        id_ex_FPUSrcAInt; //! Seleção da origem do operando A da FPU
    wire        id_ex_FPUSrcBInt; //! Seleção da origem do operando B da FPU
    wire        id_ex_FloatStore; //! Indica armazenamentos vindos do banco F
    wire        id_ex_Branch;     //! Indicação de branch no estágio EX
    wire        id_ex_Jump;       //! Indicação de jump no estágio EX
    wire        id_ex_ALUSrcA_PC; //! Seleciona o PC como operando A no estágio EX
    wire        id_ex_ALUSrc;     //! Seleção do operando B da ALU_sf no estágio EX
    wire [2:0]  id_ex_ALUControl; //! Operação da ALU_sf no estágio EX
    wire [2:0]  id_ex_LoadType;   //! Tipo de carga propagado para o estágio MEM
    wire [1:0]  id_ex_StoreType;  //! Tipo de armazenamento propagado para o estágio MEM
    wire [31:0] alu_srcB;         //! Operando B efetivo da ALU_sf
    wire [31:0] alu_srcA;         //! Operando A efetivo da ALU_sf
    wire [31:0] alu_result;       //! Resultado da operação da ALU_sf
    wire [31:0] fpu_srcA;         //! Operando A efetivo da FPU
    wire [31:0] fpu_srcB;         //! Operando B efetivo da FPU
    wire [31:0] fpu_result;       //! Resultado da operação da FPU
    wire [31:0] ex_result;        //! Resultado selecionado entre ALU_sf e FPU
    wire [31:0] ex_mem_result;    //! Resultado registrado no estágio EX/MEM
    wire        zero;             //! Flag zero da ALU_sf
    wire [31:0] pc_target;        //! Endereço alvo do branch/jump
    wire        pc_src;           //! Indica se o próximo PC deve ser o alvo do branch/jump
    wire [31:0] read_data;        //! Dado lido da memória de dados
    wire [31:0] load_data_ext;    //! Dado de leitura ajustado conforme o tipo de carga
    wire [31:0] wb_data;          //! Dado a ser escrito no banco de registradores
    wire        mem_wb_RegWrite;  //! Controle RegWrite no estágio WB
    wire [1:0]  mem_wb_ResultSrc; //! Seleção da fonte de dados no estágio WB
    wire [31:0] mem_wb_ReadData;  //! Dado vindo da memória no estágio WB
    wire [31:0] mem_wb_ALUResult; //! Resultado da ALU/FPU propagado para WB
    wire [4:0]  mem_wb_rd;        //! Registrador destino no estágio WB
    wire [31:0] mem_wb_PCPlus4;   //! Valor de PC+4 propagado até o estágio WB
    wire        mem_wb_RegWriteF; //! Controle de escrita no banco F no estágio WB
    wire        ex_mem_RegWrite;  //! Controle RegWrite no estágio EX/MEM
    wire        ex_mem_RegWriteF; //! Controle RegWriteF no estágio EX/MEM
    wire        ex_mem_MemWrite;  //! Controle MemWrite no estágio EX/MEM
    wire [1:0]  ex_mem_ResultSrc; //! Seleção da fonte de dados no estágio EX/MEM
    wire [2:0]  ex_mem_LoadType;  //! Tipo de carga no estágio EX/MEM
    wire [1:0]  ex_mem_StoreType; //! Tipo de armazenamento no estágio EX/MEM
    wire        ex_mem_FloatStore;//! Indica armazenamentos vindos do banco F no estágio EX/MEM
    wire [31:0] ex_mem_store_data;//! Dado bruto para escrita armazenado em EX/MEM
    wire [31:0] ex_mem_pc_plus4;  //! PC+4 armazenado no estágio EX/MEM
    wire [4:0]  ex_mem_rd;        //! Registrador destino no estágio EX/MEM
    reg  [3:0]  byte_enable;      //! Máscara de escrita por byte na memória de dados
    reg  [31:0] store_data;       //! Dado alinhado para escrita parcial
    wire        hazard_stall;     //! Mantém PC/IF/ID quando verdadeiro
    wire        load_use_hazard_int;   //! Hazard load-use para registradores inteiros
    wire        load_use_hazard_float; //! Hazard load-use para registradores de ponto flutuante
    wire [1:0]  forwardA_int;     //! Seleção de forwarding para operando A inteiro
    wire [1:0]  forwardB_int;     //! Seleção de forwarding para operando B inteiro
    wire [1:0]  forwardA_float;   //! Seleção de forwarding para operando A flutuante
    wire [1:0]  forwardB_float;   //! Seleção de forwarding para operando B flutuante
    wire [31:0] forwardA_int_data;   //! Valor inteiro encaminhado para operando A
    wire [31:0] forwardB_int_data;   //! Valor inteiro encaminhado para operando B
    wire [31:0] forwardA_float_data; //! Valor flutuante encaminhado para operando A
    wire [31:0] forwardB_float_data; //! Valor flutuante encaminhado para operando B
    wire [31:0] store_data_forwarded; //! Dado encaminhado para operações de store
    wire        uses_rs1;         //! Indica uso de rs1 na instrução atual de ID
    wire        uses_rs2;         //! Indica uso de rs2 na instrução atual de ID
    wire [4:0]  id_rs1;           //! Campo rs1 em ID
    wire [4:0]  id_rs2;           //! Campo rs2 em ID

    /* Estágio IF */
    program_counter_sf PROGRAM_COUNTER (
        .clk(clk),
        .rst(rst),
        .stall(hazard_stall),
        .PCNext(pc_next),
        .PC(pc)
    );

    instruction_memory_sf INSTRUCTION_MEMORY (
        .A(pc),
        .RD(instr)
    );

    adder_sf ADDER_PC (
        .a(pc),
        .b(32'd4),
        .sum(pc_plus4)
    );

    /* Registrador IF/ID com sinal de flush quando um branch é tomado */
    if_id_reg_sf IF_ID (
        .clk(clk),
        .rst(rst),
        .flush(pc_src),
        .stall(hazard_stall),
        .pc_in(pc),
        .pc_plus4_in(pc_plus4),
        .instr_in(instr),
        .pc_out(if_id_pc),
        .pc_plus4_out(if_id_pc_plus4),
        .instr_out(if_id_instr)
    );

    /* Campos da instrução encaminhados para o bloco de controle */
    assign op     = if_id_instr[6:0];
    assign funct3 = if_id_instr[14:12];
    assign funct7 = if_id_instr[31:25];
    assign rs2    = if_id_instr[24:20];
    assign id_rs1 = if_id_instr[19:15];
    assign id_rs2 = if_id_instr[24:20];

    wire is_nop_sf       = (if_id_instr == 32'b0);
    wire is_jal_sf       = (op == 7'b1101111);
    wire is_store_int_sf = (op == 7'b0100011);
    wire is_store_float_sf = (op == 7'b0100111);
    wire is_branch_sf    = (op == 7'b1100011);
    wire is_rtype_sf     = (op == 7'b0110011);
    wire is_float_sf     = (op == 7'b1010011);
    wire is_lui_sf       = (op == 7'b0110111);
    wire is_auipc_sf     = (op == 7'b0010111);

    wire uses_int_rs1   = (!is_nop_sf && !is_jal_sf && !is_float_sf && !is_lui_sf && !is_auipc_sf) ||
                          (is_float_sf && FPUSrcAInt);
    wire uses_int_rs2   = (!is_nop_sf && (is_rtype_sf || is_store_int_sf || is_branch_sf) && !is_float_sf) ||
                          (is_float_sf && FPUSrcBInt);
    wire uses_float_rs1 = is_float_sf && !FPUSrcAInt;
    wire uses_float_rs2 = (is_float_sf && !FPUSrcBInt) || is_store_float_sf;

    wire uses_int_rs1_ex   = uses_int_rs1;
    wire uses_int_rs2_ex   = uses_int_rs2;
    wire uses_float_rs1_ex = uses_float_rs1;
    wire uses_float_rs2_ex = uses_float_rs2;

    assign uses_rs1 = uses_int_rs1;
    assign uses_rs2 = uses_int_rs2;

    /* Banco de registradores (leitura assíncrona, escrita síncrona) */
    register_file_sf REGISTER_FILE (
        .clk(clk),
        .rst(rst),
        .WE3(mem_wb_RegWrite),
        .A1(if_id_instr[19:15]),
        .A2(if_id_instr[24:20]),
        .A3(mem_wb_rd),
        .WD3(wb_data),
        .RD1(rd1),
        .RD2(rd2)
    );

    register_file_f_sf REGISTER_FILE_F (
        .clk(clk),
        .rst(rst),
        .WE3(mem_wb_RegWriteF),
        .A1(if_id_instr[19:15]),
        .A2(if_id_instr[24:20]),
        .A3(mem_wb_rd),
        .WD3(wb_data),
        .RD1(frd1),
        .RD2(frd2)
    );

    /* Extensão de imediato conforme o tipo da instrução */
    extend_sf EXTEND (
        .instr(if_id_instr[31:7]),
        .immsrc(ImmSrc),
        .immext(imm_base)
    );

    wire [31:0] imm_u_type_sf = {if_id_instr[31:12], 12'b0};

    assign imm_ext = (is_lui_sf || is_auipc_sf) ? imm_u_type_sf : imm_base;

    assign load_use_hazard_int = (id_ex_ResultSrc == 2'b01) && id_ex_RegWrite && (id_ex_rd != 5'd0) &&
                                 ((uses_int_rs1_ex && (id_ex_rd == id_rs1)) ||
                                  (uses_int_rs2_ex && (id_ex_rd == id_rs2)));

    assign load_use_hazard_float = (id_ex_ResultSrc == 2'b01) && id_ex_RegWriteF && (id_ex_rd != 5'd0) &&
                                   ((uses_float_rs1_ex && (id_ex_rd == id_rs1)) ||
                                    (uses_float_rs2_ex && (id_ex_rd == id_rs2)));

    assign hazard_stall = load_use_hazard_int || load_use_hazard_float;

    /* Registrador ID/EX - propaga operandos e sinais de controle */
    id_ex_reg_sf ID_EX (
        .clk(clk),
        .rst(rst),
        .flush(pc_src | hazard_stall),
        .RegWrite_in(RegWrite),
        .RegWriteF_in(RegWriteF),
        .MemWrite_in(MemWrite),
        .ResultSrc_in(ResultSrc),
        .Branch_in(Branch),
        .Jump_in(Jump),
        .LoadType_in(LoadType),
        .StoreType_in(StoreType),
        .ALUSrcA_PC_in(ALUSrcA_PC),
        .ALUSrc_in(ALUSrc),
        .ALUControl_in(ALUControl),
        .FPUControl_in(FPUControl),
        .FloatOp_in(FloatOp),
        .FPUSrcAInt_in(FPUSrcAInt),
        .FPUSrcBInt_in(FPUSrcBInt),
        .FloatStore_in(FloatStore),
        .pc_in(if_id_pc),
        .pc_plus4_in(if_id_pc_plus4),
        .rd1_in(rd1),
        .rd2_in(rd2),
        .frd1_in(frd1),
        .frd2_in(frd2),
        .imm_in(imm_ext),
        .rs1_in(if_id_instr[19:15]),
        .rs2_in(if_id_instr[24:20]),
        .rd_in(if_id_instr[11:7]),
        .RegWrite_out(id_ex_RegWrite),
        .RegWriteF_out(id_ex_RegWriteF),
        .MemWrite_out(id_ex_MemWrite),
        .ResultSrc_out(id_ex_ResultSrc),
        .Branch_out(id_ex_Branch),
        .Jump_out(id_ex_Jump),
        .LoadType_out(id_ex_LoadType),
        .StoreType_out(id_ex_StoreType),
        .ALUSrcA_PC_out(id_ex_ALUSrcA_PC),
        .ALUSrc_out(id_ex_ALUSrc),
        .ALUControl_out(id_ex_ALUControl),
        .FPUControl_out(id_ex_FPUControl),
        .FloatOp_out(id_ex_FloatOp),
        .FPUSrcAInt_out(id_ex_FPUSrcAInt),
        .FPUSrcBInt_out(id_ex_FPUSrcBInt),
        .FloatStore_out(id_ex_FloatStore),
        .pc_out(id_ex_pc),
        .pc_plus4_out(id_ex_pc_plus4),
        .rd1_out(id_ex_rd1),
        .rd2_out(id_ex_rd2),
        .frd1_out(id_ex_frd1),
        .frd2_out(id_ex_frd2),
        .imm_out(id_ex_imm),
        .rs1_out(id_ex_rs1),
        .rs2_out(id_ex_rs2),
        .rd_out(id_ex_rd)
    );

    forwarding_control_sf FORWARDING_UNIT (
        .id_ex_rs1(id_ex_rs1),
        .id_ex_rs2(id_ex_rs2),
        .id_ex_rs1_f(id_ex_rs1),
        .id_ex_rs2_f(id_ex_rs2),
        .ex_mem_rd(ex_mem_rd),
        .mem_wb_rd(mem_wb_rd),
        .ex_mem_RegWrite(ex_mem_RegWrite),
        .mem_wb_RegWrite(mem_wb_RegWrite),
        .ex_mem_RegWriteF(ex_mem_RegWriteF),
        .mem_wb_RegWriteF(mem_wb_RegWriteF),
        .forwardA_int(forwardA_int),
        .forwardB_int(forwardB_int),
        .forwardA_float(forwardA_float),
        .forwardB_float(forwardB_float)
    );

    Mux4x1_sf #(.N(32)) MUX_FWD_A_INT (
        .a(id_ex_rd1),
        .b(wb_data),
        .c(ex_mem_result),
        .d(32'b0),
        .sel(forwardA_int),
        .y(forwardA_int_data)
    );

    Mux4x1_sf #(.N(32)) MUX_FWD_B_INT (
        .a(id_ex_rd2),
        .b(wb_data),
        .c(ex_mem_result),
        .d(32'b0),
        .sel(forwardB_int),
        .y(forwardB_int_data)
    );

    Mux4x1_sf #(.N(32)) MUX_FWD_A_FLOAT (
        .a(id_ex_frd1),
        .b(wb_data),
        .c(ex_mem_result),
        .d(32'b0),
        .sel(forwardA_float),
        .y(forwardA_float_data)
    );

    Mux4x1_sf #(.N(32)) MUX_FWD_B_FLOAT (
        .a(id_ex_frd2),
        .b(wb_data),
        .c(ex_mem_result),
        .d(32'b0),
        .sel(forwardB_float),
        .y(forwardB_float_data)
    );

    assign store_data_forwarded = id_ex_FloatStore ? forwardB_float_data : forwardB_int_data;

    Mux2x1_sf #(.N(32)) MUX_SRCB (
        .a(forwardB_int_data),
        .b(id_ex_imm),
        .sel(id_ex_ALUSrc),
        .y(alu_srcB)
    );

    assign alu_srcA = id_ex_ALUSrcA_PC ? id_ex_pc : forwardA_int_data;

    ALU_sf ALU_UNIT (
        .SrcA(alu_srcA),
        .SrcB(alu_srcB),
        .ALUControl(id_ex_ALUControl),
        .ALUResult(alu_result),
        .Zero(zero)
    );

    assign fpu_srcA = id_ex_FPUSrcAInt ? forwardA_int_data : forwardA_float_data;
    assign fpu_srcB = id_ex_FPUSrcBInt ? forwardB_int_data : forwardB_float_data;

    FPU FPU_UNIT (
        .A(fpu_srcA),
        .B(fpu_srcB),
        .sel(id_ex_FPUControl),
        .Result(fpu_result)
    );

    Mux2x1_sf #(.N(32)) MUX_ALU_FPU (
        .a(alu_result),
        .b(fpu_result),
        .sel(id_ex_FloatOp),
        .y(ex_result)
    );

    adder_sf ADDER_PCTARGET (
        .a(id_ex_pc),
        .b(id_ex_imm),
        .sum(pc_target)
    );

    assign pc_src = (id_ex_Branch & zero) | id_ex_Jump; //! Branch ou jump tomados

    ex_mem_reg_sf EX_MEM (
        .clk(clk),
        .rst(rst),
        .RegWrite_in(id_ex_RegWrite),
        .RegWriteF_in(id_ex_RegWriteF),
        .MemWrite_in(id_ex_MemWrite),
        .ResultSrc_in(id_ex_ResultSrc),
        .LoadType_in(id_ex_LoadType),
        .StoreType_in(id_ex_StoreType),
        .FloatStore_in(id_ex_FloatStore),
        .ex_result_in(ex_result),
        .store_data_in(store_data_forwarded),
        .pc_plus4_in(id_ex_pc_plus4),
        .rd_in(id_ex_rd),
        .RegWrite_out(ex_mem_RegWrite),
        .RegWriteF_out(ex_mem_RegWriteF),
        .MemWrite_out(ex_mem_MemWrite),
        .ResultSrc_out(ex_mem_ResultSrc),
        .LoadType_out(ex_mem_LoadType),
        .StoreType_out(ex_mem_StoreType),
        .FloatStore_out(ex_mem_FloatStore),
        .ex_result_out(ex_mem_result),
        .store_data_out(ex_mem_store_data),
        .pc_plus4_out(ex_mem_pc_plus4),
        .rd_out(ex_mem_rd)
    );

    localparam STORE_SB   = 2'b00;
    localparam STORE_SH   = 2'b01;
    localparam STORE_SW   = 2'b10;

    always @(*) begin
        if (!ex_mem_MemWrite) begin
            byte_enable = 4'b0000;
        end else begin
            case (ex_mem_StoreType)
                STORE_SW: byte_enable = 4'b1111;
                STORE_SH: byte_enable = ex_mem_result[1] ? 4'b1100 : 4'b0011;
                STORE_SB: begin
                    case (ex_mem_result[1:0])
                        2'b00: byte_enable = 4'b0001;
                        2'b01: byte_enable = 4'b0010;
                        2'b10: byte_enable = 4'b0100;
                        default: byte_enable = 4'b1000;
                    endcase
                end
                default: byte_enable = 4'b0000;
            endcase
        end
    end

    always @(*) begin
        case (ex_mem_StoreType)
            STORE_SW: store_data = ex_mem_store_data;
            STORE_SH: store_data = ex_mem_result[1] ? {ex_mem_store_data[15:0], 16'b0} : {16'b0, ex_mem_store_data[15:0]};
            STORE_SB: begin
                case (ex_mem_result[1:0])
                    2'b00: store_data = {24'b0, ex_mem_store_data[7:0]};
                    2'b01: store_data = {16'b0, ex_mem_store_data[7:0], 8'b0};
                    2'b10: store_data = {8'b0, ex_mem_store_data[7:0], 16'b0};
                    default: store_data = {ex_mem_store_data[7:0], 24'b0};
                endcase
            end
            default: store_data = ex_mem_store_data;
        endcase
    end

    memByteAddressable32WF_sf #(
        .DATA_WIDTH(32),
        .ADDRESS_WIDTH(8)
    ) DATA_MEMORY (
        .clk(clk),
        .byteEnable(byte_enable),
        .addr(ex_mem_result[7:0]),
        .din(store_data),
        .dout(read_data)
    );

    localparam LOAD_LB  = 3'b000;
    localparam LOAD_LH  = 3'b001;
    localparam LOAD_LW  = 3'b010;
    localparam LOAD_LBU = 3'b011;
    localparam LOAD_LHU = 3'b100;

    wire [7:0] selected_byte = (ex_mem_result[1:0] == 2'b00) ? read_data[7:0]  :
                               (ex_mem_result[1:0] == 2'b01) ? read_data[15:8] :
                               (ex_mem_result[1:0] == 2'b10) ? read_data[23:16]:
                                                             read_data[31:24];

    wire [15:0] selected_half = ex_mem_result[1] ? read_data[31:16] : read_data[15:0];

    reg [31:0] load_data_ext_reg;
    always @(*) begin
        case (ex_mem_LoadType)
            LOAD_LB:  load_data_ext_reg = {{24{selected_byte[7]}}, selected_byte};
            LOAD_LBU: load_data_ext_reg = {24'b0, selected_byte};
            LOAD_LH:  load_data_ext_reg = {{16{selected_half[15]}}, selected_half};
            LOAD_LHU: load_data_ext_reg = {16'b0, selected_half};
            LOAD_LW:  load_data_ext_reg = read_data;
            default:  load_data_ext_reg = read_data;
        endcase
    end

    assign load_data_ext = load_data_ext_reg;

    /* Registrador MEM/WB */
    mem_wb_reg_sf MEM_WB (
        .clk(clk),
        .rst(rst),
        .RegWrite_in(ex_mem_RegWrite),
        .RegWriteF_in(ex_mem_RegWriteF),
        .ResultSrc_in(ex_mem_ResultSrc),
        .ReadData_in(load_data_ext),
        .ALUResult_in(ex_mem_result),
        .pc_plus4_in(ex_mem_pc_plus4),
        .rd_in(ex_mem_rd),
        .RegWrite_out(mem_wb_RegWrite),
        .RegWriteF_out(mem_wb_RegWriteF),
        .ResultSrc_out(mem_wb_ResultSrc),
        .ReadData_out(mem_wb_ReadData),
        .ALUResult_out(mem_wb_ALUResult),
        .pc_plus4_out(mem_wb_PCPlus4),
        .rd_out(mem_wb_rd)
    );

    /* Estágio WB */
    assign wb_data = (mem_wb_ResultSrc == 2'b00) ? mem_wb_ALUResult :
                     (mem_wb_ResultSrc == 2'b01) ? mem_wb_ReadData :
                     mem_wb_PCPlus4; //! Para JAL gravar PC+4

    /* Atualização do PC: branch tomado versus sequência normal */
    Mux2x1_sf #(.N(32)) MUX_PCNEXT (
        .a(pc_plus4),
        .b(pc_target),
        .sel(pc_src),
        .y(pc_next)
    );

endmodule

module Control_Unit_sf (
    input  [6:0] Op,          //! Campo opcode da instrução
    input  [2:0] funct3,      //! Campo funct3 da instrução
    input  [6:0] funct7,      //! Campo funct7 completo da instrução
    input  [4:0] rs2,         //! Campo rs2 utilizado em operações de ponto flutuante
    output       Branch,      //! Indica se a instrução é um branch condicional
    output [1:0] ResultSrc,   //! Seleciona a fonte de dados para Write Back (ALU_sf, Memória ou PC+4)
    output       MemWrite,    //! Habilita escrita na memória de dados
    output       ALUSrc,      //! Seleciona entre operando do registrador ou imediato para a ALU_sf
    output       ALUSrcA_PC,  //! Seleciona o PC como operando A da ALU_sf
    output [1:0] ImmSrc,      //! Define o tipo de extensão a ser aplicado ao imediato
    output       RegWrite,    //! Habilita escrita no banco de registradores inteiros
    output       RegWriteF,   //! Habilita escrita no banco de registradores de ponto flutuante
    output       FloatOp,     //! Seleciona o resultado da FPU
    output [4:0] FPUControl,  //! Operação executada pela FPU
    output       FPUSrcAInt,  //! Seleciona o operando A da FPU a partir do banco inteiro
    output       FPUSrcBInt,  //! Seleciona o operando B da FPU a partir do banco inteiro
    output       Jump,        //! Indica instrução JAL (desvio incondicional)
    output [2:0] LoadType,    //! Define como ajustar dados carregados
    output [1:0] StoreType,   //! Define o tamanho da escrita em memória
    output       StoreFloat,  //! Indica armazenamentos vindos do banco F
    output [2:0] ALUControl   //! Define a operação realizada pela ALU_sf
);

    //! Sinal intermediário que identifica qual operação a ALU_sf deve executar
    wire [1:0] ALUOp;

    Main_decoder_sf MainDecoder (
        .Op(Op),
        .funct3(funct3),
        .funct7(funct7),
        .rs2(rs2),
        .Branch(Branch),
        .ResultSrc(ResultSrc),
        .MemWrite(MemWrite),
        .ALUSrc(ALUSrc),
        .ALUSrcA_PC(ALUSrcA_PC),
        .ImmSrc(ImmSrc),
        .RegWrite(RegWrite),
        .RegWriteF(RegWriteF),
        .FloatOp(FloatOp),
        .FPUControl(FPUControl),
        .FPUSrcAInt(FPUSrcAInt),
        .FPUSrcBInt(FPUSrcBInt),
        .Jump(Jump),
        .LoadType(LoadType),
        .StoreType(StoreType),
        .StoreFloat(StoreFloat),
        .ALUOp(ALUOp)
    );

    ALU_decoder_sf ALUDecoder (
        .ALUOp(ALUOp),
        .funct3(funct3),
        .funct7(funct7[5]),
        .op(Op[5]),
        .ALUControl(ALUControl)
    );

endmodule

// RETIRADO DA TABELA 7.2 NA PÁGINA 408 DA BIBLIOGRAFIA

module Main_decoder_sf (
    input [6:0] Op,          //! Opcode da instrução (bits [6:0])
    input [2:0] funct3,      //! Campo funct3 utilizado para diferenciar cargas e armazenamentos
    input [6:0] funct7,      //! Campo funct7 completo (para operações de ponto flutuante)
    input [4:0] rs2,         //! Campo rs2 utilizado em instruções da FPU
    output reg Branch,       //! Indica se a instrução é um branch condicional
    output reg [1:0] ResultSrc, //! Seleciona a fonte do dado para Write Back (00=ALU/FPU, 01=Memória, 10=PC+4)
    output reg MemWrite,     //! Habilita escrita na memória de dados
    output reg ALUSrc,       //! Seleciona entre registrador (0) e imediato (1) para o operando B da ALU_sf
    output reg ALUSrcA_PC,   //! Seleciona o PC como operando A da ALU_sf
    output reg [1:0] ImmSrc, //! Define como o imediato deve ser estendido
    output reg RegWrite,     //! Habilita escrita no banco de registradores inteiros
    output reg RegWriteF,    //! Habilita escrita no banco de registradores de ponto flutuante
    output reg FloatOp,      //! Seleciona saída da FPU
    output reg [4:0] FPUControl, //! Operação a ser executada pela FPU
    output reg FPUSrcAInt,   //! Seleciona origem do operando A da FPU (0=registro F, 1=registro inteiro)
    output reg FPUSrcBInt,   //! Seleciona origem do operando B da FPU (0=registro F, 1=registro inteiro)
    output reg Jump,         //! Indica instrução JAL (desvio incondicional)
    output reg [2:0] LoadType,//! Define o tipo de extensão realizado no dado carregado
    output reg [1:0] StoreType,//! Define o tamanho da escrita na memória
    output reg       StoreFloat,//! Indica que o dado a ser armazenado vem do banco F
    output reg [1:0] ALUOp   //! Auxilia na escolha da operação da ALU_sf
);

// Instruções possíveis
localparam opcode_load        = 7'b0000011,
           opcode_store       = 7'b0100011,
           opcode_float_load  = 7'b0000111,
           opcode_float_store = 7'b0100111,
           R_type        = 7'b0110011,
           opcode_branch = 7'b1100011,
           opcode_addi   = 7'b0010011,
           opcode_auipc  = 7'b0010111,
           opcode_lui    = 7'b0110111,
           opcode_jal    = 7'b1101111,
           opcode_fp     = 7'b1010011; // Operações de ponto flutuante

// Tipos de load suportados
localparam LOAD_LB  = 3'b000,
           LOAD_LH  = 3'b001,
           LOAD_LW  = 3'b010,
           LOAD_LBU = 3'b011,
           LOAD_LHU = 3'b100,
           LOAD_NONE= 3'b111;

// Tipos de store suportados
localparam STORE_SB   = 2'b00,
           STORE_SH   = 2'b01,
           STORE_SW   = 2'b10,
           STORE_NONE = 2'b11;

always @(*) begin
    Branch     = 1'b0;
    ResultSrc  = 2'b00;
    MemWrite   = 1'b0;
    ALUSrc     = 1'b0;
    ImmSrc     = 2'b00;
    RegWrite   = 1'b0;
    RegWriteF  = 1'b0;
    FloatOp    = 1'b0;
    FPUControl = 5'b00000;
    FPUSrcAInt = 1'b0;
    FPUSrcBInt = 1'b0;
    Jump       = 1'b0;
    LoadType   = LOAD_NONE;
    StoreType  = STORE_NONE;
    ALUOp      = 2'b00;
    StoreFloat = 1'b0;
    ALUSrcA_PC = 1'b0;
    case (Op)
        opcode_load: begin
            RegWrite  = 1'b1;
            ALUSrc    = 1'b1;
            ResultSrc = 2'b01;
            case (funct3)
                3'b000: LoadType = LOAD_LB;
                3'b001: LoadType = LOAD_LH;
                3'b010: LoadType = LOAD_LW;
                3'b100: LoadType = LOAD_LBU;
                3'b101: LoadType = LOAD_LHU;
                default: LoadType = LOAD_NONE;
            endcase
        end
        opcode_store: begin
            ImmSrc   = 2'b01;
            ALUSrc   = 1'b1;
            MemWrite = 1'b1;
            case (funct3)
                3'b000: StoreType = STORE_SB;
                3'b001: StoreType = STORE_SH;
                3'b010: StoreType = STORE_SW;
                default: StoreType = STORE_NONE;
            endcase
        end
        opcode_float_load: begin
            RegWriteF = 1'b1;
            ALUSrc    = 1'b1;
            ResultSrc = 2'b01;
            LoadType  = LOAD_LW;
        end
        opcode_float_store: begin
            ImmSrc     = 2'b01;
            ALUSrc     = 1'b1;
            MemWrite   = 1'b1;
            StoreType  = STORE_SW;
            StoreFloat = 1'b1;
        end
        R_type: begin
            RegWrite = 1'b1;
            ALUOp    = 2'b10;
        end
        opcode_branch: begin
            ImmSrc = 2'b10;
            Branch = 1'b1;
            ALUOp  = 2'b01;
        end
        opcode_addi: begin
            RegWrite = 1'b1;
            ALUSrc   = 1'b1; // Operando B vem do imediato
            // ResultSrc permanece 0 para gravar o resultado da ALU_sf
        end
        opcode_lui: begin
            RegWrite = 1'b1;
            ALUSrc   = 1'b1;
        end
        opcode_auipc: begin
            RegWrite   = 1'b1;
            ALUSrc     = 1'b1;
            ALUSrcA_PC = 1'b1;
        end
        opcode_jal: begin
            RegWrite  = 1'b1; // Escreve PC+4 no registrador destino
            Jump      = 1'b1; // Desvio incondicional
            ResultSrc = 2'b10; // Seleciona PC+4 para Write Back
            ImmSrc    = 2'b11; // Imediato do tipo J
        end
        opcode_fp: begin
            FloatOp   = 1'b1;
            ALUSrc    = 1'b0;
            case (funct7)
                7'b0000000: begin // FADD.S
                    FPUControl = 5'd4;
                    RegWriteF  = 1'b1;
                    FPUSrcBInt = 1'b0;
                end
                7'b0000100: begin // FSUB.S
                    FPUControl = 5'd5;
                    RegWriteF  = 1'b1;
                    FPUSrcBInt = 1'b0;
                end
                7'b0001000: begin // FMUL.S
                    FPUControl = 5'd6;
                    RegWriteF  = 1'b1;
                    FPUSrcBInt = 1'b0;
                end
                7'b0010100: begin // FMIN/FMAX.S
                    FPUSrcBInt = 1'b0;
                    if (funct3 == 3'b000) begin
                        FPUControl = 5'd7;
                        RegWriteF  = 1'b1;
                    end else if (funct3 == 3'b001) begin
                        FPUControl = 5'd8;
                        RegWriteF  = 1'b1;
                    end
                end
                7'b1010000: begin // Comparações FEQ/FLT/FLE escrevem em registradores inteiros
                    RegWrite   = 1'b1;
                    FPUSrcBInt = 1'b0;
                    case (funct3)
                        3'b010: FPUControl = 5'd9;  // feq.s
                        3'b001: FPUControl = 5'd10; // flt.s
                        3'b000: FPUControl = 5'd11; // fle.s
                        default: RegWrite = 1'b0;
                    endcase
                end
                7'b1110000: begin // FMV.X.W
                    if ((funct3 == 3'b000) && (rs2 == 5'b00000)) begin
                        FPUControl = 5'd12;
                        RegWrite   = 1'b1;
                        FPUSrcBInt = 1'b1;
                    end
                end
                7'b1111000: begin // FMV.W.X
                    if ((funct3 == 3'b000) && (rs2 == 5'b00000)) begin
                        FPUControl = 5'd13;
                        RegWriteF  = 1'b1;
                        FPUSrcAInt = 1'b1;
                        FPUSrcBInt = 1'b1;
                    end
                end
                7'b1100000: begin // FCVT.W.S / FCVT.WU.S
                    if ((funct3 != 3'b101) && (funct3 != 3'b110) && (rs2 == 5'b00000)) begin
                        FPUControl = 5'd15;
                        RegWrite   = 1'b1;
                        FPUSrcBInt = 1'b1;
                    end
                end
                7'b1101000: begin // FCVT.S.W / FCVT.S.WU
                    if ((funct3 != 3'b101) && (funct3 != 3'b110) && (rs2 == 5'b00000)) begin
                        FPUControl = 5'd14;
                        RegWriteF  = 1'b1;
                        FPUSrcAInt = 1'b1;
                        FPUSrcBInt = 1'b1;
                    end
                end
                default: begin
                    FloatOp = 1'b0; // Operação não suportada
                end
            endcase
        end
        default: begin
            // Nenhuma ação específica
        end
    endcase
end

endmodule

// RETIRADO DA TABELA 7.3 NA PÁGINA 409 DA BIBLIOGRAFIA

module ALU_decoder_sf (
    input [1:0] ALUOp,
    input [2:0] funct3,
    input       funct7,
    input       op,
    output reg [2:0] ALUControl
);

// Operações possíveis da ALU_sf
localparam ADD = 3'b000,
           SUB = 3'b001,
           AND = 3'b010,
           OR  = 3'b011,
           SLT = 3'b101;

always @(*) begin
    case (ALUOp)
        2'b00: ALUControl = ADD; // instruções lw, sw
        2'b01: ALUControl = SUB; // instrução beq
        2'b10: begin
            case (funct3)
                3'b000: begin
                    if ({op, funct7} == 2'b11) begin
                        ALUControl = SUB; // instrução sub
                    end else begin
                        ALUControl = ADD; // instrução add
                    end
                end
                3'b010: ALUControl = SLT; // instrução slt
                3'b110: ALUControl = OR;  // instrução or
                3'b111: ALUControl = AND; // instrução and
                default: ALUControl = ADD; // caso inválido
            endcase
        end
        default: ALUControl = ADD; // caso inválido
    endcase
end

endmodule

module id_ex_reg_sf (
    input        clk,               //! Sinal de clock
    input        rst,               //! Sinal de reset síncrono
    input        flush,             //! Quando ativo, anula a instrução em execução
    input        RegWrite_in,       //! Controle de escrita no Write Back
    input        RegWriteF_in,      //! Controle de escrita no banco F
    input        MemWrite_in,       //! Controle de escrita na memória de dados
    input  [1:0] ResultSrc_in,      //! Seleção da fonte de dados para Write Back
    input        Branch_in,         //! Indica se a instrução é um branch
    input        Jump_in,           //! Indica se a instrução é um jump (JAL)
    input        ALUSrc_in,         //! Seleção do segundo operando da ALU_sf
    input  [2:0] ALUControl_in,     //! Operação a ser executada pela ALU_sf
    input  [4:0] FPUControl_in,     //! Operação a ser executada pela FPU
    input        FloatOp_in,        //! Seleciona resultado da FPU
    input        FPUSrcAInt_in,     //! Seleção da origem do operando A da FPU
    input        FPUSrcBInt_in,     //! Seleção da origem do operando B da FPU
    input        FloatStore_in,     //! Indica armazenamentos vindos do banco F
    input  [2:0] LoadType_in,       //! Tipo de carga propagado para MEM
    input  [1:0] StoreType_in,      //! Tipo de armazenamento propagado para MEM
    input        ALUSrcA_PC_in,     //! Seleciona o PC como operando A da ALU_sf
    input [31:0] pc_in,             //! PC do estágio ID (utilizado para cálculo de branches)
    input [31:0] pc_plus4_in,       //! PC+4 utilizado para escrita no Write Back (JAL)
    input [31:0] rd1_in,            //! Operando A da ALU_sf
    input [31:0] rd2_in,            //! Operando B (antes da seleção ALUSrc)
    input [31:0] frd1_in,           //! Operando A destinado à FPU
    input [31:0] frd2_in,           //! Operando B destinado à FPU
    input [31:0] imm_in,            //! Imediato estendido
    input  [4:0] rs1_in,            //! Campo rs1 da instrução
    input  [4:0] rs2_in,            //! Campo rs2 da instrução
    input  [4:0] rd_in,             //! Registrador destino
    output reg        RegWrite_out,
    output reg        RegWriteF_out,
    output reg        MemWrite_out,
    output reg [1:0] ResultSrc_out,
    output reg        Branch_out,
    output reg        Jump_out,
    output reg        ALUSrc_out,
    output reg  [2:0] ALUControl_out,
    output reg  [4:0] FPUControl_out,
    output reg        FloatOp_out,
    output reg        FPUSrcAInt_out,
    output reg        FPUSrcBInt_out,
    output reg        FloatStore_out,
    output reg  [2:0] LoadType_out,
    output reg  [1:0] StoreType_out,
    output reg        ALUSrcA_PC_out,
    output reg [31:0] pc_out,
    output reg [31:0] pc_plus4_out,
    output reg [31:0] rd1_out,
    output reg [31:0] rd2_out,
    output reg [31:0] frd1_out,
    output reg [31:0] frd2_out,
    output reg [31:0] imm_out,
    output reg  [4:0] rs1_out,
    output reg  [4:0] rs2_out,
    output reg  [4:0] rd_out
);

    always @(posedge clk) begin
        if (rst || flush) begin
            RegWrite_out   <= 1'b0;
            RegWriteF_out  <= 1'b0;
            MemWrite_out   <= 1'b0;
            ResultSrc_out  <= 2'b00;
            Branch_out     <= 1'b0;
            Jump_out       <= 1'b0;
            ALUSrc_out     <= 1'b0;
            ALUControl_out <= 3'b000;
            FPUControl_out <= 5'b0;
            FloatOp_out    <= 1'b0;
            FPUSrcAInt_out <= 1'b0;
            FPUSrcBInt_out <= 1'b0;
            FloatStore_out <= 1'b0;
            LoadType_out   <= 3'b111;
            StoreType_out  <= 2'b11;
            ALUSrcA_PC_out <= 1'b0;
            pc_out         <= 32'b0;
            pc_plus4_out   <= 32'b0;
            rd1_out        <= 32'b0;
            rd2_out        <= 32'b0;
            frd1_out       <= 32'b0;
            frd2_out       <= 32'b0;
            imm_out        <= 32'b0;
            rs1_out        <= 5'b0;
            rs2_out        <= 5'b0;
            rd_out         <= 5'b0;
        end else begin
            RegWrite_out   <= RegWrite_in;
            RegWriteF_out  <= RegWriteF_in;
            MemWrite_out   <= MemWrite_in;
            ResultSrc_out  <= ResultSrc_in;
            Branch_out     <= Branch_in;
            Jump_out       <= Jump_in;
            ALUSrc_out     <= ALUSrc_in;
            ALUControl_out <= ALUControl_in;
            FPUControl_out <= FPUControl_in;
            FloatOp_out    <= FloatOp_in;
            FPUSrcAInt_out <= FPUSrcAInt_in;
            FPUSrcBInt_out <= FPUSrcBInt_in;
            FloatStore_out <= FloatStore_in;
            LoadType_out   <= LoadType_in;
            StoreType_out  <= StoreType_in;
            ALUSrcA_PC_out <= ALUSrcA_PC_in;
            pc_out         <= pc_in;
            pc_plus4_out   <= pc_plus4_in;
            rd1_out        <= rd1_in;
            rd2_out        <= rd2_in;
            frd1_out       <= frd1_in;
            frd2_out       <= frd2_in;
            imm_out        <= imm_in;
            rs1_out        <= rs1_in;
            rs2_out        <= rs2_in;
            rd_out         <= rd_in;
        end
    end

endmodule

module if_id_reg_sf (
    input        clk,           //! Sinal de clock
    input        rst,           //! Sinal de reset síncrono
    input        flush,         //! Quando ativo, injeta bolha no estágio de decodificação
    input        stall,         //! Mantém o conteúdo atual quando há hazard
    input [31:0] pc_in,         //! Valor de PC do estágio IF
    input [31:0] pc_plus4_in,   //! Valor de PC+4 do estágio IF
    input [31:0] instr_in,      //! Instrução lida na memória
    output reg [31:0] pc_out,   //! PC encaminhado para o estágio ID
    output reg [31:0] pc_plus4_out, //! PC+4 encaminhado para o estágio ID
    output reg [31:0] instr_out //! Instrução encaminhada para o estágio ID
);

    always @(posedge clk) begin
        if (rst || flush) begin
            pc_out    <= 32'b0;
            pc_plus4_out <= 32'b0;
            instr_out <= 32'b0; //! Inserção de NOP
        end else if (!stall) begin
            pc_out    <= pc_in;
            pc_plus4_out <= pc_plus4_in;
            instr_out <= instr_in;
        end
    end

endmodule

module mem_wb_reg_sf (
    input        clk,                //! Sinal de clock
    input        rst,                //! Sinal de reset síncrono
    input        RegWrite_in,        //! Controle de escrita recebido do estágio MEM
    input        RegWriteF_in,       //! Controle de escrita do banco F recebido do estágio MEM
    input  [1:0] ResultSrc_in,       //! Seleção da fonte dos dados para Write Back
    input [31:0] ReadData_in,        //! Dado lido da memória de dados
    input [31:0] ALUResult_in,       //! Resultado da ALU_sf
    input [31:0] pc_plus4_in,        //! Valor de PC+4 propagado para Write Back
    input  [4:0] rd_in,              //! Registrador destino
    output reg        RegWrite_out,
    output reg        RegWriteF_out,
    output reg [1:0] ResultSrc_out,
    output reg [31:0] ReadData_out,
    output reg [31:0] ALUResult_out,
    output reg [31:0] pc_plus4_out,
    output reg  [4:0] rd_out
);

    always @(posedge clk) begin
        if (rst) begin
            RegWrite_out  <= 1'b0;
            RegWriteF_out <= 1'b0;
            ResultSrc_out <= 2'b00;
            ReadData_out  <= 32'b0;
            ALUResult_out <= 32'b0;
            pc_plus4_out  <= 32'b0;
            rd_out        <= 5'b0;
        end else begin
            RegWrite_out  <= RegWrite_in;
            RegWriteF_out <= RegWriteF_in;
            ResultSrc_out <= ResultSrc_in;
            ReadData_out  <= ReadData_in;
            ALUResult_out <= ALUResult_in;
            pc_plus4_out  <= pc_plus4_in;
            rd_out        <= rd_in;
        end
    end

endmodule

module ex_mem_reg_sf (
    input        clk,
    input        rst,
    input        RegWrite_in,
    input        RegWriteF_in,
    input        MemWrite_in,
    input  [1:0] ResultSrc_in,
    input  [2:0] LoadType_in,
    input  [1:0] StoreType_in,
    input        FloatStore_in,
    input [31:0] ex_result_in,
    input [31:0] store_data_in,
    input [31:0] pc_plus4_in,
    input  [4:0] rd_in,
    output reg        RegWrite_out,
    output reg        RegWriteF_out,
    output reg        MemWrite_out,
    output reg  [1:0] ResultSrc_out,
    output reg  [2:0] LoadType_out,
    output reg  [1:0] StoreType_out,
    output reg        FloatStore_out,
    output reg [31:0] ex_result_out,
    output reg [31:0] store_data_out,
    output reg [31:0] pc_plus4_out,
    output reg  [4:0] rd_out
);

    always @(posedge clk) begin
        if (rst) begin
            RegWrite_out   <= 1'b0;
            RegWriteF_out  <= 1'b0;
            MemWrite_out   <= 1'b0;
            ResultSrc_out  <= 2'b00;
            LoadType_out   <= 3'b111;
            StoreType_out  <= 2'b11;
            FloatStore_out <= 1'b0;
            ex_result_out  <= 32'b0;
            store_data_out <= 32'b0;
            pc_plus4_out   <= 32'b0;
            rd_out         <= 5'b0;
        end else begin
            RegWrite_out   <= RegWrite_in;
            RegWriteF_out  <= RegWriteF_in;
            MemWrite_out   <= MemWrite_in;
            ResultSrc_out  <= ResultSrc_in;
            LoadType_out   <= LoadType_in;
            StoreType_out  <= StoreType_in;
            FloatStore_out <= FloatStore_in;
            ex_result_out  <= ex_result_in;
            store_data_out <= store_data_in;
            pc_plus4_out   <= pc_plus4_in;
            rd_out         <= rd_in;
        end
    end

endmodule

module instruction_memory_sf (
    input [31:0] A,      //! Endereço de leitura
    output reg [31:0] RD //! Dados lidos da memória de instruções
);

    reg [7:0] memory [0:1023]; //! Memória de instruções byte-addressable

    initial begin
        // Programa: conversão Q16.16 para ponto flutuante, soma e reconversão
        // 00010297 -> auipc t0, 0x10
        memory[10'h000] = 8'h97;
        memory[10'h001] = 8'h02;
        memory[10'h002] = 8'h01;
        memory[10'h003] = 8'h00;
        // 00028293 -> addi t0, t0, 0 (mv t0, t0)
        memory[10'h004] = 8'h93;
        memory[10'h005] = 8'h82;
        memory[10'h006] = 8'h02;
        memory[10'h007] = 8'h00;
        // 0002a283 -> lw t0, 0(t0)
        memory[10'h008] = 8'h83;
        memory[10'h009] = 8'ha2;
        memory[10'h00A] = 8'h02;
        memory[10'h00B] = 8'h00;
        // 00010297 -> auipc t0, 0x10
        memory[10'h00C] = 8'h97;
        memory[10'h00D] = 8'h02;
        memory[10'h00E] = 8'h01;
        memory[10'h00F] = 8'h00;
        // ff828293 -> addi t0, t0, -8
        memory[10'h010] = 8'h93;
        memory[10'h011] = 8'h82;
        memory[10'h012] = 8'h82;
        memory[10'h013] = 8'hff;
        // 0002a303 -> lw t1, 0(t0)
        memory[10'h014] = 8'h03;
        memory[10'h015] = 8'ha3;
        memory[10'h016] = 8'h02;
        memory[10'h017] = 8'h00;
        // 00010297 -> auipc t0, 0x10
        memory[10'h018] = 8'h97;
        memory[10'h019] = 8'h02;
        memory[10'h01A] = 8'h01;
        memory[10'h01B] = 8'h00;
        // ff028293 -> addi t0, t0, -16
        memory[10'h01C] = 8'h93;
        memory[10'h01D] = 8'h82;
        memory[10'h01E] = 8'h02;
        memory[10'h01F] = 8'hff;
        // 0002a383 -> lw t2, 0(t0)
        memory[10'h020] = 8'h83;
        memory[10'h021] = 8'ha3;
        memory[10'h022] = 8'h02;
        memory[10'h023] = 8'h00;
        // 00010297 -> auipc t0, 0x10
        memory[10'h024] = 8'h97;
        memory[10'h025] = 8'h02;
        memory[10'h026] = 8'h01;
        memory[10'h027] = 8'h00;
        // fe828293 -> addi t0, t0, -24
        memory[10'h028] = 8'h93;
        memory[10'h029] = 8'h82;
        memory[10'h02A] = 8'h82;
        memory[10'h02B] = 8'hfe;
        // 0002a403 -> lw s0, 0(t0)
        memory[10'h02C] = 8'h03;
        memory[10'h02D] = 8'ha4;
        memory[10'h02E] = 8'h02;
        memory[10'h02F] = 8'h00;
        // d002f0d3 -> fcvt.s.w ft1, t0
        memory[10'h030] = 8'hd3;
        memory[10'h031] = 8'hf0;
        memory[10'h032] = 8'h02;
        memory[10'h033] = 8'hd0;
        // d0037153 -> fcvt.s.w ft2, t1
        memory[10'h034] = 8'h53;
        memory[10'h035] = 8'h71;
        memory[10'h036] = 8'h03;
        memory[10'h037] = 8'hd0;
        // d003f1d3 -> fcvt.s.w ft3, t2
        memory[10'h038] = 8'hd3;
        memory[10'h039] = 8'hf1;
        memory[10'h03A] = 8'h03;
        memory[10'h03B] = 8'hd0;
        // d0047253 -> fcvt.s.w ft4, s0
        memory[10'h03C] = 8'h53;
        memory[10'h03D] = 8'h72;
        memory[10'h03E] = 8'h04;
        memory[10'h03F] = 8'hd0;
        // 37800537 -> lui a0, 0x37800
        memory[10'h040] = 8'h37;
        memory[10'h041] = 8'h05;
        memory[10'h042] = 8'h80;
        memory[10'h043] = 8'h37;
        // f00504d3 -> fmv.w.x fs1, a0
        memory[10'h044] = 8'hd3;
        memory[10'h045] = 8'h04;
        memory[10'h046] = 8'h05;
        memory[10'h047] = 8'hf0;
        // 1090f0d3 -> fmul.s ft1, ft1, fs1
        memory[10'h048] = 8'hd3;
        memory[10'h049] = 8'hf0;
        memory[10'h04A] = 8'h90;
        memory[10'h04B] = 8'h10;
        // 10917153 -> fmul.s ft2, ft2, fs1
        memory[10'h04C] = 8'h53;
        memory[10'h04D] = 8'h71;
        memory[10'h04E] = 8'h91;
        memory[10'h04F] = 8'h10;
        // 1091f1d3 -> fmul.s ft3, ft3, fs1
        memory[10'h050] = 8'hd3;
        memory[10'h051] = 8'hf1;
        memory[10'h052] = 8'h91;
        memory[10'h053] = 8'h10;
        // 10927253 -> fmul.s ft4, ft4, fs1
        memory[10'h054] = 8'h53;
        memory[10'h055] = 8'h72;
        memory[10'h056] = 8'h92;
        memory[10'h057] = 8'h10;
        // 0020f2d3 -> fadd.s ft5, ft1, ft2
        memory[10'h058] = 8'hd3;
        memory[10'h059] = 8'hf2;
        memory[10'h05A] = 8'h20;
        memory[10'h05B] = 8'h00;
        // 0032f353 -> fadd.s ft6, ft5, ft3
        memory[10'h05C] = 8'h53;
        memory[10'h05D] = 8'hf3;
        memory[10'h05E] = 8'h32;
        memory[10'h05F] = 8'h00;
        // 004373d3 -> fadd.s ft7, ft6, ft4
        memory[10'h060] = 8'hd3;
        memory[10'h061] = 8'h73;
        memory[10'h062] = 8'h43;
        memory[10'h063] = 8'h00;
        // 00010317 -> auipc t1, 0x10
        memory[10'h064] = 8'h17;
        memory[10'h065] = 8'h03;
        memory[10'h066] = 8'h01;
        memory[10'h067] = 8'h00;
        // fac30313 -> addi t1, t1, -84
        memory[10'h068] = 8'h13;
        memory[10'h069] = 8'h03;
        memory[10'h06A] = 8'hc3;
        memory[10'h06B] = 8'hfa;
        // 00732027 -> fsw ft7, 0(t1)
        memory[10'h06C] = 8'h27;
        memory[10'h06D] = 8'h20;
        memory[10'h06E] = 8'h73;
        memory[10'h06F] = 8'h00;
        // c003f4d3 -> fcvt.w.s s1, ft7
        memory[10'h070] = 8'hd3;
        memory[10'h071] = 8'hf4;
        memory[10'h072] = 8'h03;
        memory[10'h073] = 8'hc0;
        // 00010397 -> auipc t2, 0x10
        memory[10'h074] = 8'h97;
        memory[10'h075] = 8'h03;
        memory[10'h076] = 8'h01;
        memory[10'h077] = 8'h00;
        // fa038393 -> addi t2, t2, -96
        memory[10'h078] = 8'h93;
        memory[10'h079] = 8'h83;
        memory[10'h07A] = 8'h03;
        memory[10'h07B] = 8'hfa;
        // 0093a023 -> sw s1, 0(t2)
        memory[10'h07C] = 8'h23;
        memory[10'h07D] = 8'ha0;
        memory[10'h07E] = 8'h93;
        memory[10'h07F] = 8'h00;
        // 00000063 -> beqz zero, 0 (loop)
        memory[10'h080] = 8'h63;
        memory[10'h081] = 8'h00;
        memory[10'h082] = 8'h00;
        memory[10'h083] = 8'h00;
    end

    always @(*) begin
        RD = {memory[A - 32'h1000 + 3], memory[A - 32'h1000 + 2], memory[A - 32'h1000 + 1], memory[A - 32'h1000 + 0]};
    end

endmodule

module program_counter_sf (
    input wire        clk,     //! Sinal de clock
    input wire        rst,     //! Reset síncrono
    input wire        stall,   //! Mantém o PC quando verdadeiro (bolha por hazard)
    input wire [31:0] PCNext,  //! Próximo valor do PC
    output reg [31:0] PC       //! Valor atual do PC
);

    always @(posedge clk) begin
        if (rst) begin
            PC <= 32'h1000; //! Endereço inicial da memória de instruções
        end else if (!stall) begin
            PC <= PCNext;
        end
    end

endmodule

module register_file_sf (
    input clk,         //! Sinal de clock
    input rst,         //! Sinal de reset
    input WE3,         //! Write enable input
    input [4:0] A1,    //! Endereço do primeiro registrador de leitura
    input [4:0] A2,    //! Endereço do segundo registrador de leitura
    input [4:0] A3,    //! Endereço do registrador de escrita
    input [31:0] WD3,  //! Dados a serem escritos no registrador
    output [31:0] RD1, //! Dados lidos do primeiro registrador
    output [31:0] RD2  //! Dados lidos do segundo registrador
);

    integer i;

    reg [31:0] registers [0:31]; //! Banco de registradores de 32 bits

    // Escrita síncrona
    always @(posedge clk, posedge rst) begin : ESCRITA
        if (rst) begin
            for (i = 0; i < 32; i = i + 1) begin : RESET
                registers[i] <= 32'b0;
            end
        end else if (WE3 && (A3 != 5'd0)) begin
            registers[A3] <= WD3; //! Escreve os dados no registrador especificado
        end
    end

    // Leitura combinacional (assíncrona) com suporte a write-first quando há
    // leitura e escrita do mesmo registrador no mesmo ciclo.
    wire forwarding_rd1_int = WE3 && (A3 == A1) && (A3 != 5'd0);
    wire forwarding_rd2_int = WE3 && (A3 == A2) && (A3 != 5'd0);

    assign RD1 = (A1 == 5'd0) ? 32'd0 : (forwarding_rd1_int ? WD3 : registers[A1]);
    assign RD2 = (A2 == 5'd0) ? 32'd0 : (forwarding_rd2_int ? WD3 : registers[A2]);

endmodule

module register_file_f_sf (
    input clk,         //! Sinal de clock
    input rst,         //! Sinal de reset
    input WE3,         //! Habilita escrita no banco de registradores de ponto flutuante
    input [4:0] A1,    //! Endereço do primeiro registrador de leitura (fA)
    input [4:0] A2,    //! Endereço do segundo registrador de leitura (fB)
    input [4:0] A3,    //! Endereço do registrador de escrita
    input [31:0] WD3,  //! Dados a serem escritos no registrador de destino
    output [31:0] RD1, //! Operando A disponibilizado para a FPU
    output [31:0] RD2  //! Operando B disponibilizado para a FPU
);

    integer i;

    reg [31:0] registers [0:31]; //! Banco de 32 registradores em ponto flutuante (f0–f31)

    // Escrita síncrona dos registradores de ponto flutuante
    always @(posedge clk, posedge rst) begin : ESCRITA_F
        if (rst) begin
            for (i = 0; i < 32; i = i + 1) begin : RESET_F
                registers[i] <= 32'b0;
            end
        end else if (WE3) begin
            registers[A3] <= WD3; //! Escreve sempre que habilitado (não há registrador constante)
        end
    end

    // Leitura combinacional dos operandos destinados à FPU com comportamento
    // write-first para disponibilizar imediatamente o valor recém-escrito.
    wire forwarding_rd1_float = WE3 && (A3 == A1);
    wire forwarding_rd2_float = WE3 && (A3 == A2);

    assign RD1 = forwarding_rd1_float ? WD3 : registers[A1];
    assign RD2 = forwarding_rd2_float ? WD3 : registers[A2];

endmodule

module extend_sf (
    input [31:7] instr,      //! Instrução a ser processada
    input [1:0]  immsrc,     //! Comando contendo o tipo de extensão a ser realizado
    output reg [31:0] immext //! Saída contendo a extensão da instrução
);

always @(*) begin
    case (immsrc)
        2'b00: immext = { {20{instr[31]}}, instr[31:20] }; // I-type
        2'b01: immext = { {20{instr[31]}}, instr[31:25], instr[11:7] }; // S-type (store)
        2'b10: immext = { {20{instr[31]}}, instr[7], instr[30:25], instr[11:8], 1'b0 }; // B-type (branches)
        2'b11: immext = { {12{instr[31]}}, instr[19:12], instr[20], instr[30:21], 1'b0 }; // J-type (jal)
        default: immext = 32'bx; // undefined
    endcase
end

endmodule

module ALU_sf (
    input [31:0] SrcA,
    input [31:0] SrcB,
    input [2:0] ALUControl,
    output reg [31:0] ALUResult,
    output reg Zero
);

    always @(*) begin
        case (ALUControl)
            3'b000: ALUResult = SrcA + SrcB; // Soma
            3'b001: ALUResult = SrcA - SrcB; // Subtração
            3'b010: ALUResult = SrcA & SrcB; // AND
            3'b011: ALUResult = SrcA | SrcB; // OR
            3'b101: ALUResult = ($signed(SrcA) < $signed(SrcB)) ? 32'd1 : 32'd0; // SLT
            default: ALUResult = 32'd0;
        endcase

        Zero = (ALUResult == 32'd0);
    end

endmodule

module Mux2x1_sf #(parameter N = 8) (
    input [N-1:0] a,
    input [N-1:0] b,
    input sel,
    output [N-1:0] y
);

    assign y = sel ? b : a;

endmodule

module Mux4x1_sf #(parameter N = 32) (
    input  [N-1:0] a,
    input  [N-1:0] b,
    input  [N-1:0] c,
    input  [N-1:0] d,
    input  [1:0]   sel,
    output [N-1:0] y
);

    assign y = (sel == 2'b00) ? a :
               (sel == 2'b01) ? b :
               (sel == 2'b10) ? c :
                                d;

endmodule

module forwarding_control_sf (
    input  wire [4:0] id_ex_rs1,
    input  wire [4:0] id_ex_rs2,
    input  wire [4:0] id_ex_rs1_f,
    input  wire [4:0] id_ex_rs2_f,
    input  wire [4:0] ex_mem_rd,
    input  wire [4:0] mem_wb_rd,
    input  wire       ex_mem_RegWrite,
    input  wire       mem_wb_RegWrite,
    input  wire       ex_mem_RegWriteF,
    input  wire       mem_wb_RegWriteF,
    output reg  [1:0] forwardA_int,
    output reg  [1:0] forwardB_int,
    output reg  [1:0] forwardA_float,
    output reg  [1:0] forwardB_float
);

    always @(*) begin
        forwardA_int   = 2'b00;
        forwardB_int   = 2'b00;
        forwardA_float = 2'b00;
        forwardB_float = 2'b00;

        if (ex_mem_RegWrite && (ex_mem_rd != 5'd0) && (ex_mem_rd == id_ex_rs1)) begin
            forwardA_int = 2'b10;
        end else if (mem_wb_RegWrite && (mem_wb_rd != 5'd0) && (mem_wb_rd == id_ex_rs1)) begin
            forwardA_int = 2'b01;
        end

        if (ex_mem_RegWrite && (ex_mem_rd != 5'd0) && (ex_mem_rd == id_ex_rs2)) begin
            forwardB_int = 2'b10;
        end else if (mem_wb_RegWrite && (mem_wb_rd != 5'd0) && (mem_wb_rd == id_ex_rs2)) begin
            forwardB_int = 2'b01;
        end

        if (ex_mem_RegWriteF && (ex_mem_rd != 5'd0) && (ex_mem_rd == id_ex_rs1_f)) begin
            forwardA_float = 2'b10;
        end else if (mem_wb_RegWriteF && (mem_wb_rd != 5'd0) && (mem_wb_rd == id_ex_rs1_f)) begin
            forwardA_float = 2'b01;
        end

        if (ex_mem_RegWriteF && (ex_mem_rd != 5'd0) && (ex_mem_rd == id_ex_rs2_f)) begin
            forwardB_float = 2'b10;
        end else if (mem_wb_RegWriteF && (mem_wb_rd != 5'd0) && (mem_wb_rd == id_ex_rs2_f)) begin
            forwardB_float = 2'b01;
        end
    end

endmodule

module adder_sf (
    input wire [31:0] a,
    input wire [31:0] b,
    output wire [31:0] sum
);

    assign sum = a + b;

endmodule

module FPU (
    input  [31:0] A,    //! Operando A
    input  [31:0] B,    //! Operando B
    input  [4:0]  sel,  //! Seleção da operação
    output reg [31:0] Result //! Resultado em ponto flutuante
);

    wire [31:0] res1, res2;
    wire [1:0]  res3;
    wire [31:0] res4, res5;
    reg         add_sub;

    adder_FPU adder_inst (
        .a       (A),
        .b       (B),
        .op      (add_sub),
        .results (res1),
        .compare (res3)
    );

    multiply multiply_inst (
        .iA    (A),
        .iB    (B),
        .oProd (res2)
    );

    fp2int fp2int_inst (
        .A (A),
        .B (res5)
    );

    int2fp int2fp_inst (
        .A (A),
        .B (res4)
    );

    always @(*) begin
        case (sel)
            5'd0:  begin add_sub = 1'b0; Result = A; end
            5'd1:  begin add_sub = 1'b0; Result = B; end
            5'd2:  begin add_sub = 1'b0; Result = {~A[31], A[30:0]}; end
            5'd3:  begin add_sub = 1'b0; Result = {~B[31], B[30:0]}; end
            5'd4:  begin add_sub = 1'b0; Result = res1; end // A+B
            5'd5:  begin add_sub = 1'b1; Result = res1; end // A-B
            5'd6:  begin add_sub = 1'b0; Result = res2; end // A*B
            5'd7:  begin add_sub = 1'b0; Result = (res3 == 1) ? A : B; end // min
            5'd8:  begin add_sub = 1'b0; Result = (res3 == 0) ? A : B; end // max
            5'd9:  begin add_sub = 1'b0; Result = (res3 == 2) ? 32'd1 : 32'd0; end // feq.s
            5'd10: begin add_sub = 1'b0; Result = (res3 == 1) ? 32'd1 : 32'd0; end // flt.s
            5'd11: begin add_sub = 1'b0; Result = ((res3 == 1) || (res3 == 2)) ? 32'd1 : 32'd0; end // fle.s
            5'd12: begin add_sub = 1'b0; Result = A; end // fmv.x.w (A já inteiro)
            5'd13: begin add_sub = 1'b0; Result = A; end // fmv.w.x (A já em inteiro)
            5'd14: begin add_sub = 1'b0; Result = res4; end // fcvt.s.w
            5'd15: begin add_sub = 1'b0; Result = res5; end // fcvt.w.s
            default: begin add_sub = 1'b0; Result = 32'b0; end
        endcase
    end

endmodule

module adder_FPU (
    input [31:0] a,
    input [31:0] b,
    input        op,
    output reg [31:0] results,
    output reg [1:0]  compare
);

    reg [7:0]  a_exp, b_exp, r_exp;
    reg [31:0] a_m, b_m, r_m, prm;
    reg [1:0]  mag;
    integer    i;
    reg        state;

    always @(*) begin
        a_exp = a[30:23];
        a_m   = {9'b000000001, a[22:0]};
        b_exp = b[30:23];
        b_m   = {9'b000000001, b[22:0]};

        if (a_exp > b_exp) begin
            mag = 0;
            compare = 0;
            b_m = b_m >> (a_exp - b_exp);
            b_exp = b_exp + (a_exp - b_exp);
        end else if (a_exp < b_exp) begin
            mag = 1;
            compare = 1;
            a_m = a_m >> (b_exp - a_exp);
            a_exp = a_exp + (b_exp - a_exp);
        end else begin
            mag = 2;
            compare = 2;
            if (a_m > b_m)
                compare = 0;
            else if (a_m < b_m)
                compare = 1;
            else
                compare = 2;
        end

        if ((a[31] == b[31] && !op) || (a[31] != b[31] && op)) begin
            results[31] = a[31];
            r_m = a_m + b_m;
        end else begin
            if (mag == 0) begin
                r_m = a_m - b_m;
                results[31] = op ? 1'b0 : a[31];
            end else if (mag == 1) begin
                r_m = b_m - a_m;
                results[31] = op ? (b[31] ? 1'b0 : 1'b1) : b[31];
            end else if (mag == 2) begin
                if (a_m >= b_m) begin
                    r_m = a_m - b_m;
                    results[31] = op ? 1'b0 : a[31];
                end else begin
                    r_m = b_m - a_m;
                    results[31] = op ? (b[31] ? 1'b0 : 1'b1) : b[31];
                end
            end else begin
                r_m = b_m - a_m;
                results[31] = 1'b0;
            end
        end

        state = 1'b1;
        i = 31;
        while (state == 1'b1) begin
            if (r_m[i] == 1'b1 || i == 0)
                state = 1'b0;
            i = i - 1;
        end

        r_exp = a_exp + i - 22;
        if ((i - 22) > 0)
            prm = r_m >> $unsigned(i - 22);
        else if ((i - 22) < 0)
            prm = r_m << $unsigned(22 - i);
        else
            prm = r_m;

        results[30:23] = r_exp;
        results[22:0]  = prm[22:0];
    end

endmodule

module multiply (
    input  [31:0] iA,
    input  [31:0] iB,
    output [31:0] oProd
);

    wire A_s = iA[31];
    wire [7:0] A_e = iA[30:23];
    wire [22:0] A_f = {1'b1, iA[22:1]};

    wire B_s = iB[31];
    wire [7:0] B_e = iB[30:23];
    wire [22:0] B_f = {1'b1, iB[22:1]};

    wire oProd_s = A_s ^ B_s;

    wire [45:0] pre_prod_frac = A_f * B_f;
    wire [8:0]  pre_prod_exp  = A_e + B_e;

    wire [7:0]  oProd_e = pre_prod_frac[45] ? (pre_prod_exp - 9'd126) : (pre_prod_exp - 9'd127);
    wire [22:0] oProd_f = pre_prod_frac[45] ? pre_prod_frac[44:22] : pre_prod_frac[43:21];

    wire underflow = pre_prod_exp < 9'h80;

    assign oProd = underflow ? 32'b0 :
                   (B_e == 8'd0) ? 32'b0 :
                   (A_e == 8'd0) ? 32'b0 :
                   {oProd_s, oProd_e, oProd_f};

endmodule

module fp2int (
    input  [31:0] A,
    output [31:0] B
);

    wire [23:0] m = {1'd1, A[22:0]};
    wire [7:0]  e = A[30:23];

    wire [31:0] abs_int = (A[30:23] >= 8'd127) ? ((m << 7) >> (8'd157 - e)) : 32'd0;
    assign B = A[31] ? (~abs_int) + 32'd1 : abs_int;

endmodule

module int2fp (
    input  [31:0] A,
    output reg [31:0] B
);

    reg [31:0] abs;
    reg        sign;
    reg [22:0] mout;
    reg [7:0]  eout;
    reg [7:0]  num_zeros;

    always @(*) begin
        abs = A[31] ? (~A) + 32'd1 : A;

        if (abs[30:0] == 31'd0) begin
            eout      = 8'd0;
            mout      = 23'd0;
            sign      = 1'b0;
            num_zeros = 8'd0;
        end else begin
            casez (abs[30:0])
                31'b1?????????????????????????????? : num_zeros = 8'd0;
                31'b01????????????????????????????? : num_zeros = 8'd1;
                31'b001???????????????????????????? : num_zeros = 8'd2;
                31'b0001??????????????????????????? : num_zeros = 8'd3;
                31'b00001?????????????????????????? : num_zeros = 8'd4;
                31'b000001????????????????????????? : num_zeros = 8'd5;
                31'b0000001???????????????????????? : num_zeros = 8'd6;
                31'b00000001??????????????????????? : num_zeros = 8'd7;
                31'b000000001?????????????????????? : num_zeros = 8'd8;
                31'b0000000001????????????????????? : num_zeros = 8'd9;
                31'b00000000001???????????????????? : num_zeros = 8'd10;
                31'b000000000001???????????????????: num_zeros = 8'd11;
                31'b0000000000001?????????????????? : num_zeros = 8'd12;
                31'b00000000000001????????????????? : num_zeros = 8'd13;
                31'b000000000000001???????????????? : num_zeros = 8'd14;
                31'b0000000000000001??????????????? : num_zeros = 8'd15;
                31'b00000000000000001?????????????? : num_zeros = 8'd16;
                31'b000000000000000001????????????? : num_zeros = 8'd17;
                31'b0000000000000000001???????????? : num_zeros = 8'd18;
                31'b00000000000000000001??????????? : num_zeros = 8'd19;
                31'b000000000000000000001?????????? : num_zeros = 8'd20;
                31'b0000000000000000000001????????? : num_zeros = 8'd21;
                31'b00000000000000000000001???????? : num_zeros = 8'd22;
                31'b000000000000000000000001??????? : num_zeros = 8'd23;
                31'b0000000000000000000000001?????? : num_zeros = 8'd24;
                31'b00000000000000000000000001????? : num_zeros = 8'd25;
                31'b000000000000000000000000001???? : num_zeros = 8'd26;
                31'b0000000000000000000000000001??? : num_zeros = 8'd27;
                31'b00000000000000000000000000001?? : num_zeros = 8'd28;
                31'b000000000000000000000000000001? : num_zeros = 8'd29;
                31'b0000000000000000000000000000001 : num_zeros = 8'd30;
                default                              : num_zeros = 8'd31;
            endcase

            mout  = (abs[30:0] << num_zeros) >> 7;
            eout  = 8'd157 - num_zeros;
            sign  = A[31];
        end

        B = {sign, eout, mout};
    end

endmodule

module memByteAddressable32WF_sf #(
    parameter DATA_WIDTH    = 32, //! Largura total da palavra
    parameter ADDRESS_WIDTH = 8   //! Endereço em bytes (2^8 = 256 bytes)
) (
    input  wire                     clk,        //! Clock da memória de dados
    input  wire [3:0]               byteEnable, //! Máscara de habilitação por byte
    input  wire [ADDRESS_WIDTH-1:0] addr,       //! Endereço em bytes
    input  wire [DATA_WIDTH-1:0]    din,        //! Dado de entrada (escrita)
    output wire [DATA_WIDTH-1:0]    dout        //! Dado de saída (leitura)
);

    localparam WORD_ADDR_WIDTH = (ADDRESS_WIDTH > 2) ? (ADDRESS_WIDTH-2) : 1; //! Endereço por palavras (4 bytes)
    wire [WORD_ADDR_WIDTH-1:0] word_addr = addr[ADDRESS_WIDTH-1:2]; //! Converte endereço em bytes para palavras

    memory_write_first_sf #(
        .DATA_WIDTH(8),
        .ADDRESS_WIDTH(WORD_ADDR_WIDTH),
        .BYTE_LANE(0)
    ) mem_byte0 (
        .clk(clk),
        .we(byteEnable[0]),
        .addr(word_addr),
        .din(din[7:0]),
        .dout(dout[7:0])
    );

    memory_write_first_sf #(
        .DATA_WIDTH(8),
        .ADDRESS_WIDTH(WORD_ADDR_WIDTH),
        .BYTE_LANE(1)
    ) mem_byte1 (
        .clk(clk),
        .we(byteEnable[1]),
        .addr(word_addr),
        .din(din[15:8]),
        .dout(dout[15:8])
    );

    memory_write_first_sf #(
        .DATA_WIDTH(8),
        .ADDRESS_WIDTH(WORD_ADDR_WIDTH),
        .BYTE_LANE(2)
    ) mem_byte2 (
        .clk(clk),
        .we(byteEnable[2]),
        .addr(word_addr),
        .din(din[23:16]),
        .dout(dout[23:16])
    );

    memory_write_first_sf #(
        .DATA_WIDTH(8),
        .ADDRESS_WIDTH(WORD_ADDR_WIDTH),
        .BYTE_LANE(3)
    ) mem_byte3 (
        .clk(clk),
        .we(byteEnable[3]),
        .addr(word_addr),
        .din(din[31:24]),
        .dout(dout[31:24])
    );

endmodule

module memory_write_first_sf #(
    parameter DATA_WIDTH = 8,          //! Largura dos dados (em bits)
    parameter ADDRESS_WIDTH = 4,       //! Número de bits do endereço
    parameter integer BYTE_LANE = -1   //! Identifica o byte lane para pré-carga (-1 desabilita)
) (
    input  wire                     clk,  //! Clock da memória
    input  wire                     we,   //! Habilitação de escrita
    input  wire [ADDRESS_WIDTH-1:0] addr, //! Endereço da palavra
    input  wire [DATA_WIDTH-1:0]    din,  //! Dado de entrada
    output wire [DATA_WIDTH-1:0]    dout  //! Dado de saída (leitura assíncrona)
);

    localparam DEPTH = 1 << ADDRESS_WIDTH; //! Número total de posições na memória

    reg [DATA_WIDTH-1:0] mem [0:DEPTH-1]; //! Array que armazena os dados
    integer init_idx; //! Índice auxiliar para inicialização

    initial begin
        for (init_idx = 0; init_idx < DEPTH; init_idx = init_idx + 1) begin
            mem[init_idx] = {DATA_WIDTH{1'b0}}; //! Garante memória zerada e evita valores indefinidos
        end

        if (BYTE_LANE == 0) begin
            if (DEPTH > 0) mem[0] = 8'h9a;   //! val1 LSB
            if (DEPTH > 1) mem[1] = 8'h00;   //! val2 LSB
            if (DEPTH > 2) mem[2] = 8'h00;   //! val3 LSB
            if (DEPTH > 3) mem[3] = 8'h00;   //! val4 LSB
            if (DEPTH > 4) mem[4] = 8'h00;   //! result_fp LSB
            if (DEPTH > 5) mem[5] = 8'h00;   //! result_int LSB
        end else if (BYTE_LANE == 1) begin
            if (DEPTH > 0) mem[0] = 8'h19;   //! val1 byte 1
            if (DEPTH > 1) mem[1] = 8'h80;   //! val2 byte 1
            if (DEPTH > 2) mem[2] = 8'h40;   //! val3 byte 1
            if (DEPTH > 3) mem[3] = 8'h20;   //! val4 byte 1
            if (DEPTH > 4) mem[4] = 8'h00;   //! result_fp byte 1
            if (DEPTH > 5) mem[5] = 8'h00;   //! result_int byte 1
        end else if (BYTE_LANE == 2) begin
            if (DEPTH > 0) mem[0] = 8'h01;   //! val1 byte 2
            if (DEPTH > 1) mem[1] = 8'h02;   //! val2 byte 2
            if (DEPTH > 2) mem[2] = 8'hfc;   //! val3 byte 2
            if (DEPTH > 3) mem[3] = 8'h04;   //! val4 byte 2
            if (DEPTH > 4) mem[4] = 8'h00;   //! result_fp byte 2
            if (DEPTH > 5) mem[5] = 8'h00;   //! result_int byte 2
        end else if (BYTE_LANE == 3) begin
            if (DEPTH > 0) mem[0] = 8'h00;   //! val1 MSB
            if (DEPTH > 1) mem[1] = 8'h00;   //! val2 MSB
            if (DEPTH > 2) mem[2] = 8'hff;   //! val3 MSB
            if (DEPTH > 3) mem[3] = 8'h00;   //! val4 MSB
            if (DEPTH > 4) mem[4] = 8'h00;   //! result_fp MSB
            if (DEPTH > 5) mem[5] = 8'h00;   //! result_int MSB
        end
    end

    always @(posedge clk) begin
        if (we) begin
            mem[addr] <= din; //! Escrita síncrona
        end
    end

    assign dout = mem[addr]; //! Leitura assíncrona (write-first devido ao uso de atribuição não bloqueante)

endmodule
