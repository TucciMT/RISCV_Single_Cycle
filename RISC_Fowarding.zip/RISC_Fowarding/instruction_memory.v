module instruction_memory (
    input [31:0] A,      //! Endereço de leitura
    output reg [31:0] RD //! Dados lidos da memória de instruções
);

    reg [7:0] memory [0:1023]; //! Memória de instruções byte-addressable

    initial begin
        /*
         * Programa carregado (referência em assembly):
         *
         * .data
         *     val1:      .word 72090      # 1.1 em Q16.16
         *     val2:      .word 163840     # 2.5
         *     val3:      .word -245760    # -3.75
         *     val4:      .word 270336     # 4.125
         *     result_fp: .word 0          # espaço para FP
         *     result_int:.word 0          # espaço para inteiro
         *
         * .text
         * .globl _start
         * _start:
         *     auipc   t0, 0x10
         *     addi    t0, t0, 0
         *     lw      t0, 0(t0)
         *     auipc   t0, 0x10
         *     addi    t0, t0, -8
         *     lw      t1, 0(t0)
         *     auipc   t0, 0x10
         *     addi    t0, t0, -16
         *     lw      t2, 0(t0)
         *     auipc   t0, 0x10
         *     addi    t0, t0, -24
         *     lw      s0, 0(t0)
         *     fcvt.s.w ft1, t0
         *     fcvt.s.w ft2, t1
         *     fcvt.s.w ft3, t2
         *     fcvt.s.w ft4, s0
         *     lui     a0, 0x37800
         *     fmv.w.x fs1, a0
         *     fmul.s  ft1, ft1, fs1
         *     fmul.s  ft2, ft2, fs1
         *     fmul.s  ft3, ft3, fs1
         *     fmul.s  ft4, ft4, fs1
         *     fadd.s  ft5, ft1, ft2
         *     fadd.s  ft6, ft5, ft3
         *     fadd.s  ft7, ft6, ft4
         *     auipc   t1, 0x10
         *     addi    t1, t1, -84
         *     fsw     ft7, 0(t1)
         *     fcvt.w.s s1, ft7
         *     auipc   t2, 0x10
         *     addi    t2, t2, -96
         *     sw      s1, 0(t2)
         * end:
         *     beqz    zero, end
         */
        // Programa: conversão Q16.16 para ponto flutuante, soma e reconversão
        // 00010297 -> auipc t0, 0x10
        memory[10'h000] = 8'h97;
        memory[10'h001] = 8'h02;
        memory[10'h002] = 8'h01;
        memory[10'h003] = 8'h00;
        // 00028293 -> addi t0, t0, 0 (mv t0, t0)
        memory[10'h004] = 8'h93;
        memory[10'h005] = 8'h82;
        memory[10'h006] = 8'h02;
        memory[10'h007] = 8'h00;
        // 0002a283 -> lw t0, 0(t0)
        memory[10'h008] = 8'h83;
        memory[10'h009] = 8'ha2;
        memory[10'h00A] = 8'h02;
        memory[10'h00B] = 8'h00;
        // 00010297 -> auipc t0, 0x10
        memory[10'h00C] = 8'h97;
        memory[10'h00D] = 8'h02;
        memory[10'h00E] = 8'h01;
        memory[10'h00F] = 8'h00;
        // ff828293 -> addi t0, t0, -8
        memory[10'h010] = 8'h93;
        memory[10'h011] = 8'h82;
        memory[10'h012] = 8'h82;
        memory[10'h013] = 8'hff;
        // 0002a303 -> lw t1, 0(t0)
        memory[10'h014] = 8'h03;
        memory[10'h015] = 8'ha3;
        memory[10'h016] = 8'h02;
        memory[10'h017] = 8'h00;
        // 00010297 -> auipc t0, 0x10
        memory[10'h018] = 8'h97;
        memory[10'h019] = 8'h02;
        memory[10'h01A] = 8'h01;
        memory[10'h01B] = 8'h00;
        // ff028293 -> addi t0, t0, -16
        memory[10'h01C] = 8'h93;
        memory[10'h01D] = 8'h82;
        memory[10'h01E] = 8'h02;
        memory[10'h01F] = 8'hff;
        // 0002a383 -> lw t2, 0(t0)
        memory[10'h020] = 8'h83;
        memory[10'h021] = 8'ha3;
        memory[10'h022] = 8'h02;
        memory[10'h023] = 8'h00;
        // 00010297 -> auipc t0, 0x10
        memory[10'h024] = 8'h97;
        memory[10'h025] = 8'h02;
        memory[10'h026] = 8'h01;
        memory[10'h027] = 8'h00;
        // fe828293 -> addi t0, t0, -24
        memory[10'h028] = 8'h93;
        memory[10'h029] = 8'h82;
        memory[10'h02A] = 8'h82;
        memory[10'h02B] = 8'hfe;
        // 0002a403 -> lw s0, 0(t0)
        memory[10'h02C] = 8'h03;
        memory[10'h02D] = 8'ha4;
        memory[10'h02E] = 8'h02;
        memory[10'h02F] = 8'h00;
        // d002f0d3 -> fcvt.s.w ft1, t0
        memory[10'h030] = 8'hd3;
        memory[10'h031] = 8'hf0;
        memory[10'h032] = 8'h02;
        memory[10'h033] = 8'hd0;
        // d0037153 -> fcvt.s.w ft2, t1
        memory[10'h034] = 8'h53;
        memory[10'h035] = 8'h71;
        memory[10'h036] = 8'h03;
        memory[10'h037] = 8'hd0;
        // d003f1d3 -> fcvt.s.w ft3, t2
        memory[10'h038] = 8'hd3;
        memory[10'h039] = 8'hf1;
        memory[10'h03A] = 8'h03;
        memory[10'h03B] = 8'hd0;
        // d0047253 -> fcvt.s.w ft4, s0
        memory[10'h03C] = 8'h53;
        memory[10'h03D] = 8'h72;
        memory[10'h03E] = 8'h04;
        memory[10'h03F] = 8'hd0;
        // 37800537 -> lui a0, 0x37800
        memory[10'h040] = 8'h37;
        memory[10'h041] = 8'h05;
        memory[10'h042] = 8'h80;
        memory[10'h043] = 8'h37;
        // f00504d3 -> fmv.w.x fs1, a0
        memory[10'h044] = 8'hd3;
        memory[10'h045] = 8'h04;
        memory[10'h046] = 8'h05;
        memory[10'h047] = 8'hf0;
        // 1090f0d3 -> fmul.s ft1, ft1, fs1
        memory[10'h048] = 8'hd3;
        memory[10'h049] = 8'hf0;
        memory[10'h04A] = 8'h90;
        memory[10'h04B] = 8'h10;
        // 10917153 -> fmul.s ft2, ft2, fs1
        memory[10'h04C] = 8'h53;
        memory[10'h04D] = 8'h71;
        memory[10'h04E] = 8'h91;
        memory[10'h04F] = 8'h10;
        // 1091f1d3 -> fmul.s ft3, ft3, fs1
        memory[10'h050] = 8'hd3;
        memory[10'h051] = 8'hf1;
        memory[10'h052] = 8'h91;
        memory[10'h053] = 8'h10;
        // 10927253 -> fmul.s ft4, ft4, fs1
        memory[10'h054] = 8'h53;
        memory[10'h055] = 8'h72;
        memory[10'h056] = 8'h92;
        memory[10'h057] = 8'h10;
        // 0020f2d3 -> fadd.s ft5, ft1, ft2
        memory[10'h058] = 8'hd3;
        memory[10'h059] = 8'hf2;
        memory[10'h05A] = 8'h20;
        memory[10'h05B] = 8'h00;
        // 0032f353 -> fadd.s ft6, ft5, ft3
        memory[10'h05C] = 8'h53;
        memory[10'h05D] = 8'hf3;
        memory[10'h05E] = 8'h32;
        memory[10'h05F] = 8'h00;
        // 004373d3 -> fadd.s ft7, ft6, ft4
        memory[10'h060] = 8'hd3;
        memory[10'h061] = 8'h73;
        memory[10'h062] = 8'h43;
        memory[10'h063] = 8'h00;
        // 00010317 -> auipc t1, 0x10
        memory[10'h064] = 8'h17;
        memory[10'h065] = 8'h03;
        memory[10'h066] = 8'h01;
        memory[10'h067] = 8'h00;
        // fac30313 -> addi t1, t1, -84
        memory[10'h068] = 8'h13;
        memory[10'h069] = 8'h03;
        memory[10'h06A] = 8'hc3;
        memory[10'h06B] = 8'hfa;
        // 00732027 -> fsw ft7, 0(t1)
        memory[10'h06C] = 8'h27;
        memory[10'h06D] = 8'h20;
        memory[10'h06E] = 8'h73;
        memory[10'h06F] = 8'h00;
        // c003f4d3 -> fcvt.w.s s1, ft7
        memory[10'h070] = 8'hd3;
        memory[10'h071] = 8'hf4;
        memory[10'h072] = 8'h03;
        memory[10'h073] = 8'hc0;
        // 00010397 -> auipc t2, 0x10
        memory[10'h074] = 8'h97;
        memory[10'h075] = 8'h03;
        memory[10'h076] = 8'h01;
        memory[10'h077] = 8'h00;
        // fa038393 -> addi t2, t2, -96
        memory[10'h078] = 8'h93;
        memory[10'h079] = 8'h83;
        memory[10'h07A] = 8'h03;
        memory[10'h07B] = 8'hfa;
        // 0093a023 -> sw s1, 0(t2)
        memory[10'h07C] = 8'h23;
        memory[10'h07D] = 8'ha0;
        memory[10'h07E] = 8'h93;
        memory[10'h07F] = 8'h00;
        // 00000063 -> beqz zero, 0 (loop)
        memory[10'h080] = 8'h63;
        memory[10'h081] = 8'h00;
        memory[10'h082] = 8'h00;
        memory[10'h083] = 8'h00;
    end

    always @(*) begin
        RD = {memory[A - 32'h1000 + 3], memory[A - 32'h1000 + 2], memory[A - 32'h1000 + 1], memory[A - 32'h1000 + 0]};
    end

endmodule
