module Mux4x1 #(parameter N = 32) (
    input  [N-1:0] a,
    input  [N-1:0] b,
    input  [N-1:0] c,
    input  [N-1:0] d,
    input  [1:0]   sel,
    output [N-1:0] y
);

    assign y = (sel == 2'b00) ? a :
               (sel == 2'b01) ? b :
               (sel == 2'b10) ? c :
                                d;

endmodule

module forwarding_control (
    input  wire [4:0] id_ex_rs1,
    input  wire [4:0] id_ex_rs2,
    input  wire [4:0] id_ex_rs1_f,
    input  wire [4:0] id_ex_rs2_f,
    input  wire [4:0] ex_mem_rd,
    input  wire [4:0] mem_wb_rd,
    input  wire       ex_mem_RegWrite,
    input  wire       mem_wb_RegWrite,
    input  wire       ex_mem_RegWriteF,
    input  wire       mem_wb_RegWriteF,
    output reg  [1:0] forwardA_int,
    output reg  [1:0] forwardB_int,
    output reg  [1:0] forwardA_float,
    output reg  [1:0] forwardB_float
);

    always @(*) begin
        forwardA_int   = 2'b00;
        forwardB_int   = 2'b00;
        forwardA_float = 2'b00;
        forwardB_float = 2'b00;

        if (ex_mem_RegWrite && (ex_mem_rd != 5'd0) && (ex_mem_rd == id_ex_rs1)) begin
            forwardA_int = 2'b10;
        end else if (mem_wb_RegWrite && (mem_wb_rd != 5'd0) && (mem_wb_rd == id_ex_rs1)) begin
            forwardA_int = 2'b01;
        end

        if (ex_mem_RegWrite && (ex_mem_rd != 5'd0) && (ex_mem_rd == id_ex_rs2)) begin
            forwardB_int = 2'b10;
        end else if (mem_wb_RegWrite && (mem_wb_rd != 5'd0) && (mem_wb_rd == id_ex_rs2)) begin
            forwardB_int = 2'b01;
        end

        if (ex_mem_RegWriteF && (ex_mem_rd != 5'd0) && (ex_mem_rd == id_ex_rs1_f)) begin
            forwardA_float = 2'b10;
        end else if (mem_wb_RegWriteF && (mem_wb_rd != 5'd0) && (mem_wb_rd == id_ex_rs1_f)) begin
            forwardA_float = 2'b01;
        end

        if (ex_mem_RegWriteF && (ex_mem_rd != 5'd0) && (ex_mem_rd == id_ex_rs2_f)) begin
            forwardB_float = 2'b10;
        end else if (mem_wb_RegWriteF && (mem_wb_rd != 5'd0) && (mem_wb_rd == id_ex_rs2_f)) begin
            forwardB_float = 2'b01;
        end
    end

endmodule
