module Control_Unit (
    input  [6:0] Op,          //! Campo opcode da instrução
    input  [2:0] funct3,      //! Campo funct3 da instrução
    input  [6:0] funct7,      //! Campo funct7 completo da instrução
    input  [4:0] rs2,         //! Campo rs2 utilizado por instruções em ponto flutuante
    output       Branch,      //! Indica se a instrução é um branch condicional
    output [1:0] ResultSrc,   //! Seleciona a fonte de dados para Write Back (ALU, Memória ou PC+4)
    output       MemWrite,    //! Habilita escrita na memória de dados
    output       ALUSrc,      //! Seleciona entre operando do registrador ou imediato para a ALU
    output       ALUSrcA_PC,  //! Seleciona o PC como operando A da ALU
    output [1:0] ImmSrc,      //! Define o tipo de extensão a ser aplicado ao imediato
    output       RegWrite,    //! Habilita escrita no banco de registradores inteiros
    output       RegWriteF,   //! Habilita escrita no banco de registradores de ponto flutuante
    output       FloatOp,     //! Seleciona o resultado da FPU
    output [4:0] FPUControl,  //! Operação da FPU
    output       FPUSrcAInt,  //! Seleciona o operando A da FPU a partir do banco inteiro
    output       FPUSrcBInt,  //! Seleciona o operando B da FPU a partir do banco inteiro
    output       Jump,        //! Indica instrução JAL (desvio incondicional)
    output [2:0] LoadType,    //! Define como os dados carregados devem ser ajustados (sinal/zero)
    output [1:0] StoreType,   //! Define o tamanho da escrita na memória de dados
    output       StoreFloat,  //! Indica quando o armazenamento utiliza registradores F
    output [2:0] ALUControl   //! Define a operação realizada pela ALU
);

    //! Sinal intermediário que identifica qual operação a ALU deve executar
    wire [1:0] ALUOp;

    Main_decoder MainDecoder (
        .Op(Op),
        .funct3(funct3),
        .funct7(funct7),
        .rs2(rs2),
        .Branch(Branch),
        .ResultSrc(ResultSrc),
        .MemWrite(MemWrite),
        .ALUSrc(ALUSrc),
        .ALUSrcA_PC(ALUSrcA_PC),
        .ImmSrc(ImmSrc),
        .RegWrite(RegWrite),
        .RegWriteF(RegWriteF),
        .FloatOp(FloatOp),
        .FPUControl(FPUControl),
        .FPUSrcAInt(FPUSrcAInt),
        .FPUSrcBInt(FPUSrcBInt),
        .Jump(Jump),
        .LoadType(LoadType),
        .StoreType(StoreType),
        .StoreFloat(StoreFloat),
        .ALUOp(ALUOp)
    );

    ALU_decoder ALUDecoder (
        .ALUOp(ALUOp),
        .funct3(funct3),
        .funct7(funct7[5]),
        .op(Op[5]),
        .ALUControl(ALUControl)
    );

endmodule
