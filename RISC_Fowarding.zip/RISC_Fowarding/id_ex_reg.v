module id_ex_reg (
    input        clk,               //! Sinal de clock
    input        rst,               //! Sinal de reset síncrono
    input        flush,             //! Quando ativo, anula a instrução em execução
    input        RegWrite_in,       //! Controle de escrita no Write Back
    input        RegWriteF_in,      //! Controle de escrita no banco de registradores F
    input        MemWrite_in,       //! Controle de escrita na memória de dados
    input  [1:0] ResultSrc_in,      //! Seleção da fonte de dados para Write Back
    input        Branch_in,         //! Indica se a instrução é um branch
    input        Jump_in,           //! Indica se a instrução é um jump (JAL)
    input        ALUSrc_in,         //! Seleção do segundo operando da ALU
    input  [2:0] ALUControl_in,     //! Operação a ser executada pela ALU
    input  [4:0] FPUControl_in,     //! Operação a ser executada pela FPU
    input        FloatOp_in,        //! Seleciona resultado da FPU
    input        FPUSrcAInt_in,     //! Seleção da origem do operando A da FPU
    input        FPUSrcBInt_in,     //! Seleção da origem do operando B da FPU
    input        FloatStore_in,     //! Indica armazenamentos vindos do banco F
    input  [2:0] LoadType_in,       //! Tipo de carga propagado para MEM
    input  [1:0] StoreType_in,      //! Tipo de armazenamento propagado para MEM
    input        ALUSrcA_PC_in,     //! Seleciona o PC como operando A da ALU
    input [31:0] pc_in,             //! PC do estágio ID (utilizado para cálculo de branches)
    input [31:0] pc_plus4_in,       //! PC+4 utilizado para escrita no Write Back (JAL)
    input [31:0] rd1_in,            //! Operando A da ALU
    input [31:0] rd2_in,            //! Operando B (antes da seleção ALUSrc)
    input [31:0] frd1_in,           //! Operando A da FPU
    input [31:0] frd2_in,           //! Operando B da FPU
    input [31:0] imm_in,            //! Imediato estendido
    input  [4:0] rs1_in,            //! Campo rs1 da instrução
    input  [4:0] rs2_in,            //! Campo rs2 da instrução
    input  [4:0] rd_in,             //! Registrador destino
    output reg        RegWrite_out,
    output reg        RegWriteF_out,
    output reg        MemWrite_out,
    output reg [1:0] ResultSrc_out,
    output reg        Branch_out,
    output reg        Jump_out,
    output reg        ALUSrc_out,
    output reg  [2:0] ALUControl_out,
    output reg  [4:0] FPUControl_out,
    output reg        FloatOp_out,
    output reg        FPUSrcAInt_out,
    output reg        FPUSrcBInt_out,
    output reg        FloatStore_out,
    output reg  [2:0] LoadType_out,
    output reg  [1:0] StoreType_out,
    output reg        ALUSrcA_PC_out,
    output reg [31:0] pc_out,
    output reg [31:0] pc_plus4_out,
    output reg [31:0] rd1_out,
    output reg [31:0] rd2_out,
    output reg [31:0] frd1_out,
    output reg [31:0] frd2_out,
    output reg [31:0] imm_out,
    output reg  [4:0] rs1_out,
    output reg  [4:0] rs2_out,
    output reg  [4:0] rd_out
);

    always @(posedge clk) begin
        if (rst || flush) begin
            RegWrite_out    <= 1'b0;
            RegWriteF_out   <= 1'b0;
            MemWrite_out    <= 1'b0;
            ResultSrc_out   <= 2'b00;
            Branch_out      <= 1'b0;
            Jump_out        <= 1'b0;
            ALUSrc_out      <= 1'b0;
            ALUControl_out  <= 3'b000;
            FPUControl_out  <= 5'b0;
            FloatOp_out     <= 1'b0;
            FPUSrcAInt_out  <= 1'b0;
            FPUSrcBInt_out  <= 1'b0;
            FloatStore_out  <= 1'b0;
            LoadType_out    <= 3'b111;
            StoreType_out   <= 2'b11;
            ALUSrcA_PC_out  <= 1'b0;
            pc_out          <= 32'b0;
            pc_plus4_out    <= 32'b0;
            rd1_out         <= 32'b0;
            rd2_out         <= 32'b0;
            frd1_out        <= 32'b0;
            frd2_out        <= 32'b0;
            imm_out         <= 32'b0;
            rs1_out         <= 5'b0;
            rs2_out         <= 5'b0;
            rd_out          <= 5'b0;
        end else begin
            RegWrite_out    <= RegWrite_in;
            RegWriteF_out   <= RegWriteF_in;
            MemWrite_out    <= MemWrite_in;
            ResultSrc_out   <= ResultSrc_in;
            Branch_out      <= Branch_in;
            Jump_out        <= Jump_in;
            ALUSrc_out      <= ALUSrc_in;
            ALUControl_out  <= ALUControl_in;
            FPUControl_out  <= FPUControl_in;
            FloatOp_out     <= FloatOp_in;
            FPUSrcAInt_out  <= FPUSrcAInt_in;
            FPUSrcBInt_out  <= FPUSrcBInt_in;
            FloatStore_out  <= FloatStore_in;
            LoadType_out    <= LoadType_in;
            StoreType_out   <= StoreType_in;
            ALUSrcA_PC_out  <= ALUSrcA_PC_in;
            pc_out          <= pc_in;
            pc_plus4_out    <= pc_plus4_in;
            rd1_out         <= rd1_in;
            rd2_out         <= rd2_in;
            frd1_out        <= frd1_in;
            frd2_out        <= frd2_in;
            imm_out         <= imm_in;
            rs1_out         <= rs1_in;
            rs2_out         <= rs2_in;
            rd_out          <= rd_in;
        end
    end

endmodule
