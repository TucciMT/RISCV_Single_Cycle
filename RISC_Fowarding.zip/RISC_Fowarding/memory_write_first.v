module memory_write_first #(
    parameter DATA_WIDTH = 8,          //! Largura dos dados (em bits)
    parameter ADDRESS_WIDTH = 4,       //! Número de bits do endereço
    parameter integer BYTE_LANE = -1   //! Identifica o byte lane para pré-carga (-1 desabilita)
) (
    input  wire                     clk,  //! Clock da memória
    input  wire                     we,   //! Habilitação de escrita
    input  wire [ADDRESS_WIDTH-1:0] addr, //! Endereço da palavra
    input  wire [DATA_WIDTH-1:0]    din,  //! Dado de entrada
    output wire [DATA_WIDTH-1:0]    dout  //! Dado de saída (leitura assíncrona)
);

    localparam DEPTH = 1 << ADDRESS_WIDTH; //! Número total de posições na memória

    reg [DATA_WIDTH-1:0] mem [0:DEPTH-1]; //! Array que armazena os dados
    integer init_idx; //! Índice auxiliar para inicialização

    initial begin
        for (init_idx = 0; init_idx < DEPTH; init_idx = init_idx + 1) begin
            mem[init_idx] = {DATA_WIDTH{1'b0}}; //! Garante memória zerada e evita valores indefinidos
        end

        if (BYTE_LANE == 0) begin
            if (DEPTH > 0) mem[0] = 8'h9a;   //! val1 LSB
            if (DEPTH > 1) mem[1] = 8'h00;   //! val2 LSB
            if (DEPTH > 2) mem[2] = 8'h00;   //! val3 LSB
            if (DEPTH > 3) mem[3] = 8'h00;   //! val4 LSB
            if (DEPTH > 4) mem[4] = 8'h00;   //! result_fp LSB
            if (DEPTH > 5) mem[5] = 8'h00;   //! result_int LSB
        end else if (BYTE_LANE == 1) begin
            if (DEPTH > 0) mem[0] = 8'h19;   //! val1 byte 1
            if (DEPTH > 1) mem[1] = 8'h80;   //! val2 byte 1
            if (DEPTH > 2) mem[2] = 8'h40;   //! val3 byte 1
            if (DEPTH > 3) mem[3] = 8'h20;   //! val4 byte 1
            if (DEPTH > 4) mem[4] = 8'h00;   //! result_fp byte 1
            if (DEPTH > 5) mem[5] = 8'h00;   //! result_int byte 1
        end else if (BYTE_LANE == 2) begin
            if (DEPTH > 0) mem[0] = 8'h01;   //! val1 byte 2
            if (DEPTH > 1) mem[1] = 8'h02;   //! val2 byte 2
            if (DEPTH > 2) mem[2] = 8'hfc;   //! val3 byte 2
            if (DEPTH > 3) mem[3] = 8'h04;   //! val4 byte 2
            if (DEPTH > 4) mem[4] = 8'h00;   //! result_fp byte 2
            if (DEPTH > 5) mem[5] = 8'h00;   //! result_int byte 2
        end else if (BYTE_LANE == 3) begin
            if (DEPTH > 0) mem[0] = 8'h00;   //! val1 MSB
            if (DEPTH > 1) mem[1] = 8'h00;   //! val2 MSB
            if (DEPTH > 2) mem[2] = 8'hff;   //! val3 MSB
            if (DEPTH > 3) mem[3] = 8'h00;   //! val4 MSB
            if (DEPTH > 4) mem[4] = 8'h00;   //! result_fp MSB
            if (DEPTH > 5) mem[5] = 8'h00;   //! result_int MSB
        end
    end

    always @(posedge clk) begin
        if (we) begin
            mem[addr] <= din; //! Escrita síncrona
        end
    end

    assign dout = mem[addr]; //! Leitura assíncrona (write-first devido ao uso de atribuição não bloqueante)

endmodule
