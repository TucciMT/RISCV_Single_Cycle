module if_id_reg (
    input        clk,           //! Sinal de clock
    input        rst,           //! Sinal de reset síncrono
    input        flush,         //! Quando ativo, injeta bolha no estágio de decodificação
    input        stall,         //! Mantém o conteúdo atual (bolha por hazard)
    input [31:0] pc_in,         //! Valor de PC do estágio IF
    input [31:0] pc_plus4_in,   //! Valor de PC+4 do estágio IF
    input [31:0] instr_in,      //! Instrução lida na memória
    output reg [31:0] pc_out,   //! PC encaminhado para o estágio ID
    output reg [31:0] pc_plus4_out, //! PC+4 encaminhado para o estágio ID
    output reg [31:0] instr_out //! Instrução encaminhada para o estágio ID
);

    always @(posedge clk) begin
        if (rst || flush) begin
            pc_out    <= 32'b0;
            pc_plus4_out <= 32'b0;
            instr_out <= 32'b0; //! Inserção de NOP
        end else if (!stall) begin
            pc_out    <= pc_in;
            pc_plus4_out <= pc_plus4_in;
            instr_out <= instr_in;
        end
    end

endmodule
