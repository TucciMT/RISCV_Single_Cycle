module ex_mem_reg (
    input        clk,
    input        rst,
    input        RegWrite_in,
    input        RegWriteF_in,
    input        MemWrite_in,
    input  [1:0] ResultSrc_in,
    input  [2:0] LoadType_in,
    input  [1:0] StoreType_in,
    input        FloatStore_in,
    input [31:0] ex_result_in,
    input [31:0] store_data_in,
    input [31:0] pc_plus4_in,
    input  [4:0] rd_in,
    output reg        RegWrite_out,
    output reg        RegWriteF_out,
    output reg        MemWrite_out,
    output reg  [1:0] ResultSrc_out,
    output reg  [2:0] LoadType_out,
    output reg  [1:0] StoreType_out,
    output reg        FloatStore_out,
    output reg [31:0] ex_result_out,
    output reg [31:0] store_data_out,
    output reg [31:0] pc_plus4_out,
    output reg  [4:0] rd_out
);

    always @(posedge clk) begin
        if (rst) begin
            RegWrite_out   <= 1'b0;
            RegWriteF_out  <= 1'b0;
            MemWrite_out   <= 1'b0;
            ResultSrc_out  <= 2'b00;
            LoadType_out   <= 3'b111;
            StoreType_out  <= 2'b11;
            FloatStore_out <= 1'b0;
            ex_result_out  <= 32'b0;
            store_data_out <= 32'b0;
            pc_plus4_out   <= 32'b0;
            rd_out         <= 5'b0;
        end else begin
            RegWrite_out   <= RegWrite_in;
            RegWriteF_out  <= RegWriteF_in;
            MemWrite_out   <= MemWrite_in;
            ResultSrc_out  <= ResultSrc_in;
            LoadType_out   <= LoadType_in;
            StoreType_out  <= StoreType_in;
            FloatStore_out <= FloatStore_in;
            ex_result_out  <= ex_result_in;
            store_data_out <= store_data_in;
            pc_plus4_out   <= pc_plus4_in;
            rd_out         <= rd_in;
        end
    end

endmodule
