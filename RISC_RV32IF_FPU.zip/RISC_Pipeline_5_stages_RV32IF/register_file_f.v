module register_file_f (
    input clk,         //! Sinal de clock
    input rst,         //! Sinal de reset
    input WE3,         //! Habilita escrita no banco de registradores de ponto flutuante
    input [4:0] A1,    //! Endereço do primeiro registrador de leitura (fA)
    input [4:0] A2,    //! Endereço do segundo registrador de leitura (fB)
    input [4:0] A3,    //! Endereço do registrador de escrita
    input [31:0] WD3,  //! Dados a serem escritos no registrador de destino
    output [31:0] RD1, //! Operando A disponibilizado para a FPU
    output [31:0] RD2  //! Operando B disponibilizado para a FPU
);

    integer i;

    reg [31:0] registers [0:31]; //! Banco de 32 registradores em ponto flutuante (f0–f31)

    // Escrita síncrona dos registradores de ponto flutuante
    always @(posedge clk, posedge rst) begin : ESCRITA
        if (rst) begin
            for (i = 0; i < 32; i = i + 1) begin : RESET
                registers[i] <= 32'b0;
            end
        end else if (WE3) begin
            registers[A3] <= WD3; //! Escreve sempre que habilitado (f0 é um registrador regular)
        end
    end

    // Leitura combinacional dos operandos destinados à FPU
    assign RD1 = registers[A1];
    assign RD2 = registers[A2];

endmodule
