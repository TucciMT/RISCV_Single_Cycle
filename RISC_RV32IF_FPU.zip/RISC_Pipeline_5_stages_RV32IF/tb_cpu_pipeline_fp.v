`timescale 1ns/1ps

module tb_cpu_pipeline_fp;
    reg clk = 0;
    reg rst = 1;

    localparam integer MAX_CYCLES   = 4096;
    localparam integer DEBUG_CYCLES = 64;
    localparam [31:0] EXPECTED_FP   = 32'h407e6680; // Resultado esperado em ponto flutuante (~3.975)
    localparam [31:0] EXPECTED_INT  = 32'h00000003; // Resultado inteiro após fcvt.w.s

    // Endereços efetivos utilizados pelo programa (relativos a 0x11000)
    localparam [31:0] ADDR_VAL1       = 32'h00011000;
    localparam [31:0] ADDR_VAL2       = 32'h00011004;
    localparam [31:0] ADDR_VAL3       = 32'h00011008;
    localparam [31:0] ADDR_VAL4       = 32'h0001100C;
    localparam [31:0] ADDR_RESULT_FP  = 32'h00011010;
    localparam [31:0] ADDR_RESULT_INT = 32'h00011014;

    cpu uut (
        .clk(clk),
        .rst(rst)
    );

    always #5 clk = ~clk;

    integer cycle;
    reg fp_written;
    reg int_written;
    reg [31:0] result_fp_word;
    reg [31:0] result_int_word;
    reg [31:0] f7_value;
    reg [31:0] x9_value;
    reg [31:0] current_fp_word;
    reg [31:0] current_int_word;

    wire [31:0] debug_pc          = uut.DATAPATH.pc;
    wire [31:0] debug_if_instr    = uut.DATAPATH.if_id_instr;
    wire        debug_memwrite    = uut.DATAPATH.id_ex_MemWrite;
    wire        debug_floatstore  = uut.DATAPATH.id_ex_FloatStore;
    wire [31:0] debug_store_data  = uut.DATAPATH.store_data;
    wire [31:0] debug_ex_result   = uut.DATAPATH.ex_result;
    wire [3:0]  debug_byte_enable = uut.DATAPATH.byte_enable;
    wire        debug_regwrite    = uut.DATAPATH.mem_wb_RegWrite;
    wire        debug_regwriteF   = uut.DATAPATH.mem_wb_RegWriteF;
    wire [4:0]  debug_memwb_rd    = uut.DATAPATH.mem_wb_rd;
    wire [31:0] debug_wb_data     = uut.DATAPATH.wb_data;
    wire [31:0] debug_alu_result  = uut.DATAPATH.alu_result;
    wire [31:0] debug_fpu_result  = uut.DATAPATH.fpu_result;

    initial begin
        $dumpfile("tb_cpu_pipeline_fp.vcd");
        $dumpvars(0, tb_cpu_pipeline_fp);
    end

    function [31:0] get_data_word_from_addr(input [31:0] addr);
        integer index;
        begin
            index = addr[7:2];
            get_data_word_from_addr = {
                uut.DATAPATH.DATA_MEMORY.mem_byte3.mem[index],
                uut.DATAPATH.DATA_MEMORY.mem_byte2.mem[index],
                uut.DATAPATH.DATA_MEMORY.mem_byte1.mem[index],
                uut.DATAPATH.DATA_MEMORY.mem_byte0.mem[index]
            };
        end
    endfunction

    task automatic print_data_word(input [31:0] addr, input [8*24-1:0] label);
        reg [31:0] value;
        begin
            value = get_data_word_from_addr(addr);
            $display("    %0s @ 0x%08h = 0x%08h", label, addr, value);
        end
    endtask

    task automatic dump_data_memory;
        begin
            $display("-- Memória de dados --");
            print_data_word(ADDR_VAL1,      "val1");
            print_data_word(ADDR_VAL2,      "val2");
            print_data_word(ADDR_VAL3,      "val3");
            print_data_word(ADDR_VAL4,      "val4");
            print_data_word(ADDR_RESULT_FP, "result_fp");
            print_data_word(ADDR_RESULT_INT,"result_int");
        end
    endtask

    task automatic dump_registers;
        begin
            $display("-- Registradores --");
            $display("    f7 = 0x%08h", uut.DATAPATH.REGISTER_FILE_F.registers[7]);
            $display("    x9 = 0x%08h", uut.DATAPATH.REGISTER_FILE.registers[9]);
            $display("    x11(base) = 0x%08h", uut.DATAPATH.REGISTER_FILE.registers[11]);
            $display("    x12(base) = 0x%08h", uut.DATAPATH.REGISTER_FILE.registers[12]);
        end
    endtask

    task automatic dump_pipeline_snapshot;
        begin
            $display("-- Pipeline snapshot --");
            $display("    IF  : PC=0x%08h instr=0x%08h", debug_pc, debug_if_instr);
            $display("    ID/EX: rd=%0d memWrite=%0b floatStore=%0b aluSrc=%0b", uut.DATAPATH.id_ex_rd,
                     uut.DATAPATH.id_ex_MemWrite, uut.DATAPATH.id_ex_FloatStore, uut.DATAPATH.id_ex_ALUSrc);
            $display("          RegWrite=%0b RegWriteF=%0b ResultSrc=%0b", uut.DATAPATH.id_ex_RegWrite,
                     uut.DATAPATH.id_ex_RegWriteF, uut.DATAPATH.id_ex_ResultSrc);
            $display("    EX  : alu=0x%08h fpu=0x%08h ex_sel=0x%08h byte_en=%b", debug_alu_result,
                     debug_fpu_result, debug_ex_result, debug_byte_enable);
            $display("    MEM/WB: rd=%0d RegWrite=%0b RegWriteF=%0b wb=0x%08h", debug_memwb_rd,
                     debug_regwrite, debug_regwriteF, debug_wb_data);
        end
    endtask

    always @(posedge clk) begin
        if (!rst) begin
            if (cycle < DEBUG_CYCLES) begin
                $display("[C%0d] PC=0x%08h instr=0x%08h | ALU=0x%08h FPU=0x%08h ex=0x%08h", cycle,
                         debug_pc, debug_if_instr, debug_alu_result, debug_fpu_result, debug_ex_result);
                if (debug_memwrite) begin
                    $display("       store -> addr=0x%08h data=0x%08h be=%b float=%0b", debug_ex_result,
                             debug_store_data, debug_byte_enable, debug_floatstore);
                end
                if (debug_regwrite) begin
                    $display("       wb int -> x%0d = 0x%08h", debug_memwb_rd, debug_wb_data);
                end
                if (debug_regwriteF) begin
                    $display("       wb float -> f%0d = 0x%08h", debug_memwb_rd, debug_wb_data);
                end
            end else if (debug_memwrite) begin
                $display("[store @C%0d] addr=0x%08h data=0x%08h be=%b float=%0b", cycle, debug_ex_result,
                         debug_store_data, debug_byte_enable, debug_floatstore);
            end
        end
    end

    initial begin
        fp_written  = 0;
        int_written = 0;

        // Aguarda alguns ciclos antes de liberar o reset
        repeat (4) @(posedge clk);
        rst = 0;

        begin : wait_loop
            for (cycle = 0; cycle < MAX_CYCLES; cycle = cycle + 1) begin
                @(posedge clk);

                current_fp_word  = get_data_word_from_addr(ADDR_RESULT_FP);
                current_int_word = get_data_word_from_addr(ADDR_RESULT_INT);

                if (!fp_written && current_fp_word !== 32'h00000000) begin
                    fp_written = 1;
                    $display("[C%0d] Detecção de escrita em result_fp: 0x%08h", cycle, current_fp_word);
                end

                if (!int_written && current_int_word !== 32'h00000000) begin
                    int_written = 1;
                    $display("[C%0d] Detecção de escrita em result_int: 0x%08h", cycle, current_int_word);
                end

                if (fp_written && int_written) begin
                    disable wait_loop;
                end
            end
        end

        result_fp_word  = get_data_word_from_addr(ADDR_RESULT_FP);
        result_int_word = get_data_word_from_addr(ADDR_RESULT_INT);
        f7_value        = uut.DATAPATH.REGISTER_FILE_F.registers[7];
        x9_value        = uut.DATAPATH.REGISTER_FILE.registers[9];

        if (!(fp_written && int_written)) begin
            $error("Timeout: resultados não foram escritos na memória dentro de %0d ciclos", MAX_CYCLES);
            dump_pipeline_snapshot();
        end else begin
            if (result_fp_word !== EXPECTED_FP) begin
                $error("Falha: esperado FP=0x%08h, obtido 0x%08h", EXPECTED_FP, result_fp_word);
            end else begin
                $display("Resultado FP correto: 0x%08h", result_fp_word);
            end

            if (f7_value !== EXPECTED_FP) begin
                $error("Falha: esperado f7=0x%08h, obtido 0x%08h", EXPECTED_FP, f7_value);
            end else begin
                $display("Registrador f7 correto: 0x%08h", f7_value);
            end

            if (result_int_word !== EXPECTED_INT) begin
                $error("Falha: esperado inteiro=0x%08h, obtido 0x%08h", EXPECTED_INT, result_int_word);
            end else begin
                $display("Resultado inteiro correto: 0x%08h", result_int_word);
            end

            if (x9_value !== EXPECTED_INT) begin
                $error("Falha: esperado x9=0x%08h, obtido 0x%08h", EXPECTED_INT, x9_value);
            end else begin
                $display("Registrador x9 correto: 0x%08h", x9_value);
            end
        end

        $display("PC final: 0x%08h", uut.DATAPATH.PROGRAM_COUNTER.PC);
        dump_data_memory();
        dump_registers();
        $finish;
    end
endmodule
