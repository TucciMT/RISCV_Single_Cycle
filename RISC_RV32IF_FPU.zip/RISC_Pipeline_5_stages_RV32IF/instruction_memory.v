module instruction_memory (
    input [31:0] A,      //! Endereço de leitura
    output reg [31:0] RD //! Dados lidos da memória de instruções
);

    reg [7:0] memory [0:1023]; //! Memória de instruções byte-addressable

    initial begin
        /*
         * Programa carregado (referência em assembly):
         *
         * .data
         *     val1:      .word 72090      # 1.1 em Q16.16
         *     val2:      .word 163840     # 2.5
         *     val3:      .word -245760    # -3.75
         *     val4:      .word 270336     # 4.125
         *     result_fp: .word 0          # espaço para FP
         *     result_int:.word 0          # espaço para inteiro
         *
         * .text
         * .globl _start
         * _start:
         *     lw      x5, val1
         *     lw      x6, val2
         *     lw      x7, val3
         *     lw      x8, val4
         *     fcvt.s.w f1, x5
         *     fcvt.s.w f2, x6
         *     fcvt.s.w f3, x7
         *     fcvt.s.w f4, x8
        *     li      x10, 0x37800000
         *     fmv.w.x f9, x10
         *     fmul.s  f1, f1, f9
         *     fmul.s  f2, f2, f9
         *     fmul.s  f3, f3, f9
         *     fmul.s  f4, f4, f9
         *     fadd.s  f5, f1, f2
         *     fadd.s  f6, f5, f3
         *     fadd.s  f7, f6, f4
         *     la      x11, result_fp
         *     fsw     f7, 0(x11)
         *     fcvt.w.s x9, f7
         *     la      x12, result_int
         *     sw      x9, 0(x12)
         * end:
         *     beq     x0, x0, end
         */
        // Programa: conversão Q16.16 para ponto flutuante, soma e reconversão
        // 00010297 -> auipc x5, 0x10
        memory[10'h000] = 8'h97;
        memory[10'h001] = 8'h02;
        memory[10'h002] = 8'h01;
        memory[10'h003] = 8'h00;
        // 0002a283 -> lw x5, 0(x5)
        memory[10'h004] = 8'h83;
        memory[10'h005] = 8'ha2;
        memory[10'h006] = 8'h02;
        memory[10'h007] = 8'h00;
        // 00010317 -> auipc x6, 0x10
        memory[10'h008] = 8'h17;
        memory[10'h009] = 8'h03;
        memory[10'h00A] = 8'h01;
        memory[10'h00B] = 8'h00;
        // ffc32303 -> lw x6, -4(x6)
        memory[10'h00C] = 8'h03;
        memory[10'h00D] = 8'h23;
        memory[10'h00E] = 8'hc3;
        memory[10'h00F] = 8'hff;
        // 00010397 -> auipc x7, 0x10
        memory[10'h010] = 8'h97;
        memory[10'h011] = 8'h03;
        memory[10'h012] = 8'h01;
        memory[10'h013] = 8'h00;
        // ff83a383 -> lw x7, -8(x7)
        memory[10'h014] = 8'h83;
        memory[10'h015] = 8'ha3;
        memory[10'h016] = 8'h83;
        memory[10'h017] = 8'hff;
        // 00010417 -> auipc x8, 0x10
        memory[10'h018] = 8'h17;
        memory[10'h019] = 8'h04;
        memory[10'h01A] = 8'h01;
        memory[10'h01B] = 8'h00;
        // ff442403 -> lw x8, -12(x8)
        memory[10'h01C] = 8'h03;
        memory[10'h01D] = 8'h24;
        memory[10'h01E] = 8'h44;
        memory[10'h01F] = 8'hff;
        // d002f0d3 -> fcvt.s.w f1, x5
        memory[10'h020] = 8'hd3;
        memory[10'h021] = 8'hf0;
        memory[10'h022] = 8'h02;
        memory[10'h023] = 8'hd0;
        // d0037153 -> fcvt.s.w f2, x6
        memory[10'h024] = 8'h53;
        memory[10'h025] = 8'h71;
        memory[10'h026] = 8'h03;
        memory[10'h027] = 8'hd0;
        // d003f1d3 -> fcvt.s.w f3, x7
        memory[10'h028] = 8'hd3;
        memory[10'h029] = 8'hf1;
        memory[10'h02A] = 8'h03;
        memory[10'h02B] = 8'hd0;
        // d0047253 -> fcvt.s.w f4, x8
        memory[10'h02C] = 8'h53;
        memory[10'h02D] = 8'h72;
        memory[10'h02E] = 8'h04;
        memory[10'h02F] = 8'hd0;
        // 37800537 -> lui x10, 0x37800
        memory[10'h030] = 8'h37;
        memory[10'h031] = 8'h05;
        memory[10'h032] = 8'h80;
        memory[10'h033] = 8'h37;
        // f00504d3 -> fmv.w.x f9, x10
        memory[10'h034] = 8'hd3;
        memory[10'h035] = 8'h04;
        memory[10'h036] = 8'h05;
        memory[10'h037] = 8'hf0;
        // 1090f0d3 -> fmul.s f1, f1, f9
        memory[10'h038] = 8'hd3;
        memory[10'h039] = 8'hf0;
        memory[10'h03A] = 8'h90;
        memory[10'h03B] = 8'h10;
        // 10917153 -> fmul.s f2, f2, f9
        memory[10'h03C] = 8'h53;
        memory[10'h03D] = 8'h71;
        memory[10'h03E] = 8'h91;
        memory[10'h03F] = 8'h10;
        // 1091f1d3 -> fmul.s f3, f3, f9
        memory[10'h040] = 8'hd3;
        memory[10'h041] = 8'hf1;
        memory[10'h042] = 8'h91;
        memory[10'h043] = 8'h10;
        // 10927253 -> fmul.s f4, f4, f9
        memory[10'h044] = 8'h53;
        memory[10'h045] = 8'h72;
        memory[10'h046] = 8'h92;
        memory[10'h047] = 8'h10;
        // 0020f2d3 -> fadd.s f5, f1, f2
        memory[10'h048] = 8'hd3;
        memory[10'h049] = 8'hf2;
        memory[10'h04A] = 8'h20;
        memory[10'h04B] = 8'h00;
        // 0032f353 -> fadd.s f6, f5, f3
        memory[10'h04C] = 8'h53;
        memory[10'h04D] = 8'hf3;
        memory[10'h04E] = 8'h32;
        memory[10'h04F] = 8'h00;
        // 004373d3 -> fadd.s f7, f6, f4
        memory[10'h050] = 8'hd3;
        memory[10'h051] = 8'h73;
        memory[10'h052] = 8'h43;
        memory[10'h053] = 8'h00;
        // 00010597 -> auipc x11, 0x10
        memory[10'h054] = 8'h97;
        memory[10'h055] = 8'h05;
        memory[10'h056] = 8'h01;
        memory[10'h057] = 8'h00;
        // fbc58593 -> addi x11, x11, -68
        memory[10'h058] = 8'h93;
        memory[10'h059] = 8'h85;
        memory[10'h05A] = 8'hc5;
        memory[10'h05B] = 8'hfb;
        // 0075a027 -> fsw f7, 0(x11)
        memory[10'h05C] = 8'h27;
        memory[10'h05D] = 8'ha0;
        memory[10'h05E] = 8'h75;
        memory[10'h05F] = 8'h00;
        // c003f4d3 -> fcvt.w.s x9, f7
        memory[10'h060] = 8'hd3;
        memory[10'h061] = 8'hf4;
        memory[10'h062] = 8'h03;
        memory[10'h063] = 8'hc0;
        // 00010617 -> auipc x12, 0x10
        memory[10'h064] = 8'h17;
        memory[10'h065] = 8'h06;
        memory[10'h066] = 8'h01;
        memory[10'h067] = 8'h00;
        // fb060613 -> addi x12, x12, -80
        memory[10'h068] = 8'h13;
        memory[10'h069] = 8'h06;
        memory[10'h06A] = 8'h06;
        memory[10'h06B] = 8'hfb;
        // 00962023 -> sw x9, 0(x12)
        memory[10'h06C] = 8'h23;
        memory[10'h06D] = 8'h20;
        memory[10'h06E] = 8'h96;
        memory[10'h06F] = 8'h00;
        // 00000063 -> beq x0, x0, 0 (loop)
        memory[10'h070] = 8'h63;
        memory[10'h071] = 8'h00;
        memory[10'h072] = 8'h00;
        memory[10'h073] = 8'h00;
    end

    always @(*) begin
        RD = {memory[A - 32'h1000 + 3], memory[A - 32'h1000 + 2], memory[A - 32'h1000 + 1], memory[A - 32'h1000 + 0]};
    end

endmodule
